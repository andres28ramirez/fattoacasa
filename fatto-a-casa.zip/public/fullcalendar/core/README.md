
# FullCalendar Core Package

Provides core functionality, including the Calendar class

[View the docs &raquo;](https://fullcalendar.io/docs/initialize-es6)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar)
