<?php $__env->startSection('title','Compras · Fatto a Casa'); ?>

<?php $__env->startSection('titulo','PAGOS REALIZADOS'); ?>

<?php $__env->startSection('tabs'); ?>
    <ul class="nav nav-tabs opciones">
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-compras')); ?>">Listado de Compras</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('suministros')); ?>">Suministros</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('cpp')); ?>">Cuentas por Pagar</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('cp')); ?>">Pagos Realizados</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('info'); ?>

    <!-- SCRIPT PARA REDIRECCIÓN BOTONES DE LA TABLA -->
    <script>
        function redirect_table(e){
            switch (e) {
                case "filtrar":
                    $('#table-filter').modal(true);
                    //CAPTURAR EVENTO SUBMIT DE FILTRAR INFORMACIÓN
                    $("#submit-form-list-pagos").unbind('click').click(function(event){
                        $("#form-list-pagos").on('submit',function(){
                            //Evaluar los valores que me llegan y hacer el location.href
                            var id = $('#form-list-pagos input[id="form-codigo"]').val(); if(!id) id = "todos";
                            var referencia = $('#form-list-pagos input[id="form-referencia"]').val(); if(!referencia) referencia = "todos";
                            var banco = $('#form-list-pagos select[id="form-banco"] option:selected').val();

                            var tiempo = $('#form-list-pagos select[id="form-tiempo"] option:selected').val();
                            var fecha_1 = "todos";
                            var fecha_2 = "todos";
                            switch (tiempo) {
                                case "Específico":
                                    fecha_1 = $('#form-list-pagos input[id="form-fecha-1"]').val();
                                    fecha_2 = $('#form-list-pagos input[id="form-fecha-2"]').val();
                                    break;
                            }

                            var cantidad = "<?php echo e($registros); ?>";
                            var registro = "<?php echo e(route('cp')); ?>";
                            var orden = "<?php echo e($order); ?>";
                            
                            var ruta = registro+"/"+cantidad+"/"+id+"/"+referencia+"/"+banco+"/"+tiempo+"/"+fecha_1+"/"+fecha_2+"/"+orden;
                            
                            if(id && referencia && banco && tiempo){
                                if(tiempo!="todos"){
                                    if(!(Date.parse(fecha_2) < Date.parse(fecha_1)) && fecha_1 && fecha_2)
                                        location.href = ruta;
                                }
                                else
                                    location.href = ruta;
                            }
                            return false;
                        });
                    });
                    break;
                case "registros":
                    var id = "<?php echo e($id); ?>"; if(!id) id = "todos";
                    var referencia = "<?php echo e($referencia); ?>"; if(!referencia) referencia = "todos";
                    var banco = "<?php echo e($banco); ?>"; if(!banco) banco = "todos";

                    var tiempo = "<?php echo e($tiempo); ?>"; if(!tiempo) tiempo = "todos";
                    var fecha_1 = "<?php echo e($fecha_1); ?>"; if(!fecha_1) fecha_1 = "todos";
                    var fecha_2 = "<?php echo e($fecha_2); ?>"; if(!fecha_2) fecha_2 = "todos";

                    var cantidad = $('select[id="num-register-lista-pagos"] option:selected').val();
                    var registro = "<?php echo e(route('cp')); ?>";
                    var orden = "<?php echo e($order); ?>";

                    var ruta = registro+"/"+cantidad+"/"+id+"/"+referencia+"/"+banco+"/"+tiempo+"/"+fecha_1+"/"+fecha_2+"/"+orden;
                    location.href = ruta;
                    break;
                case "refresh":
                    var registro = "<?php echo e(route('cp')); ?>";
                    location.href = registro;
                    break;
                case "print":
                    var id = "<?php echo e($id); ?>"; if(!id) id = "todos";
                    var referencia = "<?php echo e($referencia); ?>"; if(!referencia) referencia = "todos";
                    var banco = "<?php echo e($banco); ?>"; if(!banco) banco = "todos";

                    var tiempo = "<?php echo e($tiempo); ?>"; if(!tiempo) tiempo = "todos";
                    var fecha_1 = "<?php echo e($fecha_1); ?>"; if(!fecha_1) fecha_1 = "todos";
                    var fecha_2 = "<?php echo e($fecha_2); ?>"; if(!fecha_2) fecha_2 = "todos";

                    var registro = "<?php echo e(route('pdf-compra-pago')); ?>";
                    var ruta = registro+"/"+id+"/"+referencia+"/"+banco+"/"+tiempo+"/"+fecha_1+"/"+fecha_2;
                    window.open(ruta);
                    break;
                default: //EL DEFAULT ES EL DE ORDENAR
                    var id = "<?php echo e($id); ?>"; if(!id) id = "todos";
                    var referencia = "<?php echo e($referencia); ?>"; if(!referencia) referencia = "todos";
                    var banco = "<?php echo e($banco); ?>"; if(!banco) banco = "todos";

                    var tiempo = "<?php echo e($tiempo); ?>"; if(!tiempo) tiempo = "todos";
                    var fecha_1 = "<?php echo e($fecha_1); ?>"; if(!fecha_1) fecha_1 = "todos";
                    var fecha_2 = "<?php echo e($fecha_2); ?>"; if(!fecha_2) fecha_2 = "todos";

                    var cantidad = "<?php echo e($registros); ?>";
                    var registro = "<?php echo e(route('cp')); ?>";
                    var orden = e;

                    var ruta = registro+"/"+cantidad+"/"+id+"/"+referencia+"/"+banco+"/"+tiempo+"/"+fecha_1+"/"+fecha_2+"/"+orden;
                    location.href = ruta;
                    break;
            }
        }
    </script>

    <div class="row justify-content-center my-3 px-2">
        <?php
            if($banco)
                $filtrado = true;
            else
                $filtrado = false;

            $data_list = array(    
                "table-id" => "lista-pagos",
                "title" => "Presione sobre el pago para ver el detallado de la compra",
                "registros" => $registros,
                "filter" => $filtrado,
                "title-click" => $order,
                "titulos" => array(
                    array(
                        "nombre" => "Proveedor",
                        "bd-name" => "id_proveedor",
                    ),
                    array(
                        "nombre" => "Banco",
                        "bd-name" => "banco",
                    ),
                    array(
                        "nombre" => "Referencia",
                        "bd-name" => "referencia",
                    ),
                    array(
                        "nombre" => "Fecha",
                        "bd-name" => "fecha_pago",
                    ),
                    array(
                        "nombre" => "ID-Compra",
                        "bd-name" => "id_compra",
                    ),
                    array(
                        "nombre" => "Monto",
                        "bd-name" => "monto",
                    ),
                ),
                "content" => array(),
            );

            $data_content = array(
                "id" => 3,
                "dato-1" => "Andres",
                "dato-2" => "Banesco",
                "dato-3" => "16487943",
                "dato-4" => "13-03-2020",
                "dato-5" => "55",
                "dato-6" => "15.000 Bs",
            );

            foreach ($compras as $buy) {
                $data_content["id"] = $buy->id_pago;
                foreach($buy->pago->compra as $element){
                    $data_content["dato-1"] = $element->proveedor->nombre;
                }
                $data_content["dato-2"] = $buy->pago->banco;
                $data_content["dato-3"] = $buy->pago->referencia;
                $data_content["dato-4"] = $buy->pago->fecha_pago;
                $data_content["dato-5"] = $buy->id;
                $data_content["dato-6"] = $buy->monto." Bs";

                array_push($data_list["content"],$data_content);
            }
        ?>
        <?php echo $__env->make('includes.general_table',['data'=>$data_list], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <nav aria-label="..." class="pagination-table">
            <?php echo e($compras->links()); ?>

        </nav>
    </div>

    <!-- MODAL PARA FILTRAR LA TABLA -->
    <div class="modal fade" id="table-filter" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="titulo">Filtrar Tabla</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                        $data_form = array(
                            "action" => "",
                            "title" => "",
                            "form-id" => "form-list-pagos",
                            
                            "form-components" => array(
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Código de Compra (Opc.)",
                                    "icon" => "fa-list-alt",
                                    "type" => "number",
                                    "id_name" => "form-codigo",
                                    "form_name" => "form-codigo",
                                    "placeholder" => "Ingrese el código o la porción del mismo que desea",
                                    "validate" => "Código es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Número de Referencia Bancaria (Opc.)",
                                    "icon" => "fa-book",
                                    "type" => "number",
                                    "id_name" => "form-referencia",
                                    "form_name" => "form-referencia",
                                    "placeholder" => "Ingrese el código o la porción del mismo que desea",
                                    "validate" => "Nro. de Referencia es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Banco del Pago",
                                    "icon" => "fa-home",
                                    "id_name" => "form-banco",
                                    "form_name" => "banco",
                                    "title" => "Selecciona un Banco",
                                    "options" => array(
                                        array(
                                            "value" => "todos",
                                            "nombre" => "Cualquier Banco",
                                        ),
                                        array(
                                            "value" => "Bancamiga",
                                            "nombre" => "Bancamiga",
                                        ),
                                        array(
                                            "value" => "BanCaribe",
                                            "nombre" => "BanCaribe",
                                        ),
                                        array(
                                            "value" => "Banco Activo",
                                            "nombre" => "Banco Activo",
                                        ),
                                        array(
                                            "value" => "Banco Agrícola de Venezuela",
                                            "nombre" => "Banco Agrícola de Venezuela",
                                        ),
                                        array(
                                            "value" => "Banco Bicentenario del Pueblo",
                                            "nombre" => "Banco Bicentenario del Pueblo",
                                        ),
                                        array(
                                            "value" => "Banco Caroní",
                                            "nombre" => "Banco Caroní",
                                        ),
                                        array(
                                            "value" => "Banco de Venezuela",
                                            "nombre" => "Banco de Venezuela",
                                        ),
                                        array(
                                            "value" => "Banco del Tesoro",
                                            "nombre" => "Banco del Tesoro",
                                        ),
                                        array(
                                            "value" => "Banco Exterior",
                                            "nombre" => "Banco Exterior",
                                        ),
                                        array(
                                            "value" => "Banco Mercantil",
                                            "nombre" => "Banco Mercantil",
                                        ),
                                        array(
                                            "value" => "Banco Nacional de Crédito BNC",
                                            "nombre" => "Banco Nacional de Crédito BNC",
                                        ),
                                        array(
                                            "value" => "Banco Plaza",
                                            "nombre" => "Banco Plaza",
                                        ),
                                        array(
                                            "value" => "Banco Sofitasa",
                                            "nombre" => "Banco Sofitasa",
                                        ),
                                        array(
                                            "value" => "Banco Venezolano de Crédito",
                                            "nombre" => "Banco Venezolano de Crédito",
                                        ),
                                        array(
                                            "value" => "Banesco",
                                            "nombre" => "Banesco",
                                        ),
                                        array(
                                            "value" => "Banplus",
                                            "nombre" => "Banplus",
                                        ),
                                        array(
                                            "value" => "BBVA Provincial",
                                            "nombre" => "BBVA Provincial",
                                        ),
                                        array(
                                            "value" => "BFC Banco Fondo Común",
                                            "nombre" => "BFC Banco Fondo Común",
                                        ),
                                        array(
                                            "value" => "BOD",
                                            "nombre" => "BOD",
                                        ),
                                        array(
                                            "value" => "DELSUR",
                                            "nombre" => "DELSUR",
                                        ),
                                    ),
                                    "validate" => "Banco es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Tiempo a Evaluar",
                                    "icon" => "fa-hourglass-half",
                                    "id_name" => "form-tiempo",
                                    "form_name" => "form-tiempo",
                                    "title" => "Selecciona un tiempo",
                                    "options" => array(
                                        array(
                                            "value" => "Específico",
                                            "nombre" => "Específico",
                                        ),
                                        array(
                                            "value" => "todos",
                                            "nombre" => "Todos los años",
                                        ),
                                    ),
                                    "validate" => "Tiempo a evaluar es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Primera fecha",
                                    "icon" => "fa-calendar",
                                    "type" => "date",
                                    "id_name" => "form-fecha-1",
                                    "form_name" => "form-fecha-1",
                                    "placeholder" => "",
                                    "validate" => "Primera fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Segunda fecha",
                                    "icon" => "fa-calendar",
                                    "type" => "date",
                                    "id_name" => "form-fecha-2",
                                    "form_name" => "form-fecha-2",
                                    "placeholder" => "",
                                    "validate" => "Segunda fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                            ),
                        );
                    ?>
                    <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        //ACOMODO LA BARRA DE NAVEGACION
            $("#ic").addClass("active");
            $("#ic").removeClass("icono_head");
            $(".ic").removeClass("icono_color");
        
        //ELIMINAR LOS BOTONES DE AGREGAR-ELIMINAR-FILTRAR-DESCARGAR
            $("#add-lista-pagos").remove();
            $("#delete-lista-pagos").remove();

        //ELIMINAR TODOS LOS CHECK
            $("#th-lista-pagos").remove();
            $(".td-lista-pagos").remove();

        //REDIRECCIONAR AL DETALLADO DEL PROVEEDOR
            $(".tr-lista-pagos").click(function() {
                var id = $(this).parent().attr("id");
                var url = "<?php echo e(route('compra-pago')); ?>";
                location.href = url+"/"+id;
            });
                
        //BORRO EL TITULO DE LOS FORMULARIOS DE FILTRADO
            $(".form-title").remove();

        //ELIMINO EL SOMBRIADO DEL FORMULARIO Y LOS BORDES
            $(".container-forms").css("border","0px");
            $(".container-forms").css("box-shadow","none");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/compras/pagos/list.blade.php ENDPATH**/ ?>