<?php $__env->startSection('title','VENTAS · Fatto a Casa'); ?>

<?php $__env->startSection('titulo','INGRESAR UN PAGO'); ?>

<?php $__env->startSection('tabs'); ?>
    <ul class="nav nav-tabs opciones">
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-ventas')); ?>">Listado de Compras</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('agg-venta')); ?>">Realizar Venta</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('despachos')); ?>">Despachos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('cpc')); ?>">Cuentas por Cobrar</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('cc')); ?>">Cuentas Cobradas</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('info'); ?>
    <div class="row justify-content-center my-3 px-2">
        <div class="col-lg col-md-10 col-sm-12">
            <?php
                $data_form = array(
                    "action" => "store-client",
                    "title" => "INGRESAR UN PAGO",
                    "form-id" => "form-client",
                    
                    "form-components" => array(
                        array(
                            "opcion" => "datos",
                            "component-type" => "input",
                            "label-name" => "Nombre",
                            "icon" => "fa-user",
                            "type" => "text",
                            "id_name" => "form-user",
                            "placeholder" => "Selecciona un cliente",
                            "validate" => "Nombre es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),
                        array(
                            "opcion" => "datos",
                            "component-type" => "input",
                            "label-name" => "Fecha",
                            "icon" => "fa-user",
                            "type" => "date",
                            "id_name" => "form-credit",
                            "placeholder" => "Ingresa la fecha de la venta",
                            "validate" => "credito es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),
                        array(
                            "component-type" => "input",
                            "label-name" => "Código",
                            "icon" => "fa-user",
                            "type" => "text",
                            "id_name" => "form-credit",
                            "placeholder" => "Ingresa el código o alias de la compra",
                            "validate" => "Código es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),
                        array(
                            "opcion" => "datos",
                            "component-type" => "input",
                            "label-name" => "Crédito",
                            "icon" => "fa-user",
                            "type" => "text",
                            "id_name" => "form-credit",
                            "placeholder" => "Ingresa la duración del credito",
                            "validate" => "credito es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),
                        

                    ),

                    "form-components-product" => array(
                        array(
                            "component-type" => "input",
                            "label-name" => "Producto",
                            "icon" => "fa-user",
                            "type" => "text",
                            "id_name" => "form-name-prod",
                            "placeholder" => "Nombre del producto",
                            "validate" => "El nombre es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),
                        array(
                            "component-type" => "input",
                            "label-name" => "Precio",
                            "icon" => "fa-user",
                            "type" => "text",
                            "id_name" => "form-name-prod",
                            "placeholder" => "Precio del producto",
                            "validate" => "El nombre es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),  
                        array(
                            "component-type" => "input",
                            "label-name" => "Cantidad",
                            "icon" => "fa-user",
                            "type" => "text",
                            "id_name" => "form-name-prod",
                            "placeholder" => "Cantidad del producto",
                            "validate" => "El nombre es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),
                        array(
                            "component-type" => "input",
                            "label-name" => "Caducidad",
                            "icon" => "fa-user",
                            "type" => "text",
                            "id_name" => "form-name-prod",
                            "placeholder" => "Caducidad del producto",
                            "validate" => "El nombre es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),
                    ),
                    "components-despacho" => array(
                        array(
                            "component-type" => "select",
                            "label-name" => "Banco",
                            "icon" => "fa-user",
                            "type" => "text",
                            "id_name" => "form-user",
                            "title" => "Selecciona un Banco",
                            "options" => array(
                                "Banco de Venezuela",
                                "Banesco",
                                "Banco Plaza",
                                "Banco Bicentenario",
                                "Banco Occidental de Crédito"
                            ),
                            "validate" => "Nombre del empleado es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),
                        array(
                            "opcion" => "datos",
                            "component-type" => "input",
                            "label-name" => "Fecha de pago",
                            "icon" => "fa-user",
                            "type" => "date",
                            "id_name" => "form-credit",
                            "placeholder" => "Ingresa la fecha de la venta",
                            "validate" => "credito es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),
                        array(
                            "opcion" => "datos",
                            "component-type" => "input",
                            "label-name" => "Descripcion del pago",
                            "icon" => "fa-user",
                            "type" => "text",
                            "id_name" => "form-credit",
                            "placeholder" => "Ingresa una descripción o referencia",
                            "validate" => "credito es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "req-true",
                        ),
                    ),
                );
            ?>
            <?php echo $__env->make('includes.despacho_edit',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        //ACOMODO LA BARRA DE NAVEGACION
        $("#ip").addClass("active");
        $("#ip").removeClass("icono_head");
        $(".ip").removeClass("icono_color");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/ventas/edit-cpc.blade.php ENDPATH**/ ?>