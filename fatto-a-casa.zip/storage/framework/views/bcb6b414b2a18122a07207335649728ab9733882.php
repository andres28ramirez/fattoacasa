<?php $__env->startSection('title','Logística · Fatto a Casa'); ?>

<?php $__env->startSection('titulo','FATTO A CASA - INVENTARIO'); ?>

<?php $__env->startSection('tabs'); ?>
    <ul class="nav nav-tabs opciones">
        <li class="nav-item">
            <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('list-inventario')); ?>">Inventario</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-suministro')); ?>">Suministro</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-producto')); ?>">Portafolio de Productos</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('info'); ?>

    <!-- SCRIPT PARA REDIRECCIÓN BOTONES DE LA TABLA -->
    <script>
        function redirect_table(e){
            switch (e) {
                case "agregar":
                    $('#table-agregar').modal(true);
                    break;
                case "filtrar":
                    $('#table-filter').modal(true);
                    //CAPTURAR EVENTO SUBMIT DE FILTRAR INFORMACIÓN
                    $("#submit-form-list-product").unbind('click').click(function(event){
                        $("#form-list-product").on('submit',function(){
                            //Evaluar los valores que me llegan y hacer el location.href
                            var producto = $('#form-list-product input[id="form-name"]').val(); if(!producto) producto = "todos";
                            var tiempo = $('#form-list-product select[id="form-tiempo"] option:selected').val();
                            var fecha_1 = "todos";
                            var fecha_2 = "todos";
                            switch (tiempo) {
                                case "Específico":
                                    fecha_1 = $('#form-list-product input[id="form-fecha-1"]').val();
                                    fecha_2 = $('#form-list-product input[id="form-fecha-2"]').val();
                                    break;
                            }

                            var cantidad = "<?php echo e($registros); ?>";
                            var registro = "<?php echo e(route('list-inventario')); ?>";
                            var orden = "<?php echo e($order); ?>";
                            
                            var ruta = registro+"/"+cantidad+"/"+producto+"/"+tiempo+"/"+fecha_1+"/"+fecha_2+"/"+orden;
                            
                            if(producto && tiempo){
                                if(tiempo=="Específico"){
                                    if(!(Date.parse(fecha_2) < Date.parse(fecha_1)) && fecha_1 && fecha_2)
                                        location.href = ruta;
                                }
                                else
                                    location.href = ruta;
                            }
                            return false;
                        });
                    });
                    break;
                case "eliminar":
                    // aqui reviso los campos que estan en check y tomo su ID
                    var table = "lista-inventario";
                    var url = "<?php echo e(route('delete-inventario')); ?>";
                    var report_url = "<?php echo e(route('report-error')); ?>";
                    var inventario = new Array();
                    $("#check-lista-inventario .check-data").each(function( index ) {
                        if ($(this).prop('checked') == true){
                            inventario.push($(this).val());
                        }
                    });

                    if(inventario.length > 0){
                        swal({
                            title: "Eliminar registros",
                            text: "¿Esta seguro de eliminar los productos seleccionados?",
                            icon: "warning",
                            buttons: ["Cancelar","Aceptar"],
                            dangerMode: true,
                        })
                        .then((willDelete) => {
                            if (willDelete) {
                                ajaxDelete(inventario,url,table,report_url);
                            }
                        });
                    }
                    break;
                case "registros":
                    var producto = "<?php echo e($producto_name); ?>"; if(!producto) producto = "todos";
                    var tiempo = "<?php echo e($tiempo); ?>"; if(!tiempo) tiempo = "todos";
                    var fecha_1 = "<?php echo e($fecha_1); ?>"; if(!fecha_1) fecha_1 = "todos";
                    var fecha_2 = "<?php echo e($fecha_2); ?>"; if(!fecha_2) fecha_2 = "todos";

                    var cantidad = $('select[id="num-register-lista-inventario"] option:selected').val();
                    var registro = "<?php echo e(route('list-inventario')); ?>";
                    var orden = "<?php echo e($order); ?>";

                    var ruta = registro+"/"+cantidad+"/"+producto+"/"+tiempo+"/"+fecha_1+"/"+fecha_2+"/"+orden;
                    location.href = ruta;
                    break;
                case "refresh":
                    var registro = "<?php echo e(route('list-inventario')); ?>";
                    location.href = registro;
                    break;
                case "print":
                    var producto = "<?php echo e($producto_name); ?>"; if(!producto) producto = "todos";
                    var tiempo = "<?php echo e($tiempo); ?>"; if(!tiempo) tiempo = "todos";
                    var fecha_1 = "<?php echo e($fecha_1); ?>"; if(!fecha_1) fecha_1 = "todos";
                    var fecha_2 = "<?php echo e($fecha_2); ?>"; if(!fecha_2) fecha_2 = "todos";

                    var registro = "<?php echo e(route('pdf-list-inventario')); ?>";
                    var ruta = registro+"/"+producto+"/"+tiempo+"/"+fecha_1+"/"+fecha_2;
                    window.open(ruta);
                    break;
                default: //EL DEFAULT ES EL DE ORDENAR
                    var producto = "<?php echo e($producto_name); ?>"; if(!producto) producto = "todos";
                    var tiempo = "<?php echo e($tiempo); ?>"; if(!tiempo) tiempo = "todos";
                    var fecha_1 = "<?php echo e($fecha_1); ?>"; if(!fecha_1) fecha_1 = "todos";
                    var fecha_2 = "<?php echo e($fecha_2); ?>"; if(!fecha_2) fecha_2 = "todos";

                    var cantidad = "<?php echo e($registros); ?>";
                    var registro = "<?php echo e(route('list-inventario')); ?>";
                    var orden = e;

                    var ruta = registro+"/"+cantidad+"/"+producto+"/"+tiempo+"/"+fecha_1+"/"+fecha_2+"/"+orden;
                    location.href = ruta;
                    break;
            }
        }
    </script>

    <div class="row justify-content-center my-3 px-2">
        <?php if(session('message')): ?>
            <div class="col-12">
                <h3 class="text-center alert alert-success"><?php echo e(session('message')); ?></h3>
            </div>
        <?php endif; ?>

        <?php if(session('status')): ?>
            <div class="col-12">
                <?php if(isset($id)): ?>
                    <?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h5><?php echo e($value); ?></h5>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <h3 class="text-center alert alert-danger"><?php echo e(session('status')); ?></h3>
            </div>
        <?php endif; ?>

        <?php
            if($tiempo)
                $filtrado = true;
            else
                $filtrado = false;

            $data_list = array(
                "table-id" => "lista-inventario",
                "title" => "Presione sobre el producto del inventario para editar sus valores",
                "registros" => $registros,
                "filter" => $filtrado,
                "title-click" => $order,
                "titulos" => array(
                    array(
                        "nombre" => "Producto",
                        "bd-name" => "id_producto",
                    ),
                    array(
                        "nombre" => "Precio",
                        "bd-name" => "precio",
                    ),
                    array(
                        "nombre" => "Cantidad",
                        "bd-name" => "cantidad",
                    ),
                    array(
                        "nombre" => "Fecha de Expiración",
                        "bd-name" => "expedicion",
                    ),
                ),
                "content" => array(),
            );

            $inv_danger = array();
            $inv_warning = array();

            $data_content = array(
                "id" => 4,
                "dato-1" => "Naranja Empaquetada",
                "dato-2" => "25.000 Bs",
                "dato-3" => "5",
                "dato-4" => "30-02-2020",
            );

            foreach ($inventario as $product) {
                $data_content["id"] = $product->id;
                $data_content["dato-1"] = $product->producto->nombre;
                $data_content["dato-2"] = $product->precio." Bs";
                $data_content["dato-3"] = $product->cantidad." Kg/Und";
                $data_content["dato-4"] = $product->expedicion ? $product->expedicion : "no posee";

                array_push($data_list["content"],$data_content);
                
                if($product->expedicion){
                    if( strtotime($product->expedicion) - strtotime(date("d-m-Y")) < 3*86400){
                        if( strtotime($product->expedicion) - strtotime(date("d-m-Y")) > 0*86400)
                            array_push($inv_warning,$product->id);
                        else
                            array_push($inv_danger,$product->id);
                    }
                }
            }
        ?>
        <?php echo $__env->make('includes.general_table',['data'=>$data_list], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <nav aria-label="..." class="pagination-table">
            <?php echo e($inventario->links()); ?>

        </nav>
    </div>

    <!-- MODAL PARA FILTRAR LA TABLA -->
    <div class="modal fade" id="table-filter" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="titulo">Filtrar Tabla</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                        $data_form = array(
                            "action" => "",
                            "title" => "",
                            "form-id" => "form-list-product",
                            
                            "form-components" => array(
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Parte o Nombre completo del Producto (Opc.)",
                                    "icon" => "fa-info",
                                    "type" => "text",
                                    "id_name" => "form-name",
                                    "form_name" => "nombre",
                                    "placeholder" => "Ingrese el nombre a buscar",
                                    "validate" => "Nombre es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Fecha de Expiración",
                                    "icon" => "fa-hourglass-half",
                                    "id_name" => "form-tiempo",
                                    "form_name" => "form-tiempo",
                                    "title" => "Selecciona un tiempo",
                                    "options" => array(
                                        array(
                                            "value" => "Específico",
                                            "nombre" => "Específico",
                                        ),
                                        array(
                                            "value" => "todos",
                                            "nombre" => "Todas las fechas",
                                        ),
                                        array(
                                            "value" => "sin fecha",
                                            "nombre" => "Sin fecha de Expiración",
                                        ),
                                    ),
                                    "validate" => "Tiempo a evaluar es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Primera fecha",
                                    "icon" => "fa-calendar",
                                    "type" => "date",
                                    "id_name" => "form-fecha-1",
                                    "form_name" => "form-fecha-1",
                                    "placeholder" => "",
                                    "validate" => "Primera fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Segunda fecha",
                                    "icon" => "fa-calendar",
                                    "type" => "date",
                                    "id_name" => "form-fecha-2",
                                    "form_name" => "form-fecha-2",
                                    "placeholder" => "",
                                    "validate" => "Segunda fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                            ),
                        );
                    ?>
                    <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL PARA AGREGAR LA TABLA -->
    <div class="modal fade" id="table-agregar" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="titulo">Agregar un Nuevo Producto al Inventario</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                        $productos = array();

                        $one_option = array("value" => "id", "nombre" => "Producto X",);
                        foreach ($products as $one) {
                            $one_option["value"] = $one->id;
                            $one_option["nombre"] = $one->nombre;
                            array_push($productos,$one_option);
                        }

                        $data_form = array(
                            "action" => "save-inventario",
                            "title" => "",
                            "form-id" => "form-add-inv",
                            
                            "form-components" => array(
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Producto",
                                    "icon" => "fa-list-alt",
                                    "id_name" => "form-producto",
                                    "form_name" => "id_producto",
                                    "title" => "Selecciona un producto",
                                    "options" => $productos,
                                    "validate" => "Producto es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Precio del Producto",
                                    "icon" => "fa-money",
                                    "type" => "text",
                                    "id_name" => "form-price",
                                    "form_name" => "precio",
                                    "placeholder" => "Ingrese el precio del producto",
                                    "validate" => "Precio es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Cantidad del Producto (Kg / Und)",
                                    "icon" => "fa-archive",
                                    "type" => "number",
                                    "id_name" => "form-cantidad",
                                    "form_name" => "cantidad",
                                    "placeholder" => "Ingrese la Cantidad",
                                    "validate" => "Cantidad es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Fecha de Expiración",
                                    "icon" => "fa-calendar",
                                    "type" => "date",
                                    "id_name" => "form-fecha",
                                    "form_name" => "expedicion",
                                    "placeholder" => "",
                                    "validate" => "Fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                            ),
                        );
                    ?>
                    <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL PARA EDITAR ALGO DE INVENTARIO -->
    <div class="modal fade" id="table-editar" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="titulo">Editar la Información del Producto</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                        $data_form = array(
                            "action" => "edit-inventario",
                            "title" => "",
                            "form-id" => "form-edit-inv",
                            
                            "form-components" => array(
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Producto",
                                    "icon" => "fa-list-alt",
                                    "id_name" => "form-producto",
                                    "form_name" => "id_producto",
                                    "title" => "Selecciona un producto",
                                    "options" => $productos,
                                    "validate" => "Producto es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Precio del Producto",
                                    "icon" => "fa-money",
                                    "type" => "text",
                                    "id_name" => "form-price",
                                    "form_name" => "precio",
                                    "placeholder" => "Ingrese el precio del producto",
                                    "validate" => "Precio es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Cantidad del Producto (Kg / Und)",
                                    "icon" => "fa-archive",
                                    "type" => "text",
                                    "id_name" => "form-cantidad",
                                    "form_name" => "cantidad",
                                    "placeholder" => "Ingrese la Cantidad",
                                    "validate" => "Cantidad es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Fecha de Expiración",
                                    "icon" => "fa-calendar",
                                    "type" => "date",
                                    "id_name" => "form-fecha",
                                    "form_name" => "expedicion",
                                    "placeholder" => "",
                                    "validate" => "Fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                            ),
                        );
                    ?>
                    <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/ajax.js')); ?>"></script>
    <script>
        //ACOMODO LA BARRA DE NAVEGACION
            $("#iv").addClass("active");
            $("#iv").removeClass("icono_head");
            $(".iv").removeClass("icono_color");
        
        //MODAL PARA MODIFICAR LA CANTIDAD
            //Agrego el spinner para que exista
            html  = '<div class="m-auto text-center col-12 py-5" id="edit-spinner">';
            html +=    '<i class="fa fa-5x fa-lg fa-spinner fa-spin" style="color: #028936"></i>';
            html += '</div>';
            $("#form-edit-inv").before(html);
            //Agrego un input al formulario que llevara el id de edicion
            var html = '<input type="hidden" id="edit-suministro" name="inventario-cod" value="id-inventario">';
            $("#form-edit-inv").append(html);

            $(".tr-lista-inventario").click(function() {
                //Elimino el error si existe
                $("#error-edicion").remove();
                var id = $(this).parent().attr("id"); //id del suministro
                var url = "<?php echo e(route('info-inventario')); ?>";
                var form = "form-edit-inv"; //ES EL ID DEL FORMULARIO
                var tipo = "inventario"; //PARA QUE EL AJAX ACOMODE EN SUMINISTRO
                var spinner = "edit-spinner"; //ES EL SPINNER ANTES DEL FORMULARIO

                //FORMATEO EL MODAL Y LO MUESTRO
                $("#"+form).addClass("d-none");
                $("#"+spinner).removeClass("d-none");
                $('#table-editar').modal(true);
                
                //AGREGO LOS PRODUCTOS DE DICHO SUMINISTRO Y FORMATEO EL MODAL
                ajaxEditLogistica(id,url,form,tipo,spinner);
            });

        //BORRO EL TITULO DE LOS FORMULARIOS DE FILTRADO
            $(".form-title").remove();

        //ELIMINO EL SOMBRIADO DEL FORMULARIO Y LOS BORDES
            $(".container-forms").css("border","0px");
            $(".container-forms").css("box-shadow","none");
        
        //BORRO EL TABLE STRIPED PARA PODER PONER BG WARNING Y BG DANGER POR EXPIRACION
            $("table").removeClass("table-striped");
        
        //MUESTRO LOS PRODUCTOS QUE ESTAN CERCA DE EXPIRAR CON EL SOMBRIADO EN LA TABLA
            <?php if(!empty($inv_danger)): ?>
                <?php $__currentLoopData = $inv_danger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    $(".tr-lista-inventario").each(function() {
                        var id = $(this).parent().attr("id");
                        if(id == "<?php echo e($one); ?>")
                            $(this).parent().addClass("alert-danger");
                    });
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php if(!empty($inv_warning)): ?>
                <?php $__currentLoopData = $inv_warning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    $(".tr-lista-inventario").each(function() {
                        var id = $(this).parent().attr("id");
                        if(id == "<?php echo e($one); ?>")
                            $(this).parent().addClass("alert-warning");
                    });
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        
        //EVENTO QUE GENERA UN SWALERT SI FALTAN PRODUCTOS Y MUESTRO CUALES SON
            <?php if(session('fallo')): ?>
                var html = 'Faltan los siguientes productos en suministro:';
                    <?php $__currentLoopData = session('fallo'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        html += '\n<?php echo e($one["nombre"]); ?>: <?php echo e($one["cantidad"]); ?> Kg/unidades';
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                swal({
                    title: "El producto no pudo ser agregado",
                    text: html,
                    icon: 'error',
                    closeOnClickOutside: false,
                    button: 'Aceptar',
                });
            <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/logistics/list_inventario.blade.php ENDPATH**/ ?>