<!DOCTYPE html>
<html lang="en">
<head>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
        <title>Fatto a Casa</title>
        <link rel="SHORTCUT ICON" href="<?php echo e(asset('img/logo.png')); ?>">
    
        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    
        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
        <link href="<?php echo e(asset('font/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet">
    
        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/utils.css')); ?>" rel="stylesheet">
    
    </head>
</head>
<body>
    <div class="app">
        <div class="limiter">
            <div class="row justify-content-center container-login100" style="background-image: url(<?php echo e(asset('img/bg-login.jpg')); ?>)">

                <div class="wrap-login100">
                    <div class="login100-form-title" style="background-image: url(<?php echo e(asset('img/bg-up-login.jpg')); ?>)">
                        <span class="login100-form-title-1">
                            <?php echo e(__('Resetear contraseña')); ?>

                        </span>
                    </div>

                    

                    <form class="login100-form validate-form" method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="wrap-input100 validate-input m-b-26" data-validate="Es requerido ingresar un correo">
                            <span class="label-input100"><?php echo e(__('Dirección de correo')); ?></span>
                            <input id="email" type="email" class="input100 form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" autofocus>

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e("Este correo no se encuentra registrado"); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>

                        <div class="flex-sb-m w-full p-b-30">
                            <div>
                                <a href="<?php echo e(route('login')); ?>" class="txt1">
                                    Iniciar sesion
                                </a>
                            </div>
                        </div>

                        <div class="container-login100-form-btn">
                            <button class="login100-form-btn" type="submit">
                                <?php echo e(__('Enviar link de reseteo de contraseña')); ?>

                            </button>
                        </div>
                    </form>
			    </div>
            </div>
        </div>
    </div>
</body>
</html>

<script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

<?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>