<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Fatto a Casa</title>
    <link rel="SHORTCUT ICON" href="<?php echo e(asset('img/logo.png')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="<?php echo e(asset('font/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/utils.css')); ?>" rel="stylesheet">

</head>
<body>
    <div class="app">
        <div class="limiter">
            <div class="row justify-content-center container-login100" style="background-image: url(<?php echo e(asset('img/bg-login.jpg')); ?>)">

                <div class="wrap-login100">
                    <div class="login100-form-title" style="background-image: url(<?php echo e(asset('img/bg-up-login.jpg')); ?>)">
                        <span class="login100-form-title-1">
                            <?php echo e(__('Iniciar Sesión')); ?>

                        </span>
                    </div>

                    <form class="login100-form validate-form" method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="wrap-input100 validate-input m-b-26" data-validate="Usuario es requerido">
                            <span class="label-input100"><?php echo e(__('Usuario')); ?></span>
                            <input id="username" type="text" placeholder="Ingresar Usuario" class="input100 form-control <?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" autofocus>
                            <span class="focus-input100"></span>
                            <?php if($errors->has('username')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e("El usuario o la contraseña no concuerdan"); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="wrap-input100 validate-input m-b-18" data-validate="Contraseña es requerida">
                            <span class="label-input100"><?php echo e(__('Contraseña')); ?></span>
                            <input id="password" type="password" placeholder="Ingresar Contraseña" class="input100 form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password">
                            <span class="focus-input100"></span>
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e("Error de Contraseña"); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="flex-sb-m w-full p-b-30">
                            <div>
                                <a href="<?php echo e(route('password.request')); ?>" class="txt1">
                                    Recuperar Contraseña...
                                </a>
                            </div>
                        </div>

                        <div class="container-login100-form-btn">
                            <button class="login100-form-btn" type="submit">
                                <?php echo e(__('Ingresar')); ?>

                            </button>
                        </div>
                    </form>
			    </div>
            </div>
        </div>
    </div>
</body>
</html>

<script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

<?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/auth/login.blade.php ENDPATH**/ ?>