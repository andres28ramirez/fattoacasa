<?php $__env->startSection('title','Clientes · Fatto a Casa'); ?>

<?php $__env->startSection('titulo','AGREGAR - CLIENTES'); ?>

<?php $__env->startSection('tabs'); ?>
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-client')); ?>">Listado</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('agg-client')); ?>">Añadir</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('sell-client')); ?>">Ventas Realizadas</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('info'); ?>
    <div class="row justify-content-center my-3 px-2">
        <div class="col-lg col-md-10 col-sm-12">
            <?php
                $zonas = array ();

                $one_zone = array(
                    "value" => 1,
                    "nombre" => "Hatillo",
                );

                foreach ($zones as $zone) {
                    $one_zone["value"] = $zone->id;
                    $one_zone["nombre"] = $zone->nombre;
                    array_push($zonas,$one_zone);
                }

                $data_form = array(
                    "action" => "save-client",
                    "title" => "AGREGAR UN NUEVO CLIENTE",
                    "form-id" => "form-client",
                    
                    "form-components" => array(
                        array(
                            "component-type" => "input",
                            "label-name" => "Nombre",
                            "icon" => "fa-user",
                            "type" => "text",
                            "id_name" => "form-user",
                            "form_name" => "nombre",
                            "placeholder" => "Ingrese el nombre del cliente",
                            "validate" => "Nombre es requerido",
                            "bd-error" => "El nombre ya se encuentra registrado",
                            "requerido" => "req-true",
                        ),
                        array(
                            "component-type" => "input",
                            "label-name" => "CI/RIF",
                            "icon" => "fa-id-card",
                            "type" => "text",
                            "id_name" => "form-cid",
                            "form_name" => "rif_cedula",
                            "placeholder" => "Ingrese la cédula o RIF",
                            "validate" => "CI/RIF es requerido",
                            "bd-error" => "LO QUE SEA",
                            "requerido" => "La cédula o rif ya se encuentra registrada",
                        ),
                        array(
                            "component-type" => "input",
                            "label-name" => "Teléfono",
                            "icon" => "fa-phone",
                            "type" => "text",
                            "id_name" => "form-phone",
                            "form_name" => "telefono",
                            "placeholder" => "Ingrese el teléfono",
                            "validate" => "Teléfono es requerido",
                            "bd-error" => "El teléfono ya se encuentra registrado",
                            "requerido" => "req-true",
                        ),
                        array(
                            "component-type" => "input",
                            "label-name" => "Correo",
                            "icon" => "fa-at",
                            "type" => "text",
                            "id_name" => "form-email",
                            "form_name" => "correo",
                            "placeholder" => "Ingrese el correo",
                            "validate" => "Correo es requerido",
                            "bd-error" => "El correo ya se encuentra registrado",
                            "requerido" => "req-true",
                        ),
                        array(
                            "component-type" => "input",
                            "label-name" => "Dirección",
                            "icon" => "fa-map-marker",
                            "type" => "text",
                            "id_name" => "form-direction",
                            "form_name" => "direccion",
                            "placeholder" => "Ingrese la dirección",
                            "validate" => "Dirección es requerida",
                            "bd-error" => "La dirección ya se encuentra registrada",
                            "requerido" => "req-true",
                        ),
                        array(
                            "component-type" => "select",
                            "label-name" => "Zona",
                            "icon" => "fa-map-pin",
                            "id_name" => "form-zone",
                            "form_name" => "id_zona",
                            "title" => "Selecciona una zona",
                            "options" => $zonas,
                            "validate" => "Zona es requerida",
                            "bd-error" => "La zona ya se encuentra registrada",
                            "requerido" => "req-true",
                        ),
                    ),
                );
            ?>
            <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        //ACOMODO LA BARRA DE NAVEGACION
            $("#ib").addClass("active");
            $("#ib").removeClass("icono_head");
            $(".ib").removeClass("icono_color");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/clients/add.blade.php ENDPATH**/ ?>