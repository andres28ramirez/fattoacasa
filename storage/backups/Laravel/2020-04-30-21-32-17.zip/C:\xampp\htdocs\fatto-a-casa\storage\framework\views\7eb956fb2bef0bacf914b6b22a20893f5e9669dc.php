<?php $__env->startSection('title','Logística · Fatto a Casa'); ?>

<?php $__env->startSection('titulo','FATTO A CASA - SUMINISTRO'); ?>

<?php $__env->startSection('tabs'); ?>
    <ul class="nav nav-tabs opciones">
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-inventario')); ?>">Inventario</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-suministro')); ?>">Suministro</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('list-producto')); ?>">Portafolio de Productos</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('info'); ?>

    <style>
        .table-buttons:hover {
            background-color: #028936;
            color: rgba(255,255,255,1);
            -webkit-transition: all 1s ease;
            -moz-transition: all 1s ease;
            -o-transition: all 1s ease;
            -ms-transition: all 1s ease;
            transition: all 1s ease;
        }

        .table-buttons {
            color: white;
            background-color: rgba(2,137,54,0.5);
        }

        .border-detail {
            border-top: 1px solid #ced4da;
            border-left: 1px solid #ced4da;
        }
    </style>

    
    <div class="text-left py-2" style="font-size: 1.2em; border-bottom: 1px solid black">
        INFORMACIÓN DEL PRODUCTO
    </div>

    <div class="border">
        <?php
            $data_form = array(
                "action" => "edit-nomina",
                "title" => "",
                "form-id" => "form-nomina",
                
                "form-components" => array(
                    array(
                        "component-type" => "select",
                        "label-name" => "Empleado",
                        "icon" => "fa-user",
                        "id_name" => "form-empleado",
                        "title" => "Selecciona una opción",
                        "options" => array(
                            "Lista de Empleados",
                        ),
                        "validate" => "Empleado es requerido",
                        "bd-error" => "LO QUE SEA",
                        "requerido" => "req-true",
                    ),
                    array(
                        "component-type" => "input",
                        "label-name" => "Fecha correspondiente en Nómina",
                        "icon" => "fa-calendar",
                        "type" => "date",
                        "id_name" => "form-fecha",
                        "placeholder" => "Ingrese la fecha de Nómina",
                        "validate" => "Fecha es requerida",
                        "bd-error" => "LO QUE SEA",
                        "requerido" => "req-true",
                    ),
                    array(
                        "component-type" => "input",
                        "label-name" => "Fecha del Pago",
                        "icon" => "fa-calendar-o",
                        "type" => "date",
                        "id_name" => "form-fecha-pago",
                        "placeholder" => "Ingrese la fecha del pago",
                        "validate" => "Fecha es requerida",
                        "bd-error" => "LO QUE SEA",
                        "requerido" => "req-true",
                    ),
                    array(
                        "component-type" => "input",
                        "label-name" => "Monto Pagado",
                        "icon" => "fa-money",
                        "type" => "text",
                        "id_name" => "form-price",
                        "placeholder" => "Ingrese el monto",
                        "validate" => "Monto es requerido",
                        "bd-error" => "LO QUE SEA",
                        "requerido" => "req-true",
                    ),
                    array(
                        "component-type" => "select",
                        "label-name" => "Banco del Pago",
                        "icon" => "fa-home",
                        "id_name" => "form-banco",
                        "title" => "Selecciona una opción",
                        "options" => array(
                            "BOD",
                            "BBVA Provincial",
                            "Banesco",
                        ),
                        "validate" => "Banco es requerido",
                        "bd-error" => "LO QUE SEA",
                        "requerido" => "req-true",
                    ),
                    array(
                        "component-type" => "input",
                        "label-name" => "Referencia Bancaria",
                        "icon" => "fa-clipboard",
                        "type" => "text",
                        "id_name" => "form-referencia",
                        "placeholder" => "Ingrese la referencia",
                        "validate" => "Referencia es requerida",
                        "bd-error" => "LO QUE SEA",
                        "requerido" => "req-true",
                    ),
                ),
            );

            $datos = array(
                array(
                    "label" => "Nombre del Empleado", 
                    "dato" => "Andres Ramirez",
                ),
                array(
                    "label" => "Cédula", 
                    "dato" => "23.868.394",
                ),
                array(
                    "label" => "Tipo de Empleado", 
                    "dato" => "Operador",
                ),
                array(
                    "label" => "Sueldo del Empleado", 
                    "dato" => "30.000 Bs",
                ),
                array(
                    "label" => "Banco del Empleado", 
                    "dato" => "BOD",
                ),
            );

            $data_list = array(
                array(
                    "table-id" => "lista-nomina",
                    "icon" => "fa-user",
                    "type" => "inline-info",
                    "title" => "Información del Empleado",
                    "information" => $datos,
                ),
            );

            $title = "Datos del Pago de Nómina";
        ?>
        <?php echo $__env->make('includes.general_detail',['data'=>$data_form, 'data_list'=>$data_list, 'title'=>$title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/form_validate.js')); ?>"></script>
    <script>
        //ACOMODO LA BARRA DE NAVEGACION
        $("#iv").addClass("active");
        $("#iv").removeClass("icono_head");
        $(".iv").removeClass("icono_color");
        
        //VOLVER A LA VISTA QUE ESTABAMOS ANTES
        const retroceder = () => {
            location.href = "<?php echo e(route('list-producto')); ?>";
        }
    </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/logistics/detail_product.blade.php ENDPATH**/ ?>