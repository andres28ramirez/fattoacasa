<?php $__env->startSection('title','VENTAS · Fatto a Casa'); ?>

<?php $__env->startSection('titulo','DESPACHOS'); ?>

<?php $__env->startSection('tabs'); ?>
    <ul class="nav nav-tabs opciones">
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-ventas')); ?>">Listado de Compras</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('agg-venta')); ?>">Realizar Venta</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('despachos')); ?>">Despachos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('cpc')); ?>">Cuentas por Cobrar</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('cc')); ?>">Cuentas Cobradas</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('info'); ?>

    <!-- SCRIPT PARA REDIRECCIÓN BOTONES DE LA TABLA -->
    <script>
        function redirect_table(e){
            switch (e) {
                case "agregar":
                    location.href = "<?php echo e(route('agg-venta')); ?>";
                    break;
                case "filtrar":
                    $('#table-filter').modal(true);
                    break;
                case "eliminar":
                    alert("ACOMODAR TABLA PARA QUE ELIMINE LOS VALORES DADOS");
                    break;
                case "registros":
                    alert("ACOMODAR TABLA A CANTIDAD DE REGISTROS");
                    break;
                case "print":
                    alert("IMPRIMIR LA TABLA TAL Y COMO ESTE FILTRADA O NO");
                    break;
                default:
                    alert("DEFAULT");
                    break;
            }
        }
    </script>

    <div class="row justify-content-center my-3 px-2">
        <?php
            $data_list = array(
                
                "table-id" => "ventas-cliente",
                "title" => "TOTAL DESPACHOS",
                "pagina" => 1,
                "pagina-total" => 6,

                "titulos" => array(
                    "ID",
                    "Proveedor",
                    "Monto",
                    "Fecha",
                    "Trabajador",
                    
                ),

                "content" => array( 
                    array(
                        "id" => 1,
                        "dato-1" => "1",
                        "dato-2" => "Excelsior Gama",
                        "dato-3" => "25869,123 Bs",
                        "dato-4" => "No despachado",
                        "dato-5" => "No despachado",
                    ),
                    array(
                        "id" => 2,
                        "dato-1" => "2",
                        "dato-2" => "Gama",
                        "dato-3" => "25869,123 Bs",
                        "dato-4" => "28-06-1996",
                        "dato-5" => "Andres Sosa",
                    ),
                    array(
                        "id" => 3,
                        "dato-1" => "3",
                        "dato-2" => "Excelsior",
                        "dato-3" => "869,123 Bs",
                        "dato-4" => "28-06-1996",
                        "dato-5" => "Pedro Duque",
                    ),
                    array(
                        "id" => 3,
                        "dato-1" => "3",
                        "dato-2" => "Excelsior",
                        "dato-3" => "869,123 Bs",
                        "dato-4" => "No despachado",
                        "dato-5" => "No despachado",
                    ),
                    array(
                        "id" => 3,
                        "dato-1" => "3",
                        "dato-2" => "Excelsior",
                        "dato-3" => "869,123 Bs",
                        "dato-4" => "28-06-1996",
                        "dato-5" => "Michael salazar",
                    ),
                ),
            );
        ?>
        <?php echo $__env->make('includes.general_table',['data'=>$data_list], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- MODAL PARA VER EL DETALLADO DE PRODUCTOS -->
    <?php
        $data_modal = array(    
            "modal-id" => "venta-detail",
            "title" => "Venta Detallada",
        );
    ?>
    <?php echo $__env->make('includes.detail_sell_buy',['data'=>$data_modal], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- MODAL PARA FILTRAR LA TABLA -->
    <div class="modal fade" id="table-filter" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="titulo">Filtrar Tabla</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                        $data_form = array(
                            "action" => "",
                            "title" => "",
                            "form-id" => "form-list-client",
                            
                            "form-components" => array(
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Periodo a Evaluar",
                                    "icon" => "fa-leanpub",
                                    "id_name" => "form-periodo",
                                    "title" => "Selecciona un periodo",
                                    "options" => array(
                                        "Mensual",
                                        "Trimestral",
                                        "Días de la Semana",
                                    ),
                                    "validate" => "Periodo es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Tiempo a Evaluar",
                                    "icon" => "fa-hourglass-half",
                                    "id_name" => "form-tiempo",
                                    "title" => "Selecciona un tiempo",
                                    "options" => array(
                                        "Año",
                                        "Específico",
                                        "Todos los años",
                                    ),
                                    "validate" => "Tiempo a evaluar es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Selecionar Año",
                                    "icon" => "fa-calendar-o",
                                    "type" => "number",
                                    "id_name" => "form-año",
                                    "placeholder" => "Ingrese el año deseado",
                                    "validate" => "Año es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Primera fecha",
                                    "icon" => "fa-calendar",
                                    "type" => "month",
                                    "id_name" => "form-fecha-1",
                                    "placeholder" => "",
                                    "validate" => "Primera fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Segunda fecha",
                                    "icon" => "fa-calendar",
                                    "type" => "month",
                                    "id_name" => "form-fecha-2",
                                    "placeholder" => "",
                                    "validate" => "Segunda fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                            ),
                        );
                    ?>
                    <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        //ACOMODO LA BARRA DE NAVEGACION
        $("#ip").addClass("active");
        $("#ip").removeClass("icono_head");
        $(".ip").removeClass("icono_color");

        //ELIMINAR LOS BOTONES DE AGREGAR-ELIMINAR-FILTRAR-DESCARGAR
        $("#delete-ventas-cliente").remove();
        $("#add-ventas-cliente").remove();

        //ELIMINAR TODOS LOS CHECK
        $("#th-ventas-cliente").remove();
        $(".td-ventas-cliente").remove();

        //ABRIR MODAL PARA VER DETALLADO DE PRODUCTOS
        $(".tr-ventas-cliente").click(function() {
            location.href = "<?php echo e(route('edit-despacho')); ?>";
        });

        //BORRO EL TITULO DE LOS FORMULARIOS DE FILTRADO
        $(".form-title").remove();

        //ELIMINO EL SOMBRIADO DEL FORMULARIO Y LOS BORDES
        $(".container-forms").css("border","0px");
        $(".container-forms").css("box-shadow","none");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/ventas/despachos.blade.php ENDPATH**/ ?>