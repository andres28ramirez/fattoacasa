
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agenda` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `tipo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `agenda` WRITE;
/*!40000 ALTER TABLE `agenda` DISABLE KEYS */;
/*!40000 ALTER TABLE `agenda` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `agenda_persona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agenda_persona` (
  `id_agenda` int(255) NOT NULL,
  `id_trabajador` int(255) DEFAULT NULL,
  `id_cliente` int(255) DEFAULT NULL,
  `id_proveedor` int(255) DEFAULT NULL,
  KEY `fk_agenda_persona_agenda` (`id_agenda`),
  KEY `fk_agenda_persona_trabajador` (`id_trabajador`),
  KEY `fk_agenda_persona_cliente` (`id_cliente`),
  KEY `fk_agenda_persona_proveedor` (`id_proveedor`),
  CONSTRAINT `fk_agenda_persona_agenda` FOREIGN KEY (`id_agenda`) REFERENCES `agenda` (`id`),
  CONSTRAINT `fk_agenda_persona_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`),
  CONSTRAINT `fk_agenda_persona_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id`),
  CONSTRAINT `fk_agenda_persona_trabajador` FOREIGN KEY (`id_trabajador`) REFERENCES `trabajador` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `agenda_persona` WRITE;
/*!40000 ALTER TABLE `agenda_persona` DISABLE KEYS */;
/*!40000 ALTER TABLE `agenda_persona` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'Productos Frescos'),(2,'Productos Procesados'),(3,'Producto para empaquetar');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `id_zona` int(255) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `telefono` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `tipo_cid` varchar(255) NOT NULL,
  `rif_cedula` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cliente_zona` (`id_zona`),
  CONSTRAINT `fk_cliente_zona` FOREIGN KEY (`id_zona`) REFERENCES `zona` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Gilberto Ramirez',1,'Los Cocos','0412-7942183','gilbertoramirezm@gmail.com','V -','9169478','2020-03-06 20:09:27','2020-04-06 20:09:27'),(2,'Excelsior Gama C.A',2,'NE 25 SW 56','+58-414-3836100','excelsiorgama@gmail.com','J -','159753456','2020-04-06 20:20:51','2020-04-06 20:59:20');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compra` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_proveedor` int(255) NOT NULL,
  `id_pago` int(255) DEFAULT NULL,
  `fecha` date NOT NULL,
  `monto` double NOT NULL,
  `credito` int(255) NOT NULL,
  `pendiente` tinyint(1) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_compra_proveedor` (`id_proveedor`),
  KEY `fk_compra_pago` (`id_pago`),
  CONSTRAINT `fk_compra_pago` FOREIGN KEY (`id_pago`) REFERENCES `pago` (`id`),
  CONSTRAINT `fk_compra_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `compra` WRITE;
/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
INSERT INTO `compra` VALUES (2,30,2,'2020-02-25',58290,20,1,'2020-03-30 21:45:40','2020-03-31 02:34:44'),(3,32,1,'2019-06-28',1814.82,60,1,'2020-03-30 21:51:35','2020-03-31 21:17:31'),(4,29,3,'2020-02-20',4932.9,30,1,'2020-03-31 17:25:07','2020-03-31 21:17:55'),(10,33,6,'2020-02-20',2332.99,30,1,'2020-04-02 19:10:07','2020-04-02 19:23:57'),(11,30,NULL,'2020-04-02',1.16,30,0,'2020-04-02 19:23:04','2020-04-02 19:23:04'),(12,33,NULL,'2020-04-12',1740,25,0,'2020-04-12 18:16:58','2020-04-12 18:16:58');
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `despacho`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `despacho` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_venta` int(255) NOT NULL,
  `id_trabajador` int(255) DEFAULT NULL,
  `fecha` date NOT NULL,
  `nota` varchar(255) NOT NULL,
  `entregado` tinyint(1) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_despacho_venta` (`id_venta`),
  KEY `fk_despacho_trabajador` (`id_trabajador`),
  CONSTRAINT `fk_despacho_trabajador` FOREIGN KEY (`id_trabajador`) REFERENCES `trabajador` (`id`),
  CONSTRAINT `fk_despacho_venta` FOREIGN KEY (`id_venta`) REFERENCES `venta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `despacho` WRITE;
/*!40000 ALTER TABLE `despacho` DISABLE KEYS */;
INSERT INTO `despacho` VALUES (3,7,1,'2020-04-12','Despacho a la 2:00 pm, tocar reja primero',1,'2020-04-11 18:35:10','2020-04-11 19:06:30'),(5,6,1,'2020-06-17','Tocar la puerta',0,'2020-04-17 16:55:21','2020-04-17 16:59:43');
/*!40000 ALTER TABLE `despacho` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `desperdicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `desperdicio` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_compra` int(255) NOT NULL,
  `id_producto` int(255) NOT NULL,
  `cantidad` double NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_desperdicio_compra` (`id_compra`),
  KEY `fk_desperdicio_producto` (`id_producto`),
  CONSTRAINT `fk_desperdicio_compra` FOREIGN KEY (`id_compra`) REFERENCES `compra` (`id`),
  CONSTRAINT `fk_desperdicio_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `desperdicio` WRITE;
/*!40000 ALTER TABLE `desperdicio` DISABLE KEYS */;
INSERT INTO `desperdicio` VALUES (1,4,2,1,NULL,NULL),(2,4,9,3,NULL,NULL),(4,3,5,5,'2020-04-01 17:48:12','2020-04-01 17:48:12'),(5,2,4,9,'2020-04-01 17:51:14','2020-04-01 17:56:31'),(6,2,7,42,'2020-04-01 17:51:14','2020-04-01 17:56:31');
/*!40000 ALTER TABLE `desperdicio` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `egreso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `egreso` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_compra` int(255) DEFAULT NULL,
  `id_gasto_costo` int(255) DEFAULT NULL,
  `id_pago_nomina` int(255) DEFAULT NULL,
  `monto` double NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_egreso_compra` (`id_compra`),
  KEY `fk_egreso_gasto_costo` (`id_gasto_costo`),
  KEY `fk_egreso_pago_nomina` (`id_pago_nomina`),
  CONSTRAINT `fk_egreso_compra` FOREIGN KEY (`id_compra`) REFERENCES `compra` (`id`),
  CONSTRAINT `fk_egreso_gasto_costo` FOREIGN KEY (`id_gasto_costo`) REFERENCES `gasto_costo` (`id`),
  CONSTRAINT `fk_egreso_pago_nomina` FOREIGN KEY (`id_pago_nomina`) REFERENCES `pago_nomina` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `egreso` WRITE;
/*!40000 ALTER TABLE `egreso` DISABLE KEYS */;
INSERT INTO `egreso` VALUES (1,2,NULL,NULL,58290,'2020-03-30 21:45:40','2020-03-30 21:45:40'),(2,3,NULL,NULL,1814.82,'2020-03-30 21:51:35','2020-03-30 21:51:35'),(3,4,NULL,NULL,4932.9,'2020-03-31 17:25:07','2020-03-31 17:25:07'),(4,10,NULL,NULL,2332.99,'2020-04-02 19:10:07','2020-04-02 19:10:07'),(5,11,NULL,NULL,1.16,'2020-04-02 19:23:04','2020-04-02 19:23:04'),(7,12,NULL,NULL,1740,'2020-04-12 18:16:58','2020-04-12 18:16:58'),(9,NULL,2,NULL,500.527,'2020-04-12 22:06:49','2020-04-12 22:28:34'),(10,NULL,3,NULL,123.751,'2020-04-12 22:09:15','2020-04-12 22:09:15'),(11,NULL,NULL,1,5800.186,'2020-04-14 19:47:49','2020-04-14 20:46:00');
/*!40000 ALTER TABLE `egreso` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `gasto_costo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gasto_costo` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `monto` double NOT NULL,
  `tipo` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `gasto_costo` WRITE;
/*!40000 ALTER TABLE `gasto_costo` DISABLE KEYS */;
INSERT INTO `gasto_costo` VALUES (2,'2020-04-12','Pago de Servicio de Internet',500.527,'Gasto','2020-04-12 22:06:49','2020-04-12 22:29:01'),(3,'2020-04-12','Pago de DirecTV',123.751,'Costo','2020-04-12 22:09:15','2020-04-12 22:09:15');
/*!40000 ALTER TABLE `gasto_costo` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `incidencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incidencia` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_user` int(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `activity` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_incidencia_users` (`id_user`),
  CONSTRAINT `fk_incidencia_users` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `incidencia` WRITE;
/*!40000 ALTER TABLE `incidencia` DISABLE KEYS */;
INSERT INTO `incidencia` VALUES (3,1,'Andres Ramirez','Módulo Logística','Producto Editado Código (5)','2020-03-30 17:13:37','2020-03-30 17:13:37'),(4,1,'Andres Ramirez','Módulo Logística','Producto Editado Código (5)','2020-03-30 17:13:44','2020-03-30 17:13:44'),(5,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (1)','2020-03-30 21:26:56','2020-03-30 21:26:56'),(6,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (2)','2020-03-30 21:45:40','2020-03-30 21:45:40'),(7,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (3)','2020-03-30 21:51:35','2020-03-30 21:51:35'),(8,1,'Andres Ramirez','Módulo Compras','Compra Editada Código (2)','2020-03-31 02:34:21','2020-03-31 02:34:21'),(9,1,'Andres Ramirez','Módulo Compras','Compra Editada Código (2)','2020-03-31 02:34:44','2020-03-31 02:34:44'),(10,1,'Andres Ramirez','Módulo Compras','Compra Editada Código (3)','2020-03-31 02:36:16','2020-03-31 02:36:16'),(11,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (4)','2020-03-31 17:25:07','2020-03-31 17:25:07'),(12,1,'Andres Ramirez','Módulo Compras','Pago añadido - Código de Compra (4)','2020-03-31 17:33:53','2020-03-31 17:33:53'),(13,1,'Andres Ramirez','Módulo Compras','Compra Editada Código (3)','2020-03-31 17:34:22','2020-03-31 17:34:22'),(14,1,'Andres Ramirez','Módulo Logística','Producto Editado Código (9)','2020-03-31 20:49:27','2020-03-31 20:49:27'),(15,1,'Andres Ramirez','Módulo Proveedores','Proveedor Añadido Cédula/Rif (9148869)','2020-03-31 20:50:59','2020-03-31 20:50:59'),(16,1,'Andres Ramirez','Módulo Proveedores','Proveedor Eliminado Cédula/Rif (9148869)','2020-03-31 20:51:05','2020-03-31 20:51:05'),(17,1,'Andres Ramirez','Módulo Proveedores','Proveedor Añadido Cédula/Rif (9148869)','2020-03-31 20:52:34','2020-03-31 20:52:34'),(18,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Requested page not found [404]]','2020-03-31 21:10:21','2020-03-31 21:10:21'),(19,1,'Andres Ramirez','Módulo Compras','Compra Editada Código (3)','2020-03-31 21:12:47','2020-03-31 21:12:47'),(20,1,'Andres Ramirez','Módulo Compras','Compra Editada Código (3)','2020-03-31 21:17:31','2020-03-31 21:17:31'),(21,1,'Andres Ramirez','Módulo Compras','Compra Editada Código (4)','2020-03-31 21:17:55','2020-03-31 21:17:55'),(22,1,'Andres Ramirez','Módulo Proveedores','Proveedor Eliminado Cédula/Rif (9148869)','2020-03-31 21:22:33','2020-03-31 21:22:33'),(23,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Editar Desperdicio - Internal Server Error [500].]','2020-04-01 03:20:16','2020-04-01 03:20:16'),(24,1,'Andres Ramirez','Módulo Compras','Despericio añadido - Código de Compra (1)','2020-04-01 17:49:58','2020-04-01 17:49:58'),(25,NULL,'Error en el Sistema','Módulo Compras','Error al almacenar desperdicio - Código SQL [42S22]','2020-04-01 17:50:39','2020-04-01 17:50:39'),(26,1,'Andres Ramirez','Módulo Compras','Despericio añadido - Código de Compra (2)','2020-04-01 17:51:14','2020-04-01 17:51:14'),(27,NULL,'Error en el Sistema','Módulo Compras','Error al almacenar desperdicio - Código SQL [42S22]','2020-04-01 17:51:28','2020-04-01 17:51:28'),(28,NULL,'Error en el Sistema','Módulo Compras','Error al almacenar desperdicio - Código SQL [42S22]','2020-04-01 17:52:24','2020-04-01 17:52:24'),(29,1,'Andres Ramirez','Módulo Compras','Despericio añadido - Código de Compra (1)','2020-04-01 17:56:02','2020-04-01 17:56:02'),(30,1,'Andres Ramirez','Módulo Compras','Despericio añadido - Código de Compra (2)','2020-04-01 17:56:31','2020-04-01 17:56:31'),(31,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-01 20:58:02','2020-04-01 20:58:02'),(32,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-01 20:58:28','2020-04-01 20:58:28'),(33,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-01 21:02:07','2020-04-01 21:02:07'),(34,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-01 21:03:13','2020-04-01 21:03:13'),(35,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-01 21:03:20','2020-04-01 21:03:20'),(36,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-01 21:06:41','2020-04-01 21:06:41'),(37,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-01 21:13:53','2020-04-01 21:13:53'),(38,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-01 21:14:04','2020-04-01 21:14:04'),(39,1,'Andres Ramirez','Módulo Compras','Compra Eliminada - Código (1)','2020-04-01 21:14:26','2020-04-01 21:14:26'),(40,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (5)','2020-04-01 21:16:09','2020-04-01 21:16:09'),(41,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-01 21:16:21','2020-04-01 21:16:21'),(42,1,'Andres Ramirez','Módulo Compras','Compra Eliminada - Código (5)','2020-04-01 21:17:18','2020-04-01 21:17:18'),(43,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (6)','2020-04-01 21:18:07','2020-04-01 21:18:07'),(44,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (7)','2020-04-01 21:18:42','2020-04-01 21:18:42'),(46,1,'Andres Ramirez','Módulo Compras','Compra Eliminada - Código (7)','2020-04-01 21:20:26','2020-04-01 21:20:26'),(47,1,'Andres Ramirez','Módulo Compras','Compra Eliminada - Código (6)','2020-04-01 21:23:57','2020-04-01 21:23:57'),(48,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (8)','2020-04-01 21:25:17','2020-04-01 21:25:17'),(49,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (9)','2020-04-01 21:25:47','2020-04-01 21:25:47'),(50,1,'Andres Ramirez','Módulo Compras','Compra Eliminada - Código (9)','2020-04-01 21:25:54','2020-04-01 21:25:54'),(51,1,'Andres Ramirez','Módulo Compras','Compra Eliminada - Código (8)','2020-04-01 21:25:54','2020-04-01 21:25:54'),(52,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (10)','2020-04-02 19:10:07','2020-04-02 19:10:07'),(53,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (11)','2020-04-02 19:23:04','2020-04-02 19:23:04'),(54,1,'Andres Ramirez','Módulo Compras','Pago añadido - Código de Compra (10)','2020-04-02 19:23:57','2020-04-02 19:23:57'),(55,1,'Andres Ramirez','Módulo Logística','Producto Editado Código (7)','2020-04-02 20:36:46','2020-04-02 20:36:46'),(56,1,'Andres Ramirez','Módulo Logística','Producto Editado Código (7)','2020-04-02 20:36:58','2020-04-02 20:36:58'),(57,1,'Andres Ramirez','Módulo Compras','Pago Editado - Código de Compra (2)','2020-04-03 02:05:34','2020-04-03 02:05:34'),(58,1,'Andres Ramirez','Módulo Compras','Pago Editado - Código de Compra (2)','2020-04-03 02:07:12','2020-04-03 02:07:12'),(59,1,'Andres Ramirez','Módulo Compras','Pago Editado - Código de Compra (2)','2020-04-03 02:10:08','2020-04-03 02:10:08'),(60,1,'Andres Ramirez','Módulo Compras','Pago Editado - Código de Compra (2)','2020-04-03 02:11:21','2020-04-03 02:11:21'),(61,1,'Andres Ramirez','Módulo Compras','Pago Editado - Código de Compra (2)','2020-04-03 02:12:42','2020-04-03 02:12:42'),(62,1,'Andres Ramirez','Módulo Compras','Pago Editado - Código de Compra (2)','2020-04-03 02:12:59','2020-04-03 02:12:59'),(63,1,'Andres Ramirez','Módulo Logística','Suministro Eliminado - Código (8)','2020-04-05 18:34:42','2020-04-05 18:34:42'),(64,1,'Andres Ramirez','Módulo Logística','Suministro Eliminado - Código (9)','2020-04-05 18:34:42','2020-04-05 18:34:42'),(65,1,'Andres Ramirez','Módulo Logística','Suministro Editado - Código (3)','2020-04-05 22:12:18','2020-04-05 22:12:18'),(66,1,'Andres Ramirez','Módulo Logística','Suministro Editado - Código (3)','2020-04-05 22:12:39','2020-04-05 22:12:39'),(67,1,'Andres Ramirez','Módulo Logística','Suministro Añadido Código (3)','2020-04-05 22:19:33','2020-04-05 22:19:33'),(68,1,'Andres Ramirez','Módulo Logística','Suministro Añadido Código (7)','2020-04-05 22:21:57','2020-04-05 22:21:57'),(69,1,'Andres Ramirez','Módulo Logística','Suministro Editado - Código (14)','2020-04-05 22:22:11','2020-04-05 22:22:11'),(70,1,'Andres Ramirez','Módulo Logística','Suministro Editado - Código (14)','2020-04-05 22:22:22','2020-04-05 22:22:22'),(71,1,'Andres Ramirez','Módulo Logística','Inventario Eliminado - Código (1)','2020-04-05 23:29:53','2020-04-05 23:29:53'),(72,1,'Andres Ramirez','Módulo Logística','Producto Editado Código (9)','2020-04-05 23:31:23','2020-04-05 23:31:23'),(73,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (2)','2020-04-06 15:28:57','2020-04-06 15:28:57'),(74,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (2)','2020-04-06 15:29:06','2020-04-06 15:29:06'),(75,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (2)','2020-04-06 15:29:25','2020-04-06 15:29:25'),(76,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (2)','2020-04-06 15:32:50','2020-04-06 15:32:50'),(77,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (2)','2020-04-06 15:32:56','2020-04-06 15:32:56'),(78,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (2)','2020-04-06 15:35:08','2020-04-06 15:35:08'),(79,1,'Andres Ramirez','Módulo Logística','Producto Editado Código (9)','2020-04-06 16:59:08','2020-04-06 16:59:08'),(80,1,'Andres Ramirez','Módulo Logística','Inventario Añadido Código (4)','2020-04-06 18:12:34','2020-04-06 18:12:34'),(81,1,'Andres Ramirez','Módulo Clientes','Cliente Añadido Cédula/Rif (9169478)','2020-04-06 20:09:27','2020-04-06 20:09:27'),(82,1,'Andres Ramirez','Módulo Clientes','Cliente Añadido Cédula/Rif (159753456)','2020-04-06 20:20:51','2020-04-06 20:20:51'),(83,1,'Andres Ramirez','Módulo Clientes','Cliente Editado Cédula/Rif (159753456)','2020-04-06 20:58:37','2020-04-06 20:58:37'),(84,1,'Andres Ramirez','Módulo Clientes','Cliente Editado Cédula/Rif (159753456)','2020-04-06 20:59:20','2020-04-06 20:59:20'),(85,1,'Andres Ramirez','Módulo Ventas','Venta Añadida - Código (5)','2020-04-07 00:52:24','2020-04-07 00:52:24'),(86,1,'Andres Ramirez','Módulo Ventas','Venta Añadida - Código (6)','2020-04-07 01:00:03','2020-04-07 01:00:03'),(87,1,'Andres Ramirez','Módulo Ventas','Venta Añadida - Código (7)','2020-04-07 01:00:49','2020-04-07 01:00:49'),(88,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (7)','2020-04-07 02:11:59','2020-04-07 02:11:59'),(89,1,'Andres Ramirez','Módulo Ventas','Pago añadido - Código de Venta (7)','2020-04-07 02:22:31','2020-04-07 02:22:31'),(90,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (7)','2020-04-07 02:22:55','2020-04-07 02:22:55'),(91,1,'Andres Ramirez','Módulo Ventas','Pago Editado - Código de Venta (7)','2020-04-07 17:49:21','2020-04-07 17:49:21'),(92,1,'Andres Ramirez','Configuracion','Usuario Añadido - Id de Usuario (4)','2020-04-10 18:05:18','2020-04-10 18:05:18'),(93,1,'Andres Ramirez','Configuración','Usuario Eliminado - ID (4)','2020-04-10 18:06:10','2020-04-10 18:06:10'),(94,1,'Andres Ramirez','Configuración','Usuario Eliminado - ID (3)','2020-04-10 18:06:10','2020-04-10 18:06:10'),(95,NULL,'Error del Sistema','Configuración','Error al añadir trabajador - Código SQL [42S22]','2020-04-10 21:02:28','2020-04-10 21:02:28'),(96,NULL,'Error del Sistema','Configuración','Error al añadir trabajador - Código SQL [42S22]','2020-04-10 21:03:25','2020-04-10 21:03:25'),(97,1,'Andres Ramirez','Configuracion','Trabajador Añadido - Cedula (26163200)','2020-04-10 21:04:48','2020-04-10 21:04:48'),(98,1,'Andres Ramirez','Configuracion','Trabajador Añadido - Cedula (22724200)','2020-04-10 21:09:51','2020-04-10 21:09:51'),(99,1,'Andres Ramirez','Configuracion','Trabajador Añadido - Cedula (23567894)','2020-04-10 21:11:44','2020-04-10 21:11:44'),(100,1,'Andres Ramirez','Configuración','Trabajador Eliminado - Código (2)','2020-04-10 21:50:38','2020-04-10 21:50:38'),(101,1,'Andres Ramirez','Configuracion','Trabajador Añadido - Cedula (26707992)','2020-04-10 21:51:29','2020-04-10 21:51:29'),(102,1,'Andres Ramirez','Configuración','Trabajador Editado - Cédula (26707992)','2020-04-10 22:30:53','2020-04-10 22:30:53'),(103,1,'Andres Ramirez','Configuración','Trabajador Editado - Cédula (23567894)','2020-04-11 16:58:56','2020-04-11 16:58:56'),(104,1,'Andres Ramirez','Módulo Ventas','Despacho añadido - Código de Venta (7)','2020-04-11 17:29:18','2020-04-11 17:29:18'),(105,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-11 18:29:44','2020-04-11 18:29:44'),(106,1,'Andres Ramirez','Módulo Ventas','Despacho añadido - Código de Venta (6)','2020-04-11 18:32:29','2020-04-11 18:32:29'),(107,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-11 18:33:16','2020-04-11 18:33:16'),(108,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-11 18:34:01','2020-04-11 18:34:01'),(109,1,'Andres Ramirez','Módulo Ventas','Despacho Eliminado - Código de Venta (6)','2020-04-11 18:34:40','2020-04-11 18:34:40'),(110,1,'Andres Ramirez','Módulo Ventas','Despacho Eliminado - Código de Venta (7)','2020-04-11 18:34:40','2020-04-11 18:34:40'),(111,1,'Andres Ramirez','Módulo Ventas','Despacho añadido - Código de Venta (7)','2020-04-11 18:35:10','2020-04-11 18:35:10'),(112,1,'Andres Ramirez','Módulo Ventas','Despacho añadido - Código de Venta (5)','2020-04-11 18:39:50','2020-04-11 18:39:50'),(113,1,'Andres Ramirez','Módulo Ventas','Venta Eliminada - Código (5)','2020-04-11 18:40:08','2020-04-11 18:40:08'),(114,1,'Andres Ramirez','Módulo Ventas','Despacho Editado - Código de Venta (7)','2020-04-11 19:06:30','2020-04-11 19:06:30'),(115,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (2)','2020-04-11 19:07:48','2020-04-11 19:07:48'),(116,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (12)','2020-04-12 18:16:58','2020-04-12 18:16:58'),(117,1,'Andres Ramirez','Módulo Compras','Compra Añadida - Código (13)','2020-04-12 18:18:42','2020-04-12 18:18:42'),(118,1,'Andres Ramirez','Módulo Compras','Compra Eliminada - Código (13)','2020-04-12 18:19:04','2020-04-12 18:19:04'),(119,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-12 21:48:11','2020-04-12 21:48:11'),(120,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-12 21:51:23','2020-04-12 21:51:23'),(121,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-12 21:51:33','2020-04-12 21:51:33'),(122,1,'Andres Ramirez','Módulo Finanzas','Gasto o Costo Eliminado - Código (1)','2020-04-12 21:53:04','2020-04-12 21:53:04'),(123,1,'Andres Ramirez','Módulo Finanzas','Costo añadido - Código (2)','2020-04-12 22:06:49','2020-04-12 22:06:49'),(124,1,'Andres Ramirez','Módulo Finanzas','Costo añadido - Código (3)','2020-04-12 22:09:15','2020-04-12 22:09:15'),(125,1,'Andres Ramirez','Módulo Finanzas','Costo Editado - Código (2)','2020-04-12 22:28:34','2020-04-12 22:28:34'),(126,1,'Andres Ramirez','Módulo Finanzas','Gasto Editado - Código (2)','2020-04-12 22:29:01','2020-04-12 22:29:01'),(127,1,'Andres Ramirez','Módulo Finanzas','Pago de Nómina añadido - Código (1)','2020-04-14 19:47:49','2020-04-14 19:47:49'),(128,1,'Andres Ramirez','Módulo Finanzas','Pago de Nómina Editado - Código (1)','2020-04-14 20:45:11','2020-04-14 20:45:11'),(129,1,'Andres Ramirez','Módulo Finanzas','Pago de Nómina Editado - Código (1)','2020-04-14 20:45:48','2020-04-14 20:45:48'),(130,1,'Andres Ramirez','Módulo Finanzas','Pago de Nómina Editado - Código (1)','2020-04-14 20:46:00','2020-04-14 20:46:00'),(131,1,'Andres Ramirez','Módulo Finanzas','Pago de Nómina añadido - Código (2)','2020-04-14 20:49:42','2020-04-14 20:49:42'),(132,1,'Andres Ramirez','Módulo Finanzas','Pago de Nómina Eliminado - Código (2)','2020-04-14 20:50:02','2020-04-14 20:50:02'),(133,1,'Andres Ramirez','Módulo Compras','Pago Editado - Código de Compra (4)','2020-04-14 23:18:28','2020-04-14 23:18:28'),(134,1,'Andres Ramirez','Módulo Finanzas','Pago Editado - Código de Pago (3)','2020-04-14 23:20:20','2020-04-14 23:20:20'),(135,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 18:32:17','2020-04-15 18:32:17'),(136,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (2)','2020-04-15 18:33:10','2020-04-15 18:33:10'),(137,1,'Andres Ramirez','Módulo Logística','Suministro Editado - Código (7)','2020-04-15 18:33:52','2020-04-15 18:33:52'),(138,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 19:25:53','2020-04-15 19:25:53'),(139,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 19:26:16','2020-04-15 19:26:16'),(140,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:04:29','2020-04-15 20:04:29'),(141,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:06:39','2020-04-15 20:06:39'),(142,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:07:02','2020-04-15 20:07:02'),(143,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:07:25','2020-04-15 20:07:25'),(144,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:07:47','2020-04-15 20:07:47'),(145,1,'Andres Ramirez','Módulo Ventas','Venta Añadida - Código (8)','2020-04-15 20:09:07','2020-04-15 20:09:07'),(146,NULL,'Error en el Sistema','Eliminación de Registro','Mensaje de Error [Internal Server Error [500].]','2020-04-15 20:09:52','2020-04-15 20:09:52'),(147,1,'Andres Ramirez','Módulo Ventas','Venta Eliminada - Código (8)','2020-04-15 20:11:24','2020-04-15 20:11:24'),(148,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:13:21','2020-04-15 20:13:21'),(149,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:14:44','2020-04-15 20:14:44'),(150,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:15:07','2020-04-15 20:15:07'),(151,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:23:42','2020-04-15 20:23:42'),(152,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:26:27','2020-04-15 20:26:27'),(153,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:26:54','2020-04-15 20:26:54'),(154,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:44:47','2020-04-15 20:44:47'),(155,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:45:18','2020-04-15 20:45:18'),(156,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:48:12','2020-04-15 20:48:12'),(157,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:49:06','2020-04-15 20:49:06'),(158,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:50:44','2020-04-15 20:50:44'),(159,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:51:03','2020-04-15 20:51:03'),(160,1,'Andres Ramirez','Módulo Ventas','Venta Editada Código (6)','2020-04-15 20:51:12','2020-04-15 20:51:12'),(161,1,'Andres Ramirez','Módulo Logística','Suministro Editado - Código (16)','2020-04-15 21:10:27','2020-04-15 21:10:27'),(162,1,'Andres Ramirez','Módulo Logística','Suministro Editado - Código (16)','2020-04-15 21:10:49','2020-04-15 21:10:49'),(163,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (3)','2020-04-15 21:21:17','2020-04-15 21:21:17'),(164,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (3)','2020-04-15 21:21:29','2020-04-15 21:21:29'),(165,1,'Andres Ramirez','Módulo Logística','Inventario Editado - Código (2)','2020-04-15 21:21:39','2020-04-15 21:21:39'),(166,1,'Andres Ramirez','Módulo Logística','Suministro Editado - Código (4)','2020-04-15 21:22:08','2020-04-15 21:22:08'),(167,1,'Andres Ramirez','Módulo Logística','Suministro Editado - Código (10)','2020-04-15 21:22:45','2020-04-15 21:22:45'),(168,1,'Andres Ramirez','Módulo Ventas','Venta Añadida - Código (10)','2020-04-17 16:25:41','2020-04-17 16:25:41'),(169,1,'Andres Ramirez','Módulo Ventas','Despacho añadido - Código de Venta (6)','2020-04-17 16:55:21','2020-04-17 16:55:21'),(170,1,'Andres Ramirez','Módulo Ventas','Despacho Editado - Código de Venta (6)','2020-04-17 16:59:43','2020-04-17 16:59:43'),(171,1,'Andres Ramirez','Módulo Ventas','Pago añadido - Código de Venta (10)','2020-04-19 16:51:27','2020-04-19 16:51:27'),(172,1,'Andres Ramirez','Configuración','Usuario Editado - ID del Usuario (2)','2020-04-22 17:18:45','2020-04-22 17:18:45'),(173,1,'Andres Ramirez','Configuración','Usuario Editado - ID del Usuario (2)','2020-04-22 17:20:07','2020-04-22 17:20:07'),(174,1,'Andres Ramirez','Configuración','Usuario Editado - ID del Usuario (2)','2020-04-22 17:38:28','2020-04-22 17:38:28'),(175,1,'Andres Ramirez','Configuración','Usuario Editado - ID del Usuario (2)','2020-04-22 17:39:04','2020-04-22 17:39:04'),(176,1,'Andres Ramirez','Configuración','Usuario Editado - ID del Usuario (2)','2020-04-22 17:45:47','2020-04-22 17:45:47'),(177,1,'Andres Ramirez','Configuración','Usuario Editado - ID del Usuario (2)','2020-04-22 17:47:06','2020-04-22 17:47:06'),(178,1,'Andres Ramirez','Módulo Logística','Suministro Editado - Código (4)','2020-04-30 18:08:50','2020-04-30 18:08:50'),(179,1,'Andres Ramirez','Configuracion','Trabajador Añadido - Cedula (22652343)','2020-04-30 19:38:12','2020-04-30 19:38:12');
/*!40000 ALTER TABLE `incidencia` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `indicador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `indicador` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(255) NOT NULL,
  `referencia` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `indicador` WRITE;
/*!40000 ALTER TABLE `indicador` DISABLE KEYS */;
/*!40000 ALTER TABLE `indicador` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventario` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_producto` int(255) NOT NULL,
  `precio` double NOT NULL,
  `cantidad` double NOT NULL,
  `expedicion` date NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_inventario_producto` (`id_producto`),
  CONSTRAINT `fk_inventario_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventario` WRITE;
/*!40000 ALTER TABLE `inventario` DISABLE KEYS */;
INSERT INTO `inventario` VALUES (2,9,5000,785,'2020-04-20',NULL,'2020-04-15 21:21:39'),(3,4,500,1,'2020-04-20','2020-04-06 18:12:34','2020-04-17 16:25:41');
/*!40000 ALTER TABLE `inventario` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orden_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orden_producto` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_venta` int(255) DEFAULT NULL,
  `id_compra` int(255) DEFAULT NULL,
  `id_producto` int(255) NOT NULL,
  `cantidad` double NOT NULL,
  `precio` double NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_orden_producto_venta` (`id_venta`),
  KEY `fk_orden_producto_compra` (`id_compra`),
  KEY `fk_orden_producto_producto` (`id_producto`),
  CONSTRAINT `fk_orden_producto_compra` FOREIGN KEY (`id_compra`) REFERENCES `compra` (`id`),
  CONSTRAINT `fk_orden_producto_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id`),
  CONSTRAINT `fk_orden_producto_venta` FOREIGN KEY (`id_venta`) REFERENCES `venta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orden_producto` WRITE;
/*!40000 ALTER TABLE `orden_producto` DISABLE KEYS */;
INSERT INTO `orden_producto` VALUES (2,NULL,2,4,10,25,'2020-03-30 21:45:40','2020-03-30 21:45:40'),(3,NULL,2,7,50,1000,'2020-03-30 21:45:40','2020-03-30 21:45:40'),(4,NULL,3,5,10,156.45,'2020-03-30 21:51:35','2020-03-30 21:51:35'),(5,NULL,4,9,15,200,'2020-03-31 17:25:07','2020-03-31 17:25:07'),(6,NULL,4,2,5,250.5,'2020-03-31 17:25:07','2020-03-31 17:25:07'),(12,NULL,10,3,100.56,20,'2020-04-02 19:10:07','2020-04-02 19:10:07'),(13,NULL,11,1,1,1,'2020-04-02 19:23:04','2020-04-02 19:23:04'),(22,6,NULL,9,15,150.6,'2020-04-07 01:00:03','2020-04-07 01:00:03'),(23,7,NULL,9,100,845.23,'2020-04-07 01:00:49','2020-04-07 01:00:49'),(24,NULL,12,2,10,150,'2020-04-12 18:16:58','2020-04-12 18:16:58'),(28,10,NULL,4,3,5,'2020-04-17 16:25:41','2020-04-17 16:25:41');
/*!40000 ALTER TABLE `orden_producto` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pago` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `banco` varchar(255) NOT NULL,
  `referencia` varchar(255) NOT NULL,
  `fecha_pago` date NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pago` WRITE;
/*!40000 ALTER TABLE `pago` DISABLE KEYS */;
INSERT INTO `pago` VALUES (1,'Banco Mercantil','156456156','2020-03-30','2020-03-30 21:51:35','2020-03-31 02:36:16'),(2,'Banco de Venezuela','14562345','2020-03-28','2020-03-31 02:34:44','2020-04-03 02:12:59'),(3,'BOD','1789456789','2020-03-27','2020-03-31 17:33:53','2020-04-14 23:20:20'),(6,'BBVA Provincial','123456789','2020-04-02','2020-04-02 19:23:57','2020-04-02 19:23:57'),(7,'Banco Mercantil','7456321','2020-04-27','2020-04-07 02:22:31','2020-04-07 17:49:21'),(8,'BBVA Provincial','189456237','2020-04-14','2020-04-14 19:47:49','2020-04-14 19:47:49'),(10,'Banesco','76134968426','2020-04-19','2020-04-19 16:51:27','2020-04-19 16:51:27');
/*!40000 ALTER TABLE `pago` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pago_nomina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pago_nomina` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_trabajador` int(255) NOT NULL,
  `mes` date NOT NULL,
  `monto` double NOT NULL,
  `id_pago` int(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pago_nomina_trabajador` (`id_trabajador`),
  KEY `fk_pago_nomina_pago` (`id_pago`),
  CONSTRAINT `fk_pago_nomina_pago` FOREIGN KEY (`id_pago`) REFERENCES `pago` (`id`),
  CONSTRAINT `fk_pago_nomina_trabajador` FOREIGN KEY (`id_trabajador`) REFERENCES `trabajador` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pago_nomina` WRITE;
/*!40000 ALTER TABLE `pago_nomina` DISABLE KEYS */;
INSERT INTO `pago_nomina` VALUES (1,3,'2020-03-01',5800.186,8,'2020-04-14 19:47:49','2020-04-14 20:46:00');
/*!40000 ALTER TABLE `pago_nomina` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `producto` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `id_categoria` int(255) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_producto_categoria` (`id_categoria`),
  CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES (1,'Bolsa',3,'Bolsa plástica transparente',NULL,NULL),(2,'Manzana',1,'Manzana Roja del Campo','2020-03-29 23:04:21','2020-03-29 23:04:21'),(3,'Manzana Pelada',1,'Manzana lista para vender','2020-03-29 23:06:17','2020-03-29 23:06:17'),(4,'Manzana Congelada',2,'Lista para vender','2020-03-29 23:07:43','2020-03-29 23:07:43'),(5,'Pera Amarilla',3,'Pera para procesar otros alimentos de la industria','2020-03-29 23:11:01','2020-03-30 17:11:30'),(7,'Etiquetas con Logo',3,'Para colocar en los paquetes de envio','2020-03-29 23:19:35','2020-04-02 20:36:58'),(9,'Pera Naranja',1,'Buenarda Rara','2020-03-29 23:21:06','2020-04-05 23:31:23');
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `producto_receta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `producto_receta` (
  `id_producto_final` int(255) NOT NULL,
  `id_ingrediente` int(255) NOT NULL,
  `cantidad` double NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  KEY `fk_producto_receta_producto_final` (`id_producto_final`),
  KEY `fk_producto_receta_ingrediente` (`id_ingrediente`),
  CONSTRAINT `fk_producto_receta_ingrediente` FOREIGN KEY (`id_ingrediente`) REFERENCES `producto` (`id`),
  CONSTRAINT `fk_producto_receta_producto_final` FOREIGN KEY (`id_producto_final`) REFERENCES `producto` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `producto_receta` WRITE;
/*!40000 ALTER TABLE `producto_receta` DISABLE KEYS */;
INSERT INTO `producto_receta` VALUES (2,1,1,'2020-03-29 23:04:21','2020-03-29 23:04:21'),(3,1,1,'2020-03-29 23:06:17','2020-03-29 23:06:17'),(4,1,1,'2020-03-29 23:07:43','2020-03-29 23:07:43'),(4,2,0.5,'2020-03-29 23:07:43','2020-03-29 23:07:43'),(5,1,1,'2020-03-30 17:13:43','2020-03-30 17:13:43'),(9,1,60,'2020-04-06 16:59:07','2020-04-06 16:59:07');
/*!40000 ALTER TABLE `producto_receta` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `id_zona` int(255) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `telefono` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `tipo_cid` varchar(255) NOT NULL,
  `rif_cedula` varchar(255) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_proveedor_zona` (`id_zona`),
  CONSTRAINT `fk_proveedor_zona` FOREIGN KEY (`id_zona`) REFERENCES `zona` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (29,'Andres',2,'dusseldorf','0412-7942183','atencion@agrofrutas.com','V -','23868394','2020-03-27 20:55:47','2020-03-27 20:55:47'),(30,'Agrofrutas',1,'4145 SW 151st Terrace','5612297145','afs@assistant.com','J -','15648946','2020-03-27 23:33:15','2020-03-27 20:56:14'),(32,'Maribel',1,'Calle San Martin','0412-7942183','afs@assistants.com','V -','23789456','2020-03-29 17:01:22','2020-03-29 17:01:22'),(33,'Nestor Semedo',2,'dusseldorf','0412-7942183','atencion@agro.com','V -','23868395','2020-03-30 16:36:20','2020-03-30 16:36:20');
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reporte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reporte` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_user` int(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `tipo` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reporte_users` (`id_user`),
  CONSTRAINT `fk_reporte_users` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reporte` WRITE;
/*!40000 ALTER TABLE `reporte` DISABLE KEYS */;
/*!40000 ALTER TABLE `reporte` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `suministro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suministro` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_compra` int(255) NOT NULL,
  `id_producto` int(255) NOT NULL,
  `id_proveedor` int(255) DEFAULT NULL,
  `precio` double NOT NULL,
  `cantidad` double NOT NULL,
  `expedicion` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_suministro_producto` (`id_producto`),
  KEY `fk_suministro_proveedor` (`id_proveedor`),
  CONSTRAINT `fk_suministro_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id`),
  CONSTRAINT `fk_suministro_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `suministro` WRITE;
/*!40000 ALTER TABLE `suministro` DISABLE KEYS */;
INSERT INTO `suministro` VALUES (1,2,4,30,25,10,'2020-03-30','2020-03-30 21:45:40','2020-03-30 21:45:40'),(2,2,7,30,1000,50,NULL,'2020-03-30 21:45:40','2020-03-30 21:45:40'),(3,3,5,33,156.45,100,'2020-06-30','2020-03-30 21:51:35','2020-04-05 22:12:39'),(4,4,9,29,200,15,'2020-06-30','2020-03-31 17:25:07','2020-04-30 18:08:50'),(6,5,5,30,100,10,'2020-06-01','2020-04-01 21:16:09','2020-04-01 21:16:09'),(7,6,1,30,1,1,'2020-04-16','2020-04-01 21:18:07','2020-04-15 18:33:52'),(10,9,1,29,20,11,NULL,'2020-04-01 21:25:47','2020-04-15 21:22:45'),(11,10,3,33,20,100.56,'2020-08-02','2020-04-02 19:10:07','2020-04-02 19:10:07'),(13,0,3,32,256.789,250.753,'2020-07-05','2020-04-05 22:19:33','2020-04-05 22:19:33'),(14,0,7,32,150,20,NULL,'2020-04-05 22:21:57','2020-04-05 22:22:22'),(15,0,1,30,15,10,NULL,NULL,NULL),(16,0,1,30,50,10,NULL,NULL,'2020-04-15 21:10:49'),(17,12,2,33,150,10,'2020-04-20','2020-04-12 18:16:58','2020-04-12 18:16:58'),(18,13,4,29,255.55,50,'2020-06-12','2020-04-12 18:18:42','2020-04-12 18:18:42');
/*!40000 ALTER TABLE `suministro` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `trabajador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trabajador` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(255) NOT NULL,
  `cedula` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `apellido` varchar(255) NOT NULL,
  `telefono` varchar(255) NOT NULL,
  `banco` varchar(255) NOT NULL,
  `num_cuenta` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `trabajador` WRITE;
/*!40000 ALTER TABLE `trabajador` DISABLE KEYS */;
INSERT INTO `trabajador` VALUES (1,'Despachador','26163200','Robert','Sosa','0412-7942183','Banco Mercantil','0105-0715-156423-06139-9','2020-04-10 21:04:48','2020-04-10 21:04:48'),(3,'Despachador','23567894','Nestor','Sánchez','9546707656','BOD','0116-0442-10-021345648','2020-04-10 21:11:44','2020-04-11 16:58:56'),(4,'Mantenimiento','26707992','Katyan','Seekatz','5612297145','Banesco','0134-037325-3732-07475-6','2020-04-10 21:51:29','2020-04-10 22:30:53'),(5,'Operador','22652343','Miguel','Gil','0414-3836100','Bancamiga','357951234682','2020-04-30 19:38:12','2020-04-30 19:38:12');
/*!40000 ALTER TABLE `trabajador` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `permiso_logistica` tinyint(1) DEFAULT NULL,
  `permiso_compra` tinyint(1) DEFAULT NULL,
  `permiso_venta` tinyint(1) DEFAULT NULL,
  `permiso_finanzas` tinyint(1) DEFAULT NULL,
  `permiso_cliente` tinyint(1) DEFAULT NULL,
  `permiso_proveedor` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','andres28ramirez','$2y$10$voIH0kdLeXOChao..ClJLuwJGKIQ/65Yn3VkrwWHJ.Nmzar3j.7Sy','Andres Ramirez',1,1,1,1,1,1,'2020-02-23 23:46:38','2020-02-23 23:46:38',NULL),(2,'admin secundario','mmduque9296','$2y$10$SQPLr2e.fWw0Yf7WztiKsu9eEwioi7a3TLXnY7K.wEIzxJ/POPQL6','Mercedes Duque',1,0,0,1,0,0,'2020-04-10 17:22:31','2020-04-22 17:48:26',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `venta` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(255) NOT NULL,
  `id_pago` int(255) DEFAULT NULL,
  `fecha` date NOT NULL,
  `monto` double NOT NULL,
  `credito` int(255) NOT NULL,
  `pendiente` tinyint(1) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_venta_cliente` (`id_cliente`),
  KEY `fk_venta_pago` (`id_pago`),
  CONSTRAINT `fk_venta_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`),
  CONSTRAINT `fk_venta_pago` FOREIGN KEY (`id_pago`) REFERENCES `pago` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `venta` WRITE;
/*!40000 ALTER TABLE `venta` DISABLE KEYS */;
INSERT INTO `venta` VALUES (6,1,NULL,'2020-03-14',2620.44,30,0,'2020-04-07 01:00:03','2020-04-15 20:51:12'),(7,2,7,'2020-04-10',98046.68,3,1,'2020-04-07 01:00:49','2020-04-07 02:22:55'),(10,2,10,'2020-04-18',17.4,30,1,'2020-04-17 16:25:41','2020-04-19 16:51:27');
/*!40000 ALTER TABLE `venta` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `zona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zona` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `zona` WRITE;
/*!40000 ALTER TABLE `zona` DISABLE KEYS */;
INSERT INTO `zona` VALUES (1,'Porlamar'),(2,'Pampatar');
/*!40000 ALTER TABLE `zona` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

