<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="col-12">
                <ul class="nav nav-tabs">
                    <?php echo $__env->yieldContent('tabs'); ?>
                </ul>
            </div>

            <div class="card">
                <div class="card-body" style="background-color: rgba(255,255,255,0.4)">
                    <?php echo $__env->yieldContent('info'); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/layouts/principal.blade.php ENDPATH**/ ?>