@extends('layouts.principal')

@section('title','Calendario · Fatto a Casa')

@section('titulo','VER - CALENDARIO')

@section('tabs')
    <ul class="nav nav-tabs">
        <li class="nav-item">
        <a class="nav-link text-dark active font-weight-bold" href=" {{ url('/Calendario')}}">Calendario</a>
        </li>
    </ul>
@endsection

@section('CalendarScripts')

    <link href="{{ asset('fullcalendar/core/main.css') }}" rel="stylesheet">
    <link href="{{ asset('fullcalendar/daygrid/main.css') }}" rel="stylesheet">
    <link href="{{ asset('fullcalendar/list/main.css') }}" rel="stylesheet">
    <link href="{{ asset('fullcalendar/timegrid/main.css') }}" rel="stylesheet">

 

    <script type="text/javascript" src="{{ asset('fullcalendar/core/main.js') }}"></script>

    <script type="text/javascript" src="{{ asset('fullcalendar/interaction/main.js') }}"></script>

    <script type="text/javascript" src="{{ asset('fullcalendar/daygrid/main.js') }}"></script>
    <script type="text/javascript" src="{{ asset('fullcalendar/list/main.js') }}"></script>
    <script type="text/javascript" src="{{ asset('fullcalendar/timegrid/main.js') }}"></script>
    <script src="{{ asset('js/form_validate.js') }}"></script>
    <script src="{{ asset('js/calendar_validate.js') }}"></script>


    <!-- Funcionalidades y uso de Fullcalendar-->
    <script>

        document.addEventListener('DOMContentLoaded', function() {
          var calendarEl = document.getElementById('calendar');
  
          var calendar = new FullCalendar.Calendar(calendarEl, {
  
              
                plugins: [ 'dayGrid', 'interaction','timeGrid', 'list',],

                //themeSystem: 'standard',
                //defaultView: 'timeGridDay',
  
                header:{
                    left:'prev,next today MiBoton',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth',
                },
  
                customButtons:{
  
                    MiBoton:{
                        text:"Agregar",
                        click:function(){

                            limpiarFormulario();

                            $('#eventoLargo').modal('toggle');
                            $("#btnAgregar").show();
                            $("#btnModificar").hide();
                            $("#btnEliminar").hide();
                            $(".id").hide();
                            $("#txtFecha").removeAttr('disabled');

                            $('#txtCliente').hide();
                            $('#txtProveedor').hide();
                            $('#txtempleado').hide();

                            $('#Clientebtn').show();
                            $('#Proveedorbtn').show();
                            $('#Empleadobtn').show();
                            $('.l1').hide();
                            $('.l2').hide();
                            $('.l3').hide();


                                                    
                        }
                    }
                },
  
                dateClick: function(info){
  
                    limpiarFormulario();

                    $('#txtFecha').val(info.dateStr);
                    $('#exampleModal').modal();
                    $("#btnAgregar").show();
                    $("#btnModificar").hide();
                    $("#btnEliminar").hide();
                    $(".id").hide();
                    $("#txtFecha").prop( "disabled", true );

                    $('#Clientebtn').show();
                    $('#Proveedorbtn').show();
                    $('#Empleadobtn').show();

                            
                    $('#txtCliente').hide();
                    $('#txtProveedor').hide();
                    $('#txtempleado').hide();
                    $('.l1').hide();
                    $('.l2').hide();
                    $('.l3').hide();

                },
  
                eventClick:function(info){

                    $("#btnAgregar").hide();
                    $("#btnModificar").show();
                    $("#btnEliminar").show();
                    $(".id").hide();
                    $("#txtFecha").removeAttr('disabled');

                    $('#Clientebtn').show();
                    $('#Proveedorbtn').show();
                    $('#Empleadobtn').show();

                    
                    $('#txtCliente').hide();
                    $('#txtProveedor').hide();
                    $('#txtempleado').hide();
                    $('.l1').hide();
                    $('.l2').hide();
                    $('.l3').hide();
                    
                    console.log(info);
                    console.log(info.event.title);
                    console.log(info.event.start);

                    console.log(info.event.end);
                    console.log(info.event.backgroundColor);
                    console.log(info.event.extendedProps.descripcion);
                    console.log(info.event.extendedProps.cliente_id);
                    console.log(info.event.extendedProps.proveedor_id);
                    console.log(info.event.extendedProps.trabajador_id);

                    $('#txtID').val(info.event.id);
                    $('#txtTitulo').val(info.event.title);
                    $('#txtColor').val(info.event.backgroundColor);
                    $('#txtDescripcion').val(info.event.extendedProps.descripcion);

                    mes = (info.event.start.getMonth()+1);
                    dia = (info.event.start.getDate());
                    anio = (info.event.start.getFullYear());

                    mes = (mes<10)?"0"+mes:mes;
                    dia = (dia<10)?"0"+dia:dia;

                    minutos=info.event.start.getMinutes();
                    hora=info.event.start.getHours();

                    minutos = (minutos<10)?"0"+minutos:minutos;
                    hora = (hora<10)?"0"+hora:hora;

                    hora = (hora+":"+minutos);

                    $('#txtFecha').val(anio+"-"+mes+"-"+dia);
                    $('#txtHora').val(hora);

                    

                    $('#exampleModal').modal();

                },    
          
                events: "{{ url('/Calendario/show')}}"
          
    });

         
  
            calendar.setOption('locale', 'es');
    
            calendar.render();

            $('#btnAgregar').click(function(){
            objEvento = recolectarDatosGUI("POST");
            EnviarInformacion('', objEvento, 'post');
            });   

            $('#btnEliminar').click(function(){
                objEvento=recolectarDatosGUI("DELETE");
                EnviarInformacion('/'+$('#txtID').val(), objEvento);
            });

            $('#btnModificar').click(function(){
                objEvento = recolectarDatosGUI("PATCH");
                EnviarInformacion('/'+$('#txtID').val(), objEvento);
            });
       

            function recolectarDatosGUI(method){

                nuevoEvento={
                    id: $('#txtID').val(),
                    title: $('#txtTitulo').val(),
                    descripcion: $('#txtDescripcion').val(),
                    start: $('#txtFecha').val()+" "+$('#txtHora').val(),
                    end: $('#txtFecha').val()+" "+$('#txtHora').val(),
                    color: $('#txtColor').val(),
                    cliente_id: $('#txtCliente').val(),
                    proveedor_id: $('#txtProveedor').val(),
                    trabajador_id: $('#txtempleado').val(),
                    activo: '0',

                    '_token':$("meta[name='csrf-token']").attr("content"),
                    '_method': method
                }
                return(nuevoEvento);
            }

            function EnviarInformacion(accion, objEvento, metodo){
                if (metodo === 'post'){


                    
                    /*if($('#txtDescripcion').val("")){
                        alert('la descripcion no puede estar vacia');
                        return false;
                   /* if($('#txtProveedor').val("") || $('txtCliente').val("") || $('txtEmpleado').va("")){
                        alert('Tiene que elgir un Proveedor, cliente o empleado')
                        return false;*/
                   /*}*/

                }
                $.ajax(
                    {
                    type: "POST",
                    url:"{{ url('/Calendario') }}"+accion,
                    data: objEvento,
                    success: function(msg){
                    console.log(msg);

                    $('#exampleModal').modal('toggle');
                        calendar.refetchEvents();
                    },
                    error: function(){ 
                    alert("Hay un error");
                    },
                    }
                );
            }


        function limpiarFormulario()
        {
            //
            $('#txtID').val(""),
            $('#txtTitulo').val(""),
            $('#txtDescripcion').val(""),
            $('#txtFecha').val("")
            $('#txtHora').val("07:00")
            $('#txtColor').val("");
            $('#txtCliente').val("");
            $('#txtProveedor').val("");
            $('#txtempleado').val("");
           


        }
  
         });

        </script>

        <script>

        </script>

    <!-- Este script es para manejar los clientes/proveedores/empleados
         y sus respectivos iconos -->
        <script>
            $(document).ready(function(){
                $("#Clientebtn").click(function(){
                    $('#Clientebtn').hide();
                    $('#Proveedorbtn').hide();
                    $('#Empleadobtn').hide();
                    $('#txtCliente').show();
                    $('.l1').show();
                    $('.l2').hide();
                    $('.l3').hide();

            });
            $("#Proveedorbtn").click(function(){
                    $('#Clientebtn').hide();
                    $('#Proveedorbtn').hide();
                    $('#Empleadobtn').hide();
                    $('#txtProveedor').show();
                    $('.l1').hide();
                    $('.l2').show();
                    $('.l3').hide();

            });
            $("#Empleadobtn").click(function(){
                    $('#Clientebtn').hide();
                    $('#Proveedorbtn').hide();
                    $('#Empleadobtn').hide();
                    $('#txtempleado').show();
                    $('.l1').hide();
                    $('.l2').hide();
                    $('.l3').show();

            });
            
            });
        </script>

@endsection


@section('info')

    <div class="container">
        <div class="row">
            <div class="col"></div>
            <div class="col-12"> 
            <div id="calendar"></div> 
            </div>
            <div class="col"></div>
        </div>
    </div>

        <!-- Modal -->
    <!--<option style="background-color:red; color:white; font-weight:bold;" value="">Eliminar Cliente<option>-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog " role="document">
            <div class="modal-content" >
                <div class="modal-header" style="background-color:#F6FAF5; border-bottom: 2px rgba(2,137,54,0.6) solid;
                ">
                <h5 class="modal-title" style="margin:0 auto; font-weight:bold; color:#028936;font-size:1.4rem;" id="exampleModalLabel">CALENDARIO</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">

                <div class="form-row">

                <div class="id">
                    ID: <br>
                    <input type="text" name="txtID" id="txtID">
                </div>
                    <div class="form-group col-md-12">
                    <label>Tipo de evento:</label> 
                        <div class="input-group">
                            <div class="d-flex">
                                <div class="m-auto form-control icon-box text-center">
                                    <i class="fa fa-users fa-lg m-auto"></i>
                                </div>
                            </div>
                            <select class="form-control" style="font-weight:bold;height: calc(2.19rem + 10px)" name="txtTitulo" id="txtTitulo" required>
                                <option selected value="">Selecciona el evento</option>
                                <option value="Reunión">Reunión</option>
                                <option value="Despacho">Despacho</option>
                                <option value="Compra">Compra</option>
                                <option value="Venta">Venta</option>
                                <option value="Viaje">Viaje</option>
                                <option value="Pago de Nómina">Pago de Nómina</option>
                                <option value="Vacaciones">Vacaciones</option>
                                <option value="Otra">Otra</option>
                            </select>     
                        </div>
                    
                    </div>

                    <div class="form-group col-md-8">
                    <label>Fecha:</label>
                        <div class="input-group">
                            <div class="d-flex">
                                <div class="m-auto form-control icon-box text-center">
                                    <i class="fa fa-calendar-check-o fa-lg m-auto"></i>
                                </div>
                            </div>
                            <input required type="date" style="height: calc(2.19rem + 10px)" class="form-control" name="txtFecha" id="txtFecha">
                        </div>
                    </div>

                    <div class="form-group col-md-4">
                    <label >Hora:</label>
                        <div class="input-group">
                            <div class="d-flex">
                                <div class="m-auto form-control icon-box text-center">
                                    <i class="fa fa-calendar-check-o fa-lg m-auto"></i>
                                </div>
                            </div>
                            <input type="time" style="height: calc(2.19rem + 10px)" min="07:00" step="60" max="19:00" class="form-control" name="txtHora" id="txtHora">
                        </div>
                    </div>

                    <div class="form-group col-md-12">
                    <label>Descripcion:</label>
                    <textarea  class="form-control" name="txtDescripcion" id="txtDescripcion" rows="3" required></textarea>
                    </div>

                    <div class="col-md-12">
                        <div class="container content-center">
                            <div class="row">
                                <div class="col ">
                                    <button id="Clientebtn" class="btn btn-secondary">Clientes</button>
                                </div>
                                <div class="col">
                                    <button  id="Empleadobtn" class="btn btn-secondary">Empleados</button>
                                </div>
                                <div class="col">
                                    <button id="Proveedorbtn" class="btn btn-secondary">Proveedores</button>   
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group col-md-12 content-center">
                        <div class="input-group l1">
                            <div class="d-flex">
                                <div class="m-auto form-control icon-box text-center">
                                    <i class="fa fa-users fa-lg m-auto"></i>
                                </div>
                            </div>
                            <select class="form-control req-true" style="font-weight:bold;height: calc(2.19rem + 10px);" name="txtCliente" id="txtCliente">
                                <option selected value="">Listado de Clientes</option>
                                @foreach ($clients as $cliente)
                                    <option value="{{ $cliente->id }}">{{ $cliente->nombre }}</option>
                                @endforeach 
                            </select>
                        </div>
                    </div>

                    <div class="form-group col-md-12 content-center">
                        <div class="input-group l2">
                            <div class="d-flex">
                                <div class="m-auto form-control icon-box text-center">
                                    <i class="fa fa-users fa-lg m-auto"></i>
                                </div>
                            </div>
                            <select class="form-control req-true" style="font-weight:bold;height: calc(2.19rem + 10px)" name="txtProveedor" id="txtProveedor">
                                <option selected value="">Listado de Proveedores</option>
                                @foreach ($providers as $prov)
                                    <option value="{{ $prov->id }}">{{ $prov->nombre }}</option>
                                @endforeach
                            </select> 
                        </div>
                    </div>

                    <div class="form-group col-md-12 content-center">
                        <div class="input-group l3">
                            <div class="d-flex">
                                <div class="m-auto form-control icon-box text-center">
                                    <i class="fa fa-users fa-lg m-auto"></i>
                                </div>
                            </div>
                            <select class="form-control req-true" style="font-weight:bold;height: calc(2.19rem + 10px)" name="txtempleado" id="txtempleado">
                                <option selected  value="">Listado de Empleados</option>
                                @foreach ($employers as $emp)
                                    <option value="{{ $emp->id }}">{{ $emp->nombre }}</option>
                                @endforeach
                            </select> 
                        </div>
                    </div>

                    <div class="form-group col-md-12">
                        <label>Color del Evento:</label> 
                            <div class="input-group">
                                <div class="d-flex">
                                    <div class="m-auto form-control icon-box text-center">
                                        <i class="fa fa-pencil-square-o fa-lg m-auto"></i>
                                    </div>
                                </div>
                                <select required class="form-control" style="font-weight:bold;height: calc(2.19rem + 10px)" name="txtColor" id="txtColor">
                                    <option selected value="">Selecciona un color</option>
                                    <option style="color:#0000FF;" value="#0000FF">Azul</option>
                                    <option style="color:#FF8000;" value="#FF8000">Naranja</option>
                                    <option style="color:#00FFFF;" value="#00FFFF">Aqua</option>
                                    <option style="color:#FF0000 ;" value="#FF0000 ">Rojo</option>
                                    <option style="color:#3ADF00;" value="#3ADF00">Verde</option>
                                    <option style="color:#800080;" value="#800080">Morado</option>
                                    <option style="color:#FF0080;" value="#FF0080">Fucsia</option>
                                    <option style="color:#FFFF00;" value="#FFFF00">Amarillo</option>
                                </select>     
                            </div>
                        
                        </div>                   
                </div>
                </div>
                <div class="modal-footer">

                    <button id="btnAgregar" class="btn btn-success">Agregar</button>
                    <button  id="btnModificar" class="btn btn-warning">Modificar</button>
                    <button id="btnEliminar" class="btn btn-danger">Borrar</button>
                    <button id="btnCancelar" data-dismiss="modal" class="btn btn-secondary">Cancelar</button>
                </div>
            </div>
            </div>
    </div>

    <!--·······································································································································································
    #########################       Modal para añadir un evento largo       ###################################################################################################
    ········································································································································································-->
    <div class="modal fade" id="eventoLargo" tabindex="-1" role="dialog" aria-labelledby="eventoLargo" aria-hidden="true">
        <div class="modal-dialog " role="document">
        <div class="modal-content" >
            <div class="modal-header" style="background-color:#F6FAF5; border-bottom: 2px rgba(2,137,54,0.6) solid;
            ">
            <h5 class="modal-title" style="margin:0 auto; font-weight:bold; color:#028936;font-size:1.4rem;" id="exampleModalLabel">CALENDARIO</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <form action="">
                @csrf
                <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label>Tipo de evento:</label> 
                                <div class="input-group">
                                    <div class="d-flex">
                                        <div class="m-auto form-control icon-box text-center">
                                            <i class="fa fa-users fa-lg m-auto"></i>
                                        </div>
                                    </div>
                                    <select class="form-control" style="font-weight:bold;height: calc(2.19rem + 10px)" name="txtTitulo" id="txtTitulo" required>
                                        <option selected value="">Selecciona el evento</option>
                                        <option value="Reunión">Reunión</option>
                                        <option value="Despacho">Despacho</option>
                                        <option value="Compra">Compra</option>
                                        <option value="Venta">Venta</option>
                                        <option value="Viaje">Viaje</option>
                                        <option value="Pago de Nómina">Pago de Nómina</option>
                                        <option value="Vacaciones">Vacaciones</option>
                                        <option value="Otra">Otra</option>
                                    </select>     
                                </div>
                            
                            </div>
        
                            <div class="form-group col-md-8">
                                <label>Fecha de inicio:</label>
                                    <div class="input-group">
                                        <div class="d-flex">
                                            <div class="m-auto form-control icon-box text-center">
                                                <i class="fa fa-calendar-check-o fa-lg m-auto"></i>
                                            </div>
                                        </div>
                                        <input required type="date" style="height: calc(2.19rem + 10px)" class="form-control" name="txtFecha" id="txtFecha">
                                    </div>
                            </div>
        
                            <div class="form-group col-md-4">
                                <label >Hora:</label>
                                    <div class="input-group">
                                        <div class="d-flex">
                                            <div class="m-auto form-control icon-box text-center">
                                                <i class="fa fa-calendar-check-o fa-lg m-auto"></i>
                                            </div>
                                        </div>
                                        <input type="time" style="height: calc(2.19rem + 10px)" min="07:00" step="60" max="19:00" class="form-control" name="txtHora" id="txtHora">
                                    </div>
                            </div>
                            <div class="form-group col-md-8">
                                <label>Fecha final:</label>
                                    <div class="input-group">
                                        <div class="d-flex">
                                            <div class="m-auto form-control icon-box text-center">
                                                <i class="fa fa-calendar-check-o fa-lg m-auto"></i>
                                            </div>
                                        </div>
                                        <input required type="date" style="height: calc(2.19rem + 10px)" class="form-control" name="txtFechafinal" id="txtFechaFinal">
                                    </div>
                            </div>
        
                            <div class="form-group col-md-4">
                                <label >Hora:</label>
                                    <div class="input-group">
                                        <div class="d-flex">
                                            <div class="m-auto form-control icon-box text-center">
                                                <i class="fa fa-calendar-check-o fa-lg m-auto"></i>
                                            </div>
                                        </div>
                                        <input type="time" style="height: calc(2.19rem + 10px)" min="07:00" step="60" max="19:00" class="form-control" name="txtHoraFinal" id="txtHoraFinal">
                                    </div>
                            </div>
        
                            <div class="form-group col-md-12">
                                <label>Descripcion:</label>
                                <textarea  class="form-control" name="txtDescripcion" id="txtDescripcion" rows="3" required></textarea>
                            </div>
        
                            <div class="col-md-12">
                                <div class="container content-center">
                                    <div class="row">
                                        <div class="col ">
                                            <button id="Clientebtn" class="btn btn-secondary">Clientes</button>
                                        </div>
                                        <div class="col">
                                            <button  id="Empleadobtn" class="btn btn-secondary">Empleados</button>
                                        </div>
                                        <div class="col">
                                            <button id="Proveedorbtn" class="btn btn-secondary">Proveedores</button>   
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group col-md-12 content-center">
                                <div class="input-group l1">
                                    <div class="d-flex">
                                        <div class="m-auto form-control icon-box text-center">
                                            <i class="fa fa-users fa-lg m-auto"></i>
                                        </div>
                                    </div>
                                    <select class="form-control req-true" style="font-weight:bold;height: calc(2.19rem + 10px);" name="txtCliente" id="txtCliente">
                                        <option selected value="">Listado de Clientes</option>
                                        @foreach ($clients as $cliente)
                                            <option value="{{ $cliente->id }}">{{ $cliente->nombre }}</option>
                                        @endforeach 
                                    </select>
                                </div>
                            </div>
        
                            <div class="form-group col-md-12 content-center">
                                <div class="input-group l2">
                                    <div class="d-flex">
                                        <div class="m-auto form-control icon-box text-center">
                                            <i class="fa fa-users fa-lg m-auto"></i>
                                        </div>
                                    </div>
                                    <select class="form-control req-true" style="font-weight:bold;height: calc(2.19rem + 10px)" name="txtProveedor" id="txtProveedor">
                                        <option selected value="">Listado de Proveedores</option>
                                        @foreach ($providers as $prov)
                                            <option value="{{ $prov->id }}">{{ $prov->nombre }}</option>
                                        @endforeach
                                    </select> 
                                </div>
                            </div>
        
                            <div class="form-group col-md-12 content-center">
                                <div class="input-group l3">
                                    <div class="d-flex">
                                        <div class="m-auto form-control icon-box text-center">
                                            <i class="fa fa-users fa-lg m-auto"></i>
                                        </div>
                                    </div>
                                    <select class="form-control req-true" style="font-weight:bold;height: calc(2.19rem + 10px)" name="txtempleado" id="txtempleado">
                                        <option selected  value="">Listado de Empleados</option>
                                        @foreach ($employers as $emp)
                                            <option value="{{ $emp->id }}">{{ $emp->nombre }}</option>
                                        @endforeach
                                    </select> 
                                </div>
                            </div>

                            <div class="form-group col-md-12">
                                <label>Color del Evento:</label> 
                                    <div class="input-group">
                                        <div class="d-flex">
                                            <div class="m-auto form-control icon-box text-center">
                                                <i class="fa fa-pencil-square-o fa-lg m-auto"></i>
                                            </div>
                                        </div>
                                        <select required class="form-control" style="font-weight:bold;height: calc(2.19rem + 10px)" name="txtColor" id="txtColor">
                                            <option selected value="">Selecciona un color</option>
                                            <option style="color:#0000FF;" value="#0000FF">Azul</option>
                                            <option style="color:#FF8000;" value="#FF8000">Naranja</option>
                                            <option style="color:#00FFFF;" value="#00FFFF">Aqua</option>
                                            <option style="color:#FF0000 ;" value="#FF0000 ">Rojo</option>
                                            <option style="color:#3ADF00;" value="#3ADF00">Verde</option>
                                            <option style="color:#800080;" value="#800080">Morado</option>
                                            <option style="color:#FF0080;" value="#FF0080">Fucsia</option>
                                            <option style="color:#FFFF00;" value="#FFFF00">Amarillo</option>
                                        </select>     
                                    </div>
                                
                                </div>  
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="btnAgregar" class="btn btn-success">Agregar</button>
                    <button id="btnCancelar" data-dismiss="modal" class="btn btn-secondary">Cancelar</button>
                </div>
            </form>
        </div>
        </div>
    </div>
    <!--·······································································································································································
    ########################        Fin del Modal para añadir un evento largo       ###################################################################################################
    ···········································································································································································-->

@endsection

@section('scripts')

<script>

    //ACOMODO LA BARRA DE NAVEGACION
    $("#icon").addClass("active");
    $("#icon").removeClass("icono_head");
    $(".icon").removeClass("icono_color");

</script>

@endsection