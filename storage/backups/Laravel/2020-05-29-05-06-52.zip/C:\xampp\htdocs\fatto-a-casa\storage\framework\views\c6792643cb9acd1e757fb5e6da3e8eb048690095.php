<div class="modal fade" id="<?php echo e($data['modal-id']); ?>" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-center" id="titulo"><?php echo e($data['title']); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- INFORMACIÓN PRODUCTO A PRODUCTO -->
                <div class="form-row justify-content-center">
                    <div class="col-12 p-2" >
                        <div class="input-group row justify-content-center">
                            <div class="col-4">
                                <!-- PRODUCTO -->
                                <strong>Producto:</strong>
                            </div>
                            <div class="col">
                                <!-- CANTIDAD -->
                                <strong>Cantidad:</strong>
                            </div>
                            <div class="col">
                                <!-- PRECIO -->
                                <strong>Precio:</strong>
                            </div>
                            <div class="col">
                            <!-- DESPERDICIO -->
                            <strong>Desperdicio:</strong>
                        </div> 
                        </div>
                                                 
                    </div>
                    
                    <div class="form-group form-control col-12 p-0" style="height: calc(2.19rem + 10px)">
                        <div class="input-group row justify-content-center">
                            <div class="d-flex col-4" style="border-right: 1px solid #ced4da; overflow: hidden">
                            <!-- PRODUCTO -->
                                <div class="my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                                    <span>Fresas</span>
                                </div>
                            </div>
                            <div class="d-flex col" style="border-right: 1px solid #ced4da; overflow: hidden">
                            <!-- CANTIDAD -->
                                <div class="my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                                    <span>20 Kg</span>
                                </div>
                            </div>
                            <div class="d-flex col" style="border-right: 1px solid #ced4da; overflow: hidden">
                                <!-- CANTIDAD -->
                                    <div class="my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                                        <span>60000 bs</span>
                                    </div>
                                </div>
                            
                                <input class="d-flex col my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                                
                            </div>
                        </div>                          
                    </div>  
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/includes/detail_desperdicio.blade.php ENDPATH**/ ?>