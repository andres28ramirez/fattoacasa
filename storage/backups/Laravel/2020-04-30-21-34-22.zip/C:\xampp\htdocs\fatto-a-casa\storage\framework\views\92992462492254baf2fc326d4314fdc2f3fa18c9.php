<div class="form-title">
    <span class="form-title2">
        <?php echo e($data['title']); ?>

    </span>
</div>

<div class="container-forms">
    <div class="container">

    <form method="POST" action="<?php echo e($data['action']); ?>" class="validate-form" id="<?php echo e($data['form-id']); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-row justify-content-center p-t-20">
            <?php $__currentLoopData = $data['form-components']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group col-md-6" id="input-<?php echo e($input['id_name']); ?>">
                    <label><?php echo e($input['label-name']); ?>:</label>
                    <div class="input-group validate-input" data-validate="<?php echo e($input['validate']); ?>">
                        <div class="d-flex">
                            <div class="m-auto form-control icon-box text-center">
                                <i class="fa <?php echo e($input['icon']); ?> fa-lg m-auto"></i>
                            </div>
                        </div>
                            <input 
                                class="form-control input100 <?php echo e($input['requerido']); ?> <?php echo e($errors->has($input['id_name']) ? ' is-invalid' : ''); ?>" 
                                style="height: calc(2.19rem + 10px)"
                                type="<?php echo e($input['type']); ?>" 
                                id="<?php echo e($input['id_name']); ?>"
                                name="<?php echo e($input['id_name']); ?>" 
                                placeholder="<?php echo e($input['placeholder']); ?>"
                                value="<?php echo e(old($input['id_name'])); ?>"
                                step = "any"
                                disabled
                            >
                </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    <div class="m-t-30 m-b-20" style="border-bottom: 2px grey solid;">
        <h3>Productos</h3>

    </div>
    <div class="form-row justify-content-center">
        <div class="col-10 p-2" >
            <div class="input-group row justify-content-center">
                <div class="col-4">
                    <!-- PRODUCTO -->
                    <strong>Producto:</strong>
                </div>
                <div class="col">
                    <!-- CANTIDAD -->
                    <strong>Precio:</strong>
                </div>
                <div class="col">
                    <!-- PRECIO -->
                    <strong>Cantidad:</strong>
                </div>
                <div class="col">
                <!-- DESPERDICIO -->
                <strong>Caducidad:</strong>
            </div> 
            </div>                        
        </div>
        <div class="col-2 ">

        </div>
        <?php for($i = 0; $i < 3; $i++): ?>
        

        <div class="form-group form-control col-10 p-0" style="height: calc(2.19rem + 10px)">
            <div class="input-group row justify-content-center">
                <div class="d-flex col-4" style="border-right: 1px solid #ced4da; overflow: hidden">
                <!-- PRODUCTO -->
                    <div class="my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                        <span>Fresas</span>
                    </div>
                </div>
                <div class="d-flex col" style="border-right: 1px solid #ced4da; overflow: hidden">
                <!-- CANTIDAD -->
                    <div class="my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                        <span>20 Kg</span>
                    </div>
                </div>
                <div class="d-flex col" style="border-right: 1px solid #ced4da; overflow: hidden">
                    <!-- CANTIDAD -->
                        <div class="my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                            <span>60000 bs</span>
                        </div>
                    </div>
                
                    <input class="d-flex col my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                    
                </div>
            </div> 
            <div class="col-2 ">
                <div class="productos ">
                    <div class="eliminar">
                        <i class="fa fa-trash fa-lg m-auto"></i>
                    </div>
        
                    <div class="add">
                        <i class="fa fa-plus fa-lg m-auto"></i>
                    </div>
                </div>
            </div>    

        <?php endfor; ?>
    </div>

    <div class="m-t-30 m-b-20" style="border-bottom: 2px grey solid;">

    </div>
    <div class="form-row m-t-30">

        <div class="col-12">
                <div class="form-row justify-content-left p-t-20">
                    <?php $__currentLoopData = $data['components-despacho']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group col-md-6" id="input-<?php echo e($input['id_name']); ?>">
                            <label><?php echo e($input['label-name']); ?>:</label>
                            <div class="input-group validate-input" data-validate="<?php echo e($input['validate']); ?>">
                                <div class="d-flex">
                                    <div class="m-auto form-control icon-box text-center">
                                        <i class="fa <?php echo e($input['icon']); ?> fa-lg m-auto"></i>
                                    </div>
                                </div>
                                <?php if($input['component-type']=="select"): ?>
                                    <select name="<?php echo e($input['id_name']); ?>" 
                                            id="<?php echo e($input['id_name']); ?>" 
                                            class="form-control input100 <?php echo e($input['requerido']); ?> <?php echo e($errors->has($input['id_name']) ? ' is-invalid' : ''); ?>" 
                                            style="height: calc(2.19rem + 10px)" >
                                        <option selected value=""><?php echo e($input['title']); ?></option>
                                        <?php $__currentLoopData = $input['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                                <?php if($input['component-type']=="input"): ?>
                                    <input 
                                        class="form-control input100 <?php echo e($input['requerido']); ?> <?php echo e($errors->has($input['id_name']) ? ' is-invalid' : ''); ?>" 
                                        style="height: calc(2.19rem + 10px)"
                                        type="<?php echo e($input['type']); ?>" 
                                        id="<?php echo e($input['id_name']); ?>"
                                        name="<?php echo e($input['id_name']); ?>" 
                                        placeholder="<?php echo e($input['placeholder']); ?>"
                                        value="<?php echo e(old($input['id_name'])); ?>"
                                        step = "any"
                                    >
                                <?php endif; ?>
                        </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        </div>
    </div>

    
                
    <div class="form-row m-t-60">

        <div class="col-12">
            <div class="bordes">
                <div>Total Base Bs: 500000</div>
                <div>IVA: 60000</div>
                <div class="bordes2">TOTAL: 560000</div>
            </div>
        </div>
    </div>

        
     
            
            

    </div>



<!-- BOTONES DE AGREGAR O ECHAR PARA ATRAS -->
<div class="d-flex justify-content-end mt-2 p-20 final" >
    <div class="">
        <button class="btn table-buttons px-5" style="background-color: rgba(2,137,54,0.6);">AGREGAR</button>
    </div>

    <div class="mx-2">
        <button class="btn table-buttons px-5" style="background-color: red;" >CANCELAR</button>
    </div>
</div> 
</form>
</div>
       <?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/includes/despacho_edit.blade.php ENDPATH**/ ?>