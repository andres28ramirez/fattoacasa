<div class="form-title">
    <span class="form-title2">
        <?php echo e($data['title']); ?>

    </span>
</div>

<div class="container-forms">
    <form method="POST" action="<?php echo e($data['action'] ? route($data['action']) : ''); ?>" class="validate-form" id="<?php echo e($data['form-id']); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-row justify-content-center">
            <?php $__currentLoopData = $data['form-components']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <div class="form-group col-md-6" id="input-<?php echo e($input['id_name']); ?>">
                    <label><?php echo e($input['label-name']); ?>:</label>
                    <div class="input-group validate-input" data-validate="<?php echo e($input['validate']); ?>">
                        <?php if($input['component-type']!="checkbox"): ?>
                            <div class="d-flex">
                                <div class="m-auto form-control icon-box text-center">
                                    <i class="fa <?php echo e($input['icon']); ?> fa-lg m-auto"></i>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($input['component-type']=="input"): ?>
                            <?php if($input['id_name'] == "form-cid"): ?>
                                <strong class='text-dark float-left my-auto'>
                                    <select name="tipo_cid" 
                                            class="form-control icon-box bg-transparent" 
                                            style="width: fit-content; border-radius: 0px">
                                        <option value="V -">V -</option>
                                        <option value="E -">E -</option>
                                        <option value="J -">J -</option>
                                    </select>
                                </strong>
                            <?php endif; ?>
                            <input 
                                class="form-control input100 <?php echo e($input['requerido']); ?> <?php echo e($errors->has($input['form_name']) ? ' is-invalid' : ''); ?>" 
                                style="height: calc(2.19rem + 10px)"
                                type="<?php echo e($input['type']); ?>" 
                                id="<?php echo e($input['id_name']); ?>"
                                name="<?php echo e($input['form_name']); ?>" 
                                placeholder="<?php echo e($input['placeholder']); ?>"
                                value="<?php echo e(old($input['form_name'])); ?>"
                                step = "any"
                            >
                        <?php elseif($input['component-type']=="select"): ?>
                            <select name="<?php echo e($input['form_name']); ?>" 
                                    id="<?php echo e($input['id_name']); ?>" 
                                    class="form-control input100 <?php echo e($input['requerido']); ?> <?php echo e($errors->has($input['form_name']) ? ' is-invalid' : ''); ?>" 
                                    style="height: calc(2.19rem + 10px)" >
                                <option selected value=""><?php echo e($input['title']); ?></option>
                                <?php $__currentLoopData = $input['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($option['value']); ?>"><?php echo e($option["nombre"]); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php elseif($input['component-type']=="textarea"): ?>
                            <textarea 
                                class="form-control input100 <?php echo e($input['requerido']); ?>"
                                style="height: calc(2.19rem + 10px)"
                                id="<?php echo e($input['id_name']); ?>"
                                name="<?php echo e($input['form_name']); ?>"
                                placeholder="<?php echo e($input['placeholder']); ?>"
                            ></textarea>
                        <?php elseif($input['component-type']=="checkbox"): ?>
                        <div class="form-control input100 <?php echo e($input['requerido']); ?>" style="height: fit-content">
                            <?php $__currentLoopData = $input['check-options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" 
                                            type="checkbox" 
                                            id="cb-<?php echo e($option['label']); ?>"
                                            name="<?php echo e($option['name']); ?>"
                                            value="1"
                                            <?php echo e($option['value'] ? "checked" : ""); ?>>
                                    <label class="form-check-label" for="cb-<?php echo e($option['label']); ?>">
                                        <?php echo e($option["label"]); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                        <span class="focus-input100"></span>
                        <?php if($errors->has($input['form_name'])): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong>El campo ya se encuentra registrado</strong>
                            </span>
                        <?php endif; ?>
                    </div>                          
                </div>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>  
        
        <?php if(isset($data['type'])): ?>
            <div class="card-header bg-transparent text-center pb-1 mb-3">
                Recetario del Producto
            </div>

            <div class="form-row justify-content-center">
                <div id="recetario-<?php echo e($data['form-id']); ?>" class="col-12">
                    <div class="form-group col-12 row justify-content-center" id="1">
                        <div class="col-6 p-0">
                            <!-- PRODUCTO -->
                            <label>Producto:</label>
                            <div class="input-group validate-input" data-validate="Producto es requerido">
                                <select name="form-producto-1" 
                                        id="form-producto-1" 
                                        class="form-control border-right req-false" 
                                        style="height: calc(2.19rem + 10px)" required>
                                    <option selected value="">Selecciona una Opción</option>
                                    <?php $__currentLoopData = $data_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product['value']); ?>"><?php echo e($product["nombre"]); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-5 p-0">
                            <!-- CANTIDAD -->
                            <label>Cantidad (Kg / Und):</label>
                            <div class="input-group validate-input" data-validate="Cantidad es requerida">
                                <input 
                                    class="form-control border-left req-false form-cantidad" 
                                    style="height: calc(2.19rem + 10px)"
                                    type="text" 
                                    id="form-cantidad-1"
                                    name="form-cantidad-1" 
                                    placeholder="Ingrese el nombre del producto"
                                    min='0'
                                    step="any"
                                >
                            </div>
                        </div>
                        <div class="col-lg d-flex p-0">
                            <button id="" class="btn table-buttons m-auto" onclick="borrar(1)">
                                <i class="fa fa-trash font-weight-bold"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="form-group col-12">
                    <div id="agregar-<?php echo e($data['form-id']); ?>" style="cursor: pointer; width: fit-content">
                        <i class="fa fa-plus-square fa-lg m-auto"></i>
                        <a>Agregar Producto...</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="form-row btn-submit">
            <div class="m-auto"> 
                <button class="form-btn" id="submit-<?php echo e($data['form-id']); ?>">Enviar</button>
            </div>
        </div>
        <?php if(isset($data['add-id'])): ?>    
            <input type="hidden" name="id" id="add-id-<?php echo e($data['form-id']); ?>" value="<?php echo e($data['add-id']); ?>">
        <?php endif; ?>
    </form>
    <input type="hidden" id="" class="id-form" value="<?php echo e($data['form-id']); ?>">
</div>

<script src="<?php echo e(asset('js/form_validate.js')); ?>"></script>
<script>
    var agregar = "agregar-<?php echo e($data['form-id']); ?>";
    var recetario = "recetario-<?php echo e($data['form-id']); ?>";
    var cantidad = 2;
    
    $("#"+agregar).click(function() {
        html = "<div class='form-group col-12 row justify-content-center' id="+cantidad+">";
        html +=   "<div class='col-6 p-0'>";
        html +=       "<label>Producto:</label>";
        html +=        "<div class='input-group validate-input' data-validate='Producto es requerido'>";
        html +=           "<select name='form-producto-"+cantidad+"'"; 
        html +=                   " id='form-producto-"+cantidad+"'"; 
        html +=                   " class='form-control input100 border-right req-false'"; 
        html +=                   " style='height: calc(2.19rem + 10px)' >";
                        <?php if(isset($data_products)): ?>
                            <?php $__currentLoopData = $data_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        html +=                 "<option value='<?php echo e($product['value']); ?>'><?php echo e($product['nombre']); ?></option>";
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
        html +=            "</select>";
        html +=        "</div>";
        html +=    "</div>";
        html +=    "<div class='col-5 p-0'>";
        html +=        "<label>Cantidad (Kg / Und):</label>";
        html +=        "<div class='input-group validate-input' data-validate='Producto es requerido'>";
        html +=            "<input class='form-control input100 border-left req-false form-cantidad'"; 
        html +=                " style='height: calc(2.19rem + 10px)' type='number'"; 
        html +=                " id='form-cantidad-"+cantidad+"' name='form-cantidad-"+cantidad+"'"; 
        html +=                " value='0' placeholder='Ingrese la cantidad del producto' min='0' step='any'>";
        html +=        "</div>";
        html +=    "</div>";
        html +=    "<div class='col-lg d-flex p-0'>";
        html +=        "<button class='btn table-buttons m-auto' onclick='borrar("+cantidad+")'>";
        html +=            "<i class='fa fa-trash font-weight-bold'></i>";
        html +=        "</button>";
        html +=    "</div>";
        html +="</div>";

        $("#"+recetario).append(html);
        cantidad++;
    });

	function borrar(codigo){
		$("#"+codigo).remove();
	}
</script><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/includes/general_form.blade.php ENDPATH**/ ?>