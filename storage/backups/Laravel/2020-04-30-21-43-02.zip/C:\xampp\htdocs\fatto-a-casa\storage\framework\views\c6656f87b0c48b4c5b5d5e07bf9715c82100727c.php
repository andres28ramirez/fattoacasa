<?php $__env->startSection('title','Logística · Fatto a Casa'); ?>

<?php $__env->startSection('titulo','FATTO A CASA - INVENTARIO'); ?>

<?php $__env->startSection('tabs'); ?>
    <ul class="nav nav-tabs opciones">
        <li class="nav-item">
            <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('list-inventario')); ?>">Inventario</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-suministro')); ?>">Suministro</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-producto')); ?>">Portafolio de Productos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-recetario')); ?>">Recetario de Productos</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('info'); ?>

    <!-- SCRIPT PARA REDIRECCIÓN BOTONES DE LA TABLA -->
    <script>
        function redirect_table(e){
            switch (e) {
                case "agregar":
                    $('#table-agregar').modal(true);
                    break;
                case "filtrar":
                    $('#table-filter').modal(true);
                    break;
                case "eliminar":
                    alert("ACOMODAR TABLA PARA QUE ELIMINE LOS VALORES DADOS");
                    break;
                case "registros":
                    alert("ACOMODAR TABLA A CANTIDAD DE REGISTROS");
                    break;
                case "print":
                    alert("IMPRIMIR LA TABLA TAL Y COMO ESTE FILTRADA O NO");
                    break;
                default:
                    alert("DEFAULT");
                    break;
            }
        }
    </script>

    <div class="row justify-content-center my-3 px-2">
        <?php
            $data_list = array(
                
                "table-id" => "lista-inventario",
                "title" => "",
                "pagina" => 1,
                "pagina-total" => 6,

                "titulos" => array(
                    "Producto",
                    "Precio",
                    "Cantidad",
                    "Fecha de Expiración",
                ),

                "content" => array( 
                    array(
                        "id" => 1,
                        "dato-1" => "Manzana Empaquetada",
                        "dato-2" => "25.000 Bs",
                        "cantidad-3" => "5",
                        "dato-4" => "30-02-2020",
                    ),array(
                        "id" => 2,
                        "dato-1" => "Pera Empaquetada",
                        "dato-2" => "25.000 Bs",
                        "cantidad-3" => "5",
                        "dato-4" => "30-02-2020",
                    ),
                    array(
                        "id" => 3,
                        "dato-1" => "Manzana Empaquetada",
                        "dato-2" => "25.000 Bs",
                        "cantidad-3" => "5",
                        "dato-4" => "30-02-2020",
                    ),
                    array(
                        "id" => 4,
                        "dato-1" => "Naranja Empaquetada",
                        "dato-2" => "25.000 Bs",
                        "cantidad-3" => "5",
                        "dato-4" => "30-02-2020",
                    ),
                ),
            );
        ?>
        <?php echo $__env->make('includes.general_table',['data'=>$data_list], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- MODAL PARA FILTRAR LA TABLA -->
    <div class="modal fade" id="table-filter" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="titulo">Filtrar Tabla</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                        $data_form = array(
                            "action" => "",
                            "title" => "",
                            "form-id" => "form-list-client",
                            
                            "form-components" => array(
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Periodo a Evaluar",
                                    "icon" => "fa-leanpub",
                                    "id_name" => "form-periodo",
                                    "title" => "Selecciona un periodo",
                                    "options" => array(
                                        "Mensual",
                                        "Trimestral",
                                        "Días de la Semana",
                                    ),
                                    "validate" => "Periodo es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Tiempo a Evaluar",
                                    "icon" => "fa-hourglass-half",
                                    "id_name" => "form-tiempo",
                                    "title" => "Selecciona un tiempo",
                                    "options" => array(
                                        "Año",
                                        "Específico",
                                        "Todos los años",
                                    ),
                                    "validate" => "Tiempo a evaluar es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Selecionar Año",
                                    "icon" => "fa-calendar-o",
                                    "type" => "number",
                                    "id_name" => "form-año",
                                    "placeholder" => "Ingrese el año deseado",
                                    "validate" => "Año es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Primera fecha",
                                    "icon" => "fa-calendar",
                                    "type" => "month",
                                    "id_name" => "form-fecha-1",
                                    "placeholder" => "",
                                    "validate" => "Primera fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Segunda fecha",
                                    "icon" => "fa-calendar",
                                    "type" => "month",
                                    "id_name" => "form-fecha-2",
                                    "placeholder" => "",
                                    "validate" => "Segunda fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                            ),
                        );
                    ?>
                    <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL PARA AGREGAR LA TABLA -->
    <div class="modal fade" id="table-agregar" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="titulo">Agregar un Nuevo Producto al Inventario</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                        $data_form = array(
                            "action" => "",
                            "title" => "",
                            "form-id" => "form-add-inv",
                            
                            "form-components" => array(
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Producto",
                                    "icon" => "fa-list-alt",
                                    "id_name" => "form-producto",
                                    "title" => "Selecciona un producto",
                                    "options" => array(
                                        "Listado de Productos",
                                    ),
                                    "validate" => "Producto es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Precio del Producto",
                                    "icon" => "fa-money",
                                    "type" => "text",
                                    "id_name" => "form-price",
                                    "placeholder" => "Ingrese el precio del producto",
                                    "validate" => "Precio es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Cantidad del Producto (Kg / Und)",
                                    "icon" => "fa-archive",
                                    "type" => "number",
                                    "id_name" => "form-cantidad",
                                    "placeholder" => "Ingrese la Cantidad",
                                    "validate" => "Cantidad es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Fecha de Expiración",
                                    "icon" => "fa-calendar",
                                    "type" => "date",
                                    "id_name" => "form-fecha",
                                    "placeholder" => "",
                                    "validate" => "Fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                            ),
                        );
                    ?>
                    <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL PARA EDITAR ALGO DE INVENTARIO -->
    <div class="modal fade" id="table-editar" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="titulo">Editar la Información del Producto</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                        $data_form = array(
                            "action" => "",
                            "title" => "",
                            "form-id" => "form-edit-inv",
                            
                            "form-components" => array(
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Producto",
                                    "icon" => "fa-list-alt",
                                    "id_name" => "form-producto",
                                    "title" => "Selecciona un producto",
                                    "options" => array(
                                        "Listado de Productos",
                                    ),
                                    "validate" => "Producto es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Precio del Producto",
                                    "icon" => "fa-money",
                                    "type" => "text",
                                    "id_name" => "form-price",
                                    "placeholder" => "Ingrese el precio del producto",
                                    "validate" => "Precio es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Cantidad del Producto (Kg / Und)",
                                    "icon" => "fa-archive",
                                    "type" => "text",
                                    "id_name" => "form-cantidad",
                                    "placeholder" => "Ingrese la Cantidad",
                                    "validate" => "Cantidad es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Fecha de Expiración",
                                    "icon" => "fa-calendar",
                                    "type" => "date",
                                    "id_name" => "form-fecha",
                                    "placeholder" => "",
                                    "validate" => "Fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                            ),
                        );
                    ?>
                    <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        //ACOMODO LA BARRA DE NAVEGACION
        $("#iv").addClass("active");
        $("#iv").removeClass("icono_head");
        $(".iv").removeClass("icono_color");
        
        //MODAL PARA MODIFICAR LA CANTIDAD
        $(".tr-lista-inventario").click(function() {
            var id = $(this).attr("id");
            $('#table-editar').modal(true);
        });

        //BORRO EL TITULO DE LOS FORMULARIOS DE FILTRADO
        $(".form-title").remove();

        //ELIMINO EL SOMBRIADO DEL FORMULARIO Y LOS BORDES
        $(".container-forms").css("border","0px");
        $(".container-forms").css("box-shadow","none");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/logistics/inventario/list.blade.php ENDPATH**/ ?>