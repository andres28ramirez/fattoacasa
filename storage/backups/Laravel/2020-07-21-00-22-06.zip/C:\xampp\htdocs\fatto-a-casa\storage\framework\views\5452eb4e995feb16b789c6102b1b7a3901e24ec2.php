<div class="rounded border">
    <div class="card-header py-3 d-flex">
        <h6 class="my-auto font-weight-bold" style="color: #333333; letter-spacing: 1px"><?php echo e($totals['texto']); ?></h6>
        <div class="my-auto ml-auto dropdown text-right">
            <?php if($totals['filtrar']): ?>
            <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa-2x fa fa-angle-down text-muted fa-lg"></i>
            </a>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <?php if($totals['filtrar']): ?>
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#progress-filter<?php echo e($totals['indicator']); ?>">Filtrar</a>
                <?php endif; ?>
                <a class="dropdown-item" href="#">Descargar</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body px-1 col-12" id="indicator-top-<?php echo e($totals['indicator']); ?>" style="overflow: auto">
        
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $percentaje = ($datos['cantidad']*100)/$totals['total'];
            ?>
            <h4 class="small font-weight-bold "><?php echo e($datos['text']); ?> 
                <span class="float-right"><?php echo e(number_format($datos['cantidad'],2, ",", ".")); ?></span>
            </h4>
            <div class="progress mb-4">
                <div 
                    class="progress-bar progress-bar-striped progress-bar-animated" 
                    role="progressbar" 
                    style="width: <?php echo e($percentaje); ?>%; background-color: <?php echo e($totals['bgColorProduct']); ?>" 
                    aria-valuenow="<?php echo e($percentaje); ?>" 
                    aria-valuemin="0" 
                    aria-valuemax="<?php echo e($totals['total']); ?>"
                >
                    <?php if($totals['porcentaje']): ?>
                        <?php echo e($percentaje); ?>%
                    <?php else: ?>
                        <?php echo e($datos['cantidad']); ?>

                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <h4 class="small font-weight-bold"><?php echo e($totals['total_text']); ?> 
            <span class="float-right"><?php echo e(number_format($totals['total'],2, ",", ".")); ?></span>
        </h4>
        <div class="progress">
            <div 
                class="progress-bar progress-bar-striped progress-bar-animated" 
                role="progressbar" 
                style="width: 100%; background-color: <?php echo e($totals['bgColorTotal']); ?>" 
                aria-valuenow="<?php echo e($totals['total']); ?>" 
                aria-valuemin="0" 
                aria-valuemax="<?php echo e($totals['total']); ?>"
            >
                <?php if($totals['porcentaje']): ?>
                    <?php echo e("100%"); ?>

                <?php else: ?>
                    <?php echo e($totals['total']); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- MODAL PARA FILTRAR EL GRÁFICO -->
<div class="modal fade" id="progress-filter<?php echo e($totals['indicator']); ?>" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-center" id="titulo">Filtrar Gráfico</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/includes/indicator_progress.blade.php ENDPATH**/ ?>