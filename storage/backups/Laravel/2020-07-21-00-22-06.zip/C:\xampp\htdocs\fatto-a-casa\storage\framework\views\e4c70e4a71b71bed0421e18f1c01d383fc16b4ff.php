<style>
    @media (max-width: 860px) {  
        #horizontalchart<?php echo e($data['canva']); ?>{
            height: 50px;
        }
    }

    @media (max-width: 550px) {  
        #horizontalchart<?php echo e($data['canva']); ?>{
            height: 40px;
        }
    }

    @media (max-width: 500px) {  
        #horizontalchart<?php echo e($data['canva']); ?>{
            height: 30px;
        }
    }

    @media (max-width: 400px) {  
        #horizontalchart<?php echo e($data['canva']); ?>{
            height: 20px;
        }
    }
</style>

<div class="rounded" id="indicator-es">
    <div class="card-header py-3 d-flex">
        <h6 class="my-auto font-weight-bold float-left" style="color: #333333; letter-spacing: 1px"><?php echo e($data['texto']); ?></h6>
        <div class="my-auto ml-auto dropdown text-right" id="horizontalbars-filter">
            <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa-2x fa fa-gear text-muted fa-lg"></i>
            </a>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item" href="#">Filtrar</a>
                <a class="dropdown-item download-indicator" type="horizontalchart<?php echo e($data['canva']); ?>" style="cursor: pointer">Descargar</a>
            </div>
        </div>
    </div>
    <div class="card-body px-1 text-center col-12 d-flex" id="canva-indicator-<?php echo e($data['canva']); ?>" title="<?php echo e($data['texto']); ?>" name="<?php echo e($data['texto']); ?>:">
        <div class="m-auto text-center col-12 horizontalchart-spinner">
            <i class="fa fa-5x fa-lg fa-spinner fa-spin" style="color: #028936"></i>
        </div>
        <canvas id="horizontalchart<?php echo e($data['canva']); ?>" height="<?php echo e($data['chartHeight']); ?>"></canvas>
        <input type="hidden" name="<?php echo e($data['canva']); ?>" class="canvadhbid" value="horizontalchart<?php echo e($data['canva']); ?>">

        <!-- VALORES QUE RECOJO PARA EL CHART -->
            <?php $__currentLoopData = $data['labels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" class="canvahdblabels<?php echo e($data['canva']); ?>" value="<?php echo e($labels); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- BAR 1 -->
            <input type="hidden" class="canvahdblabel1<?php echo e($data['canva']); ?>" value="<?php echo e($data['bar-label-1']); ?>">
            <?php $__currentLoopData = $data['bar-datos-1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" class="canvahdbdata1<?php echo e($data['canva']); ?>" value="<?php echo e($datos); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" class="canvahdbbgcolor1<?php echo e($data['canva']); ?>" value="<?php echo e($data['bar-bgcolors-1']); ?>">
            <input type="hidden" class="canvahdbbdcolor1<?php echo e($data['canva']); ?>" value="<?php echo e($data['bar-brcolors-1']); ?>">

            <!-- BAR 2 -->
            <input type="hidden" class="canvahdblabel2<?php echo e($data['canva']); ?>" value="<?php echo e($data['bar-label-2']); ?>">
            <?php $__currentLoopData = $data['bar-datos-2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" class="canvahdbdata2<?php echo e($data['canva']); ?>" value="<?php echo e($datos); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" class="canvahdbbgcolor2<?php echo e($data['canva']); ?>" value="<?php echo e($data['bar-bgcolors-2']); ?>">
            <input type="hidden" class="canvahdbbdcolor2<?php echo e($data['canva']); ?>" value="<?php echo e($data['bar-brcolors-2']); ?>">
    </div>
</div><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/includes/horizontal_bars.blade.php ENDPATH**/ ?>