<style>
    @media (max-width: 860px) {  
        #mixedlinebarchart<?php echo e($data['canva']); ?>{
            height: 50px;
        }
    }

    @media (max-width: 550px) {  
        #mixedlinebarchart<?php echo e($data['canva']); ?>{
            height: 40px;
        }
    }

    @media (max-width: 500px) {  
        #mixedlinebarchart<?php echo e($data['canva']); ?>{
            height: 30px;
        }
    }

    @media (max-width: 400px) {  
        #mixedlinebarchart<?php echo e($data['canva']); ?>{
            height: 20px;
        }
    }
</style>

<div class="rounded">
    <div class="card-header py-3 d-flex">
        <h6 class="my-auto font-weight-bold float-left" style="color: #333333; letter-spacing: 1px"><?php echo e($data['texto']); ?></h6>
        <div class="my-auto ml-auto dropdown text-right">
            <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa-2x fa fa-gear text-muted fa-lg"></i>
            </a>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#mixedlinebarchart-filter<?php echo e($data['canva']); ?>">Filtrar</a>
                <a class="dropdown-item download-indicator" type="mixedlinebarchart<?php echo e($data['canva']); ?>" style="cursor: pointer">Descargar</a>
            </div>
        </div>
    </div>
    <div class="card-body px-1 text-center col-12 d-flex" id="canva-indicator-<?php echo e($data['canva']); ?>" title="<?php echo e($data['texto']); ?>" name="<?php echo e($data['texto']); ?>:">
        <div class="m-auto text-center col-12 mixedlinebarchart-spinner">
            <i class="fa fa-5x fa-lg fa-spinner fa-spin" style="color: #028936"></i>
        </div>
        <canvas id="mixedlinebarchart<?php echo e($data['canva']); ?>" height="<?php echo e($data['chartHeight']); ?>"></canvas>
        <input type="hidden" name="<?php echo e($data['canva']); ?>" class="canvamlbid" value="mixedlinebarchart<?php echo e($data['canva']); ?>">

        <!-- VALORES QUE RECOJO PARA EL CHART -->
        <input type="hidden" class="canvatypemlbid<?php echo e($data['canva']); ?>" value="<?php echo e($data['type']); ?>">
        <?php $__currentLoopData = $data['labels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" class="canvamlblabels<?php echo e($data['canva']); ?>" value="<?php echo e($labels); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- BAR -->
        <input type="hidden" class="canvamlblabel1<?php echo e($data['canva']); ?>" value="<?php echo e($data['bar-label']); ?>">
        <?php $__currentLoopData = $data['bar-datos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" class="canvamlbdata1<?php echo e($data['canva']); ?>" value="<?php echo e($datos); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" class="canvamlbbgcolor1<?php echo e($data['canva']); ?>" value="<?php echo e($data['bar-bgcolors']); ?>">
        <input type="hidden" class="canvamlbbdcolor1<?php echo e($data['canva']); ?>" value="<?php echo e($data['bar-brcolors']); ?>">

        <!-- LABEL -->
        <input type="hidden" class="canvamlblabel2<?php echo e($data['canva']); ?>" value="<?php echo e($data['line-label']); ?>">
        <?php $__currentLoopData = $data['line-datos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" class="canvamlbdata2<?php echo e($data['canva']); ?>" value="<?php echo e($datos); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" class="canvamlbbgcolor2<?php echo e($data['canva']); ?>" value="<?php echo e($data['line-bgcolors']); ?>">
        <input type="hidden" class="canvamlbbdcolor2<?php echo e($data['canva']); ?>" value="<?php echo e($data['line-brcolors']); ?>">
    </div>
</div>

<!-- MODAL PARA FILTRAR EL GRÁFICO -->
<div class="modal fade" id="mixedlinebarchart-filter<?php echo e($data['canva']); ?>" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-center" id="titulo">Filtrar Gráfico</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/includes/mixed_barline.blade.php ENDPATH**/ ?>