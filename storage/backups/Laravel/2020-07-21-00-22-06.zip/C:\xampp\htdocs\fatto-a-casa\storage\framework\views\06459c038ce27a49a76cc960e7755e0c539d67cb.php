<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Descargar Reporte</title>
    <link rel="SHORTCUT ICON" href="<?php echo e(asset('img/logo.png')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
</head>

<style>
    @font-face {
        font-family: Poppins-Regular;
        src: url('../font/poppins/Poppins-Regular.ttf'); 
    }
    
    @font-face {
        font-family: Poppins-Medium;
        src: url('../font/poppins/Poppins-Medium.ttf'); 
    }
    
    @font-face {
        font-family: Poppins-Bold;
        src: url('../font/poppins/Poppins-Bold.ttf'); 
    }
    
    @font-face {
        font-family: Poppins-SemiBold;
        src: url('../font/poppins/Poppins-SemiBold.ttf'); 
    }

    .clearfix:after {
        content: "";
        display: table;
        clear: both;
    }

    a {
        color: #5D6975;
        text-decoration: underline;
    }

    body {
        position: relative;
        margin: 0 auto; 
        color: #001028;
        background: #FFFFFF; 
        font-family: Arial, sans-serif; 
        font-size: 12px; 
        font-family: Arial;
    }

    header {
        padding: 10px 0;
        margin-bottom: 30px;
    }

    #logo {
        /* text-align: center; */
        margin-bottom: 20px;
    }

    #logo img {
        height: 90px;
        width: 90px;
        float: left;
    }

    #project {
        padding-left: 33px;
    }

    #project span {
        color: #5D6975;
        text-align: right;
        width: 52px;
        margin-right: 10px;
        display: inline-block;
        font-size: 0.8em;
    }

    #company {
        height: 90px;
        float: left;
        padding-top: 10px;
        padding-left: 10px;
        vertical-align: middle;
    }

    #project div,
    #company div {
        white-space: nowrap;        
    }

    h1 {
        border-top: 1px solid  #495057;
        border-bottom: 1px solid  #495057;
        color: #495057;
        font-size: 2.4em;
        line-height: 1.4em;
        font-weight: normal;
        font-style: bold;
        text-align: center;
        margin: 0 0 -20px 0;
        background-color: #f9f6f1;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 20px;
    }

    table tr:nth-child(2n-1) td {
        background: #F5F5F5;
    }

    table th,
    table td {
        text-align: center;
    }

    table th {
        padding: 5px 20px;
        color: #5D6975;
        border-bottom: 1px solid #C1CED9;
        white-space: nowrap;        
        font-weight: normal;
    }

    table .service,
    table .desc {
        text-align: left;
    }

    table td {
        padding: 20px;
        text-align: center;
    }

    table td.service,
    table td.desc {
        vertical-align: top;
    }

    table td.unit,
    table td.qty,
    table td.total {
        font-size: 1.2em;
    }

    table td.grand {
        border-top: 1px solid #5D6975;;
    }

    #notices .notice {
        color: #5D6975;
        font-size: 1.2em;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(0,0,0,0.1);
    }

    footer {
        color: #5D6975;
        width: 100%;
        height: 30px;
        position: absolute;
        bottom: 0;
        border-top: 1px solid #C1CED9;
        padding: 8px 0;
        text-align: center;
    }
</style>

<!-- LAYOUT DEL PDF -->
<body>
    <header class="clearfix">
        <div id="logo">
            <img src="<?php echo e(asset('img/logo.png')); ?>">
            <div id="company">
                <div>Fatto a Casa C.A</div>
                <div>Calle Tamare, quinta Lina el Marques<br /> Caracas, Venezuela</div>
                <div>+58-212-237-7847</div>
                <div><a href="mailto:Infofattoacasa@gmail.com">Infofattoacasa@gmail.com</a></div>
            </div>
        </div>
        <h1 style="clear: both"><?php echo e($header); ?></h1>
    </header>
    <main>
        <div id="notices">
            <div>Usuario que generó el reporte: <strong><?php echo e(Auth::user()->name); ?></strong></div>
            <?php setlocale(LC_TIME, 'spanish'); ?>
            <div>Fecha de Emisión: <strong><?php echo e(strftime("%d de %B del %Y")); ?></strong></div><br>
            <div>Parámetros de Busqueda:</div>
            <div class="notice"><?php echo e($filtro); ?>.</div>
        </div>
        <table>
            <thead>
                <tr>
                    <?php $__currentLoopData = $titulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class=""><?php echo e($name); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="font-size: 8px">
                        <?php for($i = 1; $i <= count($titulos); $i++): ?>
                            <?php if(isset($row['dato-'.$i])): ?>  
                                <td class=""><?php echo e($row['dato-'.$i]); ?></td>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="<?php echo e(count($titulos)-1); ?>" class="grand total" style="text-align: right">Número de Registros:</td>
                    <td class="grand total"><?php echo e(count($datos)); ?></td>
                </tr>
            </tbody>
        </table>
    </main>
    <footer>Reporte generadó por computador y es inválido sin la firma y sellado del mismo.</footer>
  </body>
</html><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/layouts/pdf.blade.php ENDPATH**/ ?>