<style>
    @media (max-width: 550px) {  
        #singlehorizontalchart<?php echo e($data['canva']); ?>{
            height: 40px;
        }
    }

    @media (max-width: 500px) {  
        #singlehorizontalchart<?php echo e($data['canva']); ?>{
            height: 30px;
        }
    }

    @media (max-width: 400px) {  
        #singlehorizontalchart<?php echo e($data['canva']); ?>{
            height: 20px;
        }
    }
</style>

<div class="rounded">
    <div class="card-header py-3 d-flex">
        <h6 class="my-auto font-weight-bold float-left" style="color: #333333; letter-spacing: 1px"><?php echo e($data['texto']); ?></h6>
        <div class="my-auto ml-auto dropdown text-right">
            <a href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa-2x fa fa-gear text-muted fa-lg"></i>
            </a>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item download-indicator" type="singlehorizontalchart<?php echo e($data['canva']); ?>" style="cursor: pointer">Descargar</a>
            </div>
        </div>
    </div>
    <div class="card-body px-1 text-center col-12 d-flex" id="canva-indicator-<?php echo e($data['canva']); ?>" title="<?php echo e($data['texto']); ?>" name="<?php echo e($data['texto']); ?>:">
        <div class="m-auto text-center col-12 singlehorizontalchart-spinner">
            <i class="fa fa-5x fa-lg fa-spinner fa-spin" style="color: #028936"></i>
        </div>
        <canvas id="singlehorizontalchart<?php echo e($data['canva']); ?>"></canvas>
        <input type="hidden" name="<?php echo e($data['canva']); ?>" class="canvashbid" value="singlehorizontalchart<?php echo e($data['canva']); ?>">
        
        <!-- VALORES QUE RECOJO PARA EL CHART -->
        <input type="hidden" class="canvatypeshbid<?php echo e($data['canva']); ?>" value="<?php echo e($data['tipo']); ?>">
        <input type="hidden" class="canvashbbgcolors<?php echo e($data['canva']); ?>" value="<?php echo e($data['bgcolors']); ?>">
        <input type="hidden" class="canvashbbdcolors<?php echo e($data['canva']); ?>" value="<?php echo e($data['brcolors']); ?>">
        <?php $__currentLoopData = $data['datos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" class="canvashbdata<?php echo e($data['canva']); ?>" value="<?php echo e($datos); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $data['labels']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" class="canvashblabels<?php echo e($data['canva']); ?>" value="<?php echo e($labels); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/includes/single_horizontalbar.blade.php ENDPATH**/ ?>