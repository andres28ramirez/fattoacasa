<form method="POST" action="<?php echo e($data['action']); ?>" class="validate-form" id="<?php echo e($data['form-id']); ?>">
<?php echo csrf_field(); ?>

    <div class="form-row justify-content-center">
        <?php $__currentLoopData = $data['form-product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group col-12" id="input-<?php echo e($input['id_name']); ?>">
                <label><?php echo e($input['label-name']); ?>:</label>
                <div class="input-group validate-input" data-validate="<?php echo e($input['validate']); ?>">
                    <div class="d-flex">
                        <div class="m-auto form-control icon-box text-center">
                            <i class="fa <?php echo e($input['icon']); ?> fa-lg m-auto"></i>
                        </div>
                    </div>
                    <?php if($input['component-type']=="input"): ?>
                        <input 
                            class="form-control input100 <?php echo e($input['requerido']); ?>" 
                            style="height: calc(2.19rem + 10px)"
                            type="<?php echo e($input['type']); ?>" 
                            id="<?php echo e($input['id_name']); ?>"
                            name="<?php echo e($input['id_name']); ?>" 
                            placeholder="<?php echo e($input['placeholder']); ?>"
                            step = "any"
                        >
                    <?php elseif($input['component-type']=="select"): ?>
                        <select name="<?php echo e($input['id_name']); ?>" 
                                id="<?php echo e($input['id_name']); ?>" 
                                class="form-control input100 <?php echo e($input['requerido']); ?>" 
                                style="height: calc(2.19rem + 10px)" >
                            <option selected value=""><?php echo e($input['title']); ?></option>
                            <?php $__currentLoopData = $input['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php elseif($input['component-type']=="textarea"): ?>
                        <textarea 
                            class="form-control input100 <?php echo e($input['requerido']); ?>"
                            style="height: calc(2.19rem + 10px)"
                            id="<?php echo e($input['id_name']); ?>"
                            name="<?php echo e($input['id_name']); ?>"
                            placeholder="<?php echo e($input['placeholder']); ?>"
                        ></textarea>
                    <?php endif; ?>
                </div>                          
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>  

    <div class="card-header bg-transparent text-center pb-1 mb-3">
        Recetaria del Producto
    </div>

    <div class="form-row justify-content-center">
        <div id="recetario-<?php echo e($data['form-id']); ?>" class="col-12">
            <div class="form-group col-12 row justify-content-center" id="producto-1">
                <div class="col-6 p-0">
                    <!-- PRODUCTO -->
                    <label>Producto:</label>
                    <div class="input-group validate-input" data-validate="Producto es requerido">
                        <select name="form-producto" 
                                id="form-producto" 
                                class="form-control input100 border-right req-true" 
                                style="height: calc(2.19rem + 10px)" >
                            <option selected value="">Selecciona una Opción</option>
                            <option value="Todos">Todos los productos</option>
                        </select>
                    </div>
                </div>
                <div class="col-5 p-0">
                    <!-- CANTIDAD -->
                    <label>Cantidad (Kg / Und):</label>
                    <div class="input-group validate-input" data-validate="Producto es requerido">
                        <input 
                            class="form-control input100 border-left req-true" 
                            style="height: calc(2.19rem + 10px)"
                            type="text" 
                            id="form-cantidad"
                            name="form-cantidad" 
                            placeholder="Ingrese el nombre del producto"
                        >
                    </div>
                </div>
                <div class="col-lg d-flex p-0">
                    <button id="" class="btn table-buttons m-auto" onclick="borrar('producto-1')">
                        <i class="fa fa-trash font-weight-bold"></i>
                    </button>
                </div>
            </div>
        </div>

        <div class="form-group col-12">
            <div id="agregar-<?php echo e($data['form-id']); ?>" style="cursor: pointer">
                <i class="fa fa-plus-square fa-lg m-auto"></i>
                <a>Agregar Producto...</a>
            </div>
        </div>
    </div>

    <div class="form-row btn-submit">
        <div class="m-auto"> 
            <button class="form-btn"><?php echo e($data['type'] != "editar" ? "Enviar" : "Editar"); ?></button>
        </div>
    </div>    

</form>
<input type="hidden" id="" class="id-form" value="<?php echo e($data['form-id']); ?>">

<script src="<?php echo e(asset('js/form_validate.js')); ?>"></script>
<script>
    var agregar = "agregar-<?php echo e($data['form-id']); ?>";
    var recetario = "recetario-<?php echo e($data['form-id']); ?>";
    var cantidad = 2; //ESTO DEBERIA SER UN COUNT QUE SI DE UN AJAX QUE HAGA ESTE BETA

    $("#"+agregar).click(function() {
        html = "<div class='form-group col-12 row justify-content-center'>ALGO</div>";
        $("#"+recetario).append(html);
    });

	var numeroartes = 2;

    $("#arte_pesca").change(function(event) {
		$("#n_artes").append('<label class="form-control" id="a'+numeroartes+'"><input type="text" readonly="true" name="a'+numeroartes+'" value="'+$(this).val()+'" style="border: 0px; background: transparent"><button type="button" class="close p-0 m-0" aria-label="Close" onclick="borrar_arte('+numeroartes+')"><span aria-hidden="true">&times;</span></button></label>');
		numeroartes++;
	});

	function borrar(codigo){
		$("#"+codigo).remove();
	}
</script><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/includes/detail_product.blade.php ENDPATH**/ ?>