<tr>
    <td class="header">
        <a href="https://www.upload.ee/image/12015399/logo.png"><img src="https://www.upload.ee/thumb/12015399/logo.png" border="0" alt="Logo" /></a><br>
        <a href="<?php echo e($url); ?>">
            <?php echo e($slot); ?>

        </a>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\fatto-a-casa\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/header.blade.php ENDPATH**/ ?>