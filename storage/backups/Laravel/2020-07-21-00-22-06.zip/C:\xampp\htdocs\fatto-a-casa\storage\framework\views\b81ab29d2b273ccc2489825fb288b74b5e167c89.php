<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">

    <!-- Styles -->
    <!-- <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> -->
    <link href="pdf.css" rel="stylesheet">

</head>

<style>
    @font-face {
        font-family: Poppins-Regular;
        src: url('../font/poppins/Poppins-Regular.ttf'); 
    }
    
    @font-face {
        font-family: Poppins-Medium;
        src: url('../font/poppins/Poppins-Medium.ttf'); 
    }
    
    @font-face {
        font-family: Poppins-Bold;
        src: url('../font/poppins/Poppins-Bold.ttf'); 
    }
    
    @font-face {
        font-family: Poppins-SemiBold;
        src: url('../font/poppins/Poppins-SemiBold.ttf'); 
    }
    
    * {
        margin: 0px; 
        padding: 20px; 
        box-sizing: border-box;
    }
    
    body, html {
        height: 100%;
        font-family: Poppins-Regular, sans-serif;
        background: #f9f6f1;
    }
    h1{
    color: blue;
    font-size: 100px;
}
</style>

<!-- LAYOUT DEL PDF -->
    <body>
        <h1>Test Incomodo</h1>
        <img class="logo" src="<?php echo e(asset('img/logo.png')); ?>" height="100" width="100">
    </body>
</html><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/pdflayout/pdf.blade.php ENDPATH**/ ?>