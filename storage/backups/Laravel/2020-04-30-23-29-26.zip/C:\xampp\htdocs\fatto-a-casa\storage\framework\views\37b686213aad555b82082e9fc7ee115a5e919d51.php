<?php $__env->startSection('title','Home · Fatto a Casa'); ?>

<?php $__env->startSection('titulo','FATTO A CASA'); ?>

<?php $__env->startSection('tabs'); ?>
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('ind-logistica')); ?>">Logística</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('ind-venta')); ?>">Ventas</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('ind-compra')); ?>">Compras</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('ind-client')); ?>">Clientes</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('ind-proveedor')); ?>">Proveedores</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('ind-finanza')); ?>">Finanzas</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('info'); ?>

    <div class="text-right">
        <div class="btn">
            <select name="" id="" class="form-control">
                <option value="Todos">Todos</option>
                <?php for($i = date("Y"); $i >= date("Y")-5 ; $i--): ?>
                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                <?php endfor; ?>
            </select>
        </div>
    </div>

    <!-- INDICADOR ENTRADAS - SALIDAS -->
    <div class="row justify-content-center my-2 px-2">
        <!-- GRAFICO DE BARRAS SOBRE ENTRADAS -->
        <div class="col-lg col-md-10 col-sm-12">
            <?php
                $data_doublehorizontalbars = array(
                    "texto" => "TOP 5 ENTRADAS - SALIDAS DE INVENTARIO",
                    "canva" => "c1",
                    "chartHeight" => "70px",
                    "labels" => array('Cereza', 'Aguacate', 'Fresas', 'Patilla', 'Naranja'),
                    "bar-label-1" => "Salidas",
                    "bar-datos-1" => array(-10, -19, -20, -30, -15),
                    "bar-bgcolors-1" => "rgba(255,129,0,0.7)",
                    "bar-brcolors-1" => "rgba(128,66,5,0.8)",
                    "bar-label-2" => "Entradas",
                    "bar-datos-2" => array(30, 20, 30, 12, 10),
                    "bar-bgcolors-2" => "rgba(29,163,101,0.7)",
                    "bar-brcolors-2" => "rgba(25,61,47,0.8)",
                );
            ?>
            <?php echo $__env->make('includes.horizontal_bars',['data'=>$data_doublehorizontalbars], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <!-- LOS 2 BLOQUES siguientes -->
    <div class="row justify-content-center my-3 px-2">
        <!-- TOTALES DE VALORES EN GENERAL DE DESPACHOS Y VENTAS -->
        <div class="col-lg-6 col-md-10 col-sm-12 row">
            <?php
                $indicator_totals = array(
                    array(
                        "color-header" => "#BF6000",
                        "color-inside" => "#FF8100",
                        "cantidad" => 50000,
                        "text" => "INVENTARIO VENDIDO",
                        "figure" => "fa-dropbox",
                        "col" => 12
                    ) ,
                    array(
                        "color-header" => "#80170B",
                        "color-inside" => "#FF3017",
                        "cantidad" => 2000,
                        "text" => "DESPACHOS REALIZADOS",
                        "figure" => "fa-check-square-o",
                        "col" => 6
                    ),
                    array(
                        "color-header" => "#014A1D",
                        "color-inside" => "#028936",
                        "cantidad" => 1000,
                        "text" => "DESPACHOS CANCELADOS",
                        "figure" => "fa-archive",
                        "col" => 6
                    )
                );
            ?>
            <?php $__currentLoopData = $indicator_totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $totals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('includes.indicator_totals',['indicador'=>$totals], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- DESPACHOS REALIZADOS YA ABARCADO (MES, SEMANA, DIAS, ETC) -->
        <div class="col-lg-6 col-md-10 col-sm-12">
            <?php
                $data_singlebar = array(
                    "texto" => "TOTAL DESPACHOS REALIZADOS",
                    "canva" => "c2",
                    "labels" => array("ene.", "feb.", "mar.", "abr.", "may.", "jun.", "jul.", "ago.", "sep.", "oct.", "nov.", "dic."),
                    "datos" => array(3.7, 8.9, 9.8, 3.7, 23.1, 9.0, 8.7, 11.0, 23.1, 9.0, 8.7, 11.0),
                    "tipo" => "normal",
                    "bgcolors" => "rgba(255,48,23,0.7)",
                    "brcolors" => "rgba(128,23,11,0.8)"
                );
            ?>
            <?php echo $__env->make('includes.single_bar',['data'=>$data_singlebar], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <!-- LOS 2 BLOQUES siguientes -->
    <div class="row justify-content-center my-3 px-2">
        <!-- TOTALES DE ENTRADAS Y SALIDAS GENERAL POR DETERMINADOS TIEMPOS -->
        <div class="col-lg-6 col-md-10 col-sm-12">
            <?php
                $data_doublebar = array(
                    "texto" => "TOTALES DE ENTRADAS - SALIDAS DE INVENTARIO",
                    "canva" => "c3",
                    "labels" => array("lun.", "mar.", "mie.", "jue.", "vie.", "sab.", "dom."),
                    "bar-label-1" => "Entradas",
                    "bar-datos-1" => array(5, 7, 16, 24, 2, 4, 19),
                    "bar-bgcolors-1" => "rgba(29,163,101,0.7)",
                    "bar-brcolors-1" => "rgba(25,61,47,0.8)",
                    "bar-label-2" => "Salidas",
                    "bar-datos-2" => array(3.7, 8.9, 9.8, 3.7, 23.1, 9.0, 8.7),
                    "bar-bgcolors-2" => "rgba(255,129,0,0.7)",
                    "bar-brcolors-2" => "rgba(128,66,5,0.8)",
                );
            ?>
            <?php echo $__env->make('includes.double_bars',['data'=>$data_doublebar], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <!-- ROTACIÓN DE INVENTARIO (GENERAL, PRODUCTOS FRESCOS Y TRANSFORMADOS) -->
        <div class="col-lg-6 col-md-10 col-sm-12">
            <?php
                $data_singlebar = array(
                    "texto" => "ROTACIÓN DE INVENTARIO",
                    "canva" => "c4",
                    "labels" => array('Total', 'Prod. Frescos', 'Prod. Transformados'),
                    "datos" => array(0.25, 0.50, 0.16),
                    "tipo" => "porcentaje",
                    "bgcolors" => "rgba(255,129,0,0.7)",
                    "brcolors" => "rgba(128,66,5,0.8)"
                );
            ?>
            <?php echo $__env->make('includes.single_bar',['data'=>$data_singlebar], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <!-- ULTIMO BLOQUE DE INDICADOR -->
    <div class="row justify-content-center my-2 px-2">
        <!-- GRAFICO DE LINEAS SOBRE VENTA DE INVENTARIO -->
        <div class="col-lg col-md-10 col-sm-12">
            <?php
                $data_singleline = array(
                    "texto" => "INVENTARIO VENDIDO",
                    "canva" => "c5",
                    "labels" => array("ene.", "feb.", "mar.", "abr.", "may.", "jun.", "jul.", "ago.", "sep.", "oct.", "nov.", "dic."),
                    "datos" => array(3.7, 8.9, 9.8, 3.7, 23.1, 0, 8.7, 0, 23.1, 9.0, 8.7, 11.0),
                    "bgcolors" => "rgba(29,163,101,0.7)",
                    "brcolors" => "rgba(25,61,47,0.8)",
                    "chartHeight" => "70px"
                );
            ?>
            <?php echo $__env->make('includes.single_line',['data'=>$data_singleline], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        //ACOMODO LA BARRA DE NAVEGACION
        $("#iu").addClass("active");
        $("#iu").removeClass("icono_head");
        $(".iu").removeClass("icono_color");

        //BORRAR EL BOTON DE FILTRAR DE ALGUNOS INDICADORES
        $("#horizontalbars-filter").remove();
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/doublehorizontalbars.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/doublebars.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/singlebar.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/singleline.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/indicators/provider.blade.php ENDPATH**/ ?>