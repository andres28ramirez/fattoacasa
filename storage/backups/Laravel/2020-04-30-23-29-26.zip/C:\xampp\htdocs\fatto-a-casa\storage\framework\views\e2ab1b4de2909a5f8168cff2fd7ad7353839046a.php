<!-- BLOQUE DE LA INFORMACIÓN -->
<div class="row justify-content-center my-2 px-3">
    <!-- APARTADO CON LOS DATOS -->
    <div class="col-lg-6 col-md-10 col-sm-12">
        <div class="border">
            <div class="card-header bg-transparent d-flex mb-2">
                <h6 class="my-auto"><?php echo e($title); ?></h6>
                <i id="icon-edit" class="ml-2 my-auto fa fa-pencil text-muted fa-lg" style="cursor: pointer"></i>
            </div>

            <form method="POST" action="<?php echo e($data['action'] ? route($data['action']) : ''); ?>" class="validate-form" id="<?php echo e($data['form-id']); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-row justify-content-center px-3">
                    <?php $__currentLoopData = $data['form-components']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group col-12" id="input-<?php echo e($input['id_name']); ?>">
                            <label id="<?php echo e($input['id_name']=='form-re-password' ? 'label-delete' : ''); ?>"><?php echo e($input['label-name']); ?>:</label>
                            <div class="input-group validate-input" data-validate="<?php echo e($input['validate']); ?>">
                                <?php if($input['component-type']=="input"): ?>
                                    <?php if($input['id_name'] == "form-cid"): ?>
                                        <strong class='text-dark float-left my-auto'>
                                            <select name="tipo_cid" id="tipo_cid" 
                                                    class="form-control icon-box bg-transparent" 
                                                    style="width: fit-content; border-radius: 0px">
                                                <option value="V -" <?php echo e("V -" == $input['value_tipo'] ? "selected" : ""); ?>>V -</option>
                                                <option value="E -" <?php echo e("E -" == $input['value_tipo'] ? "selected" : ""); ?>>E -</option>
                                                <option value="J -" <?php echo e("J -" == $input['value_tipo'] ? "selected" : ""); ?>>J -</option>
                                            </select>
                                        </strong>
                                    <?php endif; ?>
                                    <input 
                                        class="form-control input100 <?php echo e($input['requerido']); ?> <?php echo e($errors->has($input['form_name']) ? ' is-invalid' : ''); ?>" 
                                        style="height: calc(2.19rem + 10px)"
                                        type="<?php echo e($input['type']); ?>" 
                                        id="<?php echo e($input['id_name']); ?>"
                                        name="<?php echo e($input['form_name']); ?>" 
                                        placeholder="<?php echo e($input['placeholder']); ?>"
                                        value="<?php echo e($input['value']); ?>"
                                        step = "any"
                                        readonly
                                    >
                                <?php elseif($input['component-type']=="select"): ?>
                                    <select name="<?php echo e($input['form_name']); ?>" disabled 
                                            id="<?php echo e($input['id_name']); ?>" 
                                            class="form-control input100 <?php echo e($input['requerido']); ?> <?php echo e($errors->has($input['form_name']) ? ' is-invalid' : ''); ?>" 
                                            style="height: calc(2.19rem + 10px)" >
                                            <option value="">Selecciona una Opción</option>
                                        <?php $__currentLoopData = $input['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($option['value']); ?>" 
                                                    <?php echo e($option['value'] == $input['value'] ? "selected" : ""); ?>>
                                                <?php echo e($option["nombre"]); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php elseif($input['component-type']=="textarea"): ?>
                                    <textarea 
                                        class="form-control input100 <?php echo e($input['requerido']); ?>"
                                        style="height: calc(2.19rem + 10px)"
                                        id="<?php echo e($input['id_name']); ?>"
                                        name="<?php echo e($input['form_name']); ?>"
                                        placeholder="<?php echo e($input['placeholder']); ?>"
                                        value="<?php echo e($input['value']); ?>"
                                        readonly
                                    ><?php echo e($input['value']); ?></textarea>
                                <?php elseif($input['component-type']=="checkbox"): ?>
                                    <div class="form-control input100" style="height: fit-content">
                                    <?php $__currentLoopData = $input['check-options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check">
                                            <input class="form-check-input" 
                                                    type="checkbox" 
                                                    id="cb-<?php echo e($option['label']); ?>" 
                                                    name="<?php echo e($option['name']); ?>"
                                                    value="1"
                                                    <?php echo e($option['value'] ? "checked" : ""); ?>>
                                            <label class="form-check-label" for="cb-<?php echo e($option['label']); ?>">
                                                <?php echo e($option["label"]); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <span class="focus-input100"></span>
                                <?php if($errors->has($input['form_name'])): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>El campo a editar ya posee un valor coincidente en los registros</strong>
                                    </span>
                                <?php endif; ?>
                            </div>                          
                        </div>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <input type="hidden" name="id" id="model-id-edit" value="<?php echo e($data['edit-id']); ?>">
            </form>
            <input type="hidden" id="" class="id-form" value="<?php echo e($data['form-id']); ?>">
        </div>
    </div>

    <!-- APATADO LATERAL CON LA INFORMACIÓN EXTRA -->
    <div class="col-lg-6 col-md-10 col-sm-12">

        <?php $__currentLoopData = $data_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-warning float-left mt-3 p-3 rounded-circle" style="width: fit-content; margin-left: -1.5em">
                <i class="fa fa-lg <?php echo e($component['icon']); ?>"></i>
            </div>
            <?php if($component === end($data_list)): ?>
            <div class="border-detail p-3 pl-5" style="border-bottom: 1px solid #ced4da;">
            <?php else: ?>
            <div class="border-detail p-3 pl-5">
            <?php endif; ?>
                <div class="rounded">
                <?php if(isset($component['title'])): ?>    
                    <span id="name-<?php echo e($component['table-id']); ?>" class="mb-2 col-12" style="font-size: 1.1em"><?php echo e($component['title']); ?></span>
                <?php endif; ?>
                <?php if($component['type'] == "table"): ?>
                    <div class="table-responsive col-12" id="<?php echo e($component['table-id']); ?>">
                        <input type="hidden" class="get-table-id" value="<?php echo e($component['table-id']); ?>">
                        <table class="table table-sm" style="overflow: auto; box-shadow: 0px 1px 6px 2px rgba(0,0,0,0.2);">
                            <thead class="thead-success text-dark" style="background-color: #f8fafc">
                                <tr>
                                    <?php $__currentLoopData = $component['titulos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $titulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center" scope="col" style="cursor: pointer">
                                            <span><?php echo e($titulo); ?></span>
                                        </th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>

                            <tbody class="" id="tbody">
                                <?php $__currentLoopData = $component['content']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="<?php echo e($info['id']); ?>">
                                        <?php for($i = 1; $i <= count($component['titulos']); $i++): ?>
                                            <?php if(isset($info['dato-'.$i])): ?>     
                                                <td class="text-center">
                                                    <?php echo e($info['dato-'.$i]); ?>

                                                </td>
                                            <?php endif; ?>
                                            <!-- ESTO PARA CUANDO VAYAMOS A AGREGAR COSAS UNICAS EN ALGUNOS LADOS -->
                                            <?php if(isset($info['estado-'.$i])): ?>
                                                <td class="text-center">
                                                    <span class="badge 
                                                            <?php echo e($info['estado-'.$i] ? 'badge-success' : 'badge-warning'); ?>">
                                                        <?php echo e($info['estado-'.$i] ? 'Pagado' : 'Pendiente'); ?>

                                                    </span>
                                                </td> 
                                            <?php elseif(isset($info['agenda-'.$i])): ?>
                                                <td class="text-center">
                                                    <span class="badge 
                                                            <?php echo e($info['agenda-'.$i] ? 'badge-success' : 'badge-warning'); ?>">
                                                        <?php echo e($info['agenda-'.$i] ? 'Finalizado' : 'Pendiente'); ?>

                                                    </span>
                                                </td> 
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(empty($component['content'])): ?>
                                    <tr>
                                        <td colspan="<?php echo e(count($component['titulos'])); ?>">
                                            <h5 class="text-center">NO SE ENCUENTRAN REGISTROS</h5>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php elseif($component['type'] == "totals"): ?>
                    <?php echo $__env->make('includes.indicator_totals',['indicador'=>$component], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php elseif($component['type'] == "inline-info"): ?>
                    <?php if(!empty($component['information'])): ?>
                        <?php $__currentLoopData = $component['information']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-block my-2">
                            <label class="font-weight-bold"><?php echo e($data['label']); ?>:</label>
                            <span class="d-inline form-control border-0" style="height: calc(2.19rem + 10px);">
                                <?php echo e($data['dato']); ?>

                            </span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                    <?php if(!empty($component['productos'])): ?>
                    <div class="d-block mt-2">
                        <label class="font-weight-bold">DETALLADO DE PRODUCTOS:</label>
                        <div class="col-12 p-2" >
                            <div class="input-group row justify-content-center">
                                <div class="col-6 d-flex">
                                    <!-- PRODUCTO -->
                                    <strong class="my-auto">Producto:</strong>
                                </div>
                                <div class="col-3">
                                    <!-- CANTIDAD -->
                                    <strong class="my-auto">Cantidad (Kg/Und):</strong>
                                </div>
                                <div class="col-3 d-flex">
                                    <!-- PRECIO -->
                                    <strong class="my-auto">Precio:</strong>
                                </div>
                            </div>                        
                        </div>
                        <?php $__currentLoopData = $component['productos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group form-control col-12 p-0" style="height: calc(2.19rem + 10px)">
                                <div class="input-group row justify-content-center">
                                    <div class="d-flex col-6" style="border-right: 1px solid #ced4da; overflow: hidden">
                                    <!-- PRODUCTO -->
                                        <div class="my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                                            <span><?php echo e($product['name']); ?></span>
                                        </div>
                                    </div>
                                    <div class="d-flex col-3" style="border-right: 1px solid #ced4da; overflow: hidden">
                                    <!-- CANTIDAD -->
                                        <div class="my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                                            <span><?php echo e($product['cantidad']); ?></span>
                                        </div>
                                    </div>
                                    <div class="d-flex col-3">
                                    <!-- PRECIO -->
                                        <div class="my-auto icon-box text-center bg-transparent" style="border: 0px; border-radius: 0px">
                                            <span><?php echo e($product['precio']); ?> Bs</span>
                                        </div>
                                    </div>
                                </div>                          
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>

                    <?php if(isset($component['recetario'])): ?>
                    <div class="d-block">
                        <label class="font-weight-bold">Recetario del Producto:</label>
                        <?php $cantidad = 1; ?>
                        <div class="form-row justify-content-center">
                            <div id="recetario-<?php echo e($data['form-id']); ?>" class="col-12">
                            <?php $__currentLoopData = $component['recetario']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group col-12 row justify-content-center" id="<?php echo e($cantidad); ?>">
                                    <div class="col-xl-5 col-12 p-0">
                                        <!-- PRODUCTO -->
                                        <label>Producto:</label>
                                        <div class="input-group validate-input" data-validate="Producto es requerido">
                                            <select name="form-producto-<?php echo e($cantidad); ?>"
                                                    id="form-producto-<?php echo e($cantidad); ?>" 
                                                    class="form-control border-right req-false" 
                                                    style="height: calc(2.19rem + 10px)" >
                                                <option selected value="<?php echo e($product['id']); ?>"><?php echo e($product['name']); ?></option>
                                                <?php $__currentLoopData = $data_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($recet['value']); ?>"><?php echo e($recet["nombre"]); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xl-5 col-12 p-0">
                                        <!-- CANTIDAD -->
                                        <label>Cantidad (Kg / Und):</label>
                                        <div class="input-group validate-input form-cantidad" data-validate="Producto es requerido">
                                            <input 
                                                class="form-control input100 border-left req-false" 
                                                style="height: calc(2.19rem + 10px)"
                                                type="number" 
                                                id="form-cantidad-<?php echo e($cantidad); ?>"
                                                name="form-cantidad-<?php echo e($cantidad); ?>" 
                                                placeholder="Ingrese el nombre del producto"
                                                value="<?php echo e($product['cantidad']); ?>"
                                                readonly
                                                min='0'
                                                step="any"
                                            >
                                        </div>
                                    </div>
                                    <div class="col-lg d-flex p-0">
                                        <button id="" class="btn recetario-buttons m-xl-auto mt-xl-0 mt-1" onclick="borrar(<?php echo e($cantidad); ?>)">
                                            <i class="fa fa-trash font-weight-bold"></i>
                                        </button>
                                    </div>
                                </div>
                                <?php $cantidad++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="form-group col-12">
                                <div class="d-none" id="agregar-<?php echo e($data['form-id']); ?>" style="cursor: pointer; width: fit-content">
                                    <i class="fa fa-plus-square fa-lg m-auto"></i>
                                    <a>Agregar Producto...</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>

<!-- BOTONES DE EDITAR O ECHAR PARA ATRAS -->
<div class="d-flex justify-content-end mt-2 p-2" style="background-color: #F6FAF5">
    <!-- APARTADO CON LOS DATOS -->
    <div class="">
        <button class="btn table-buttons px-5" disabled id="form-edit">Editar</button>
    </div>

    <!-- APATADO LATERAL CON LA INFORMACIÓN EXTRA -->
    <div class="mx-2">
        <button class="btn table-buttons px-5" id="form-back" onclick="retroceder()">Volver</button>
    </div>
</div>

<script>
    //ELIMINO EL SOMBRIADO DEL FORMULARIO, BORDES Y BOTON SUBMIT
        $(".container-forms").css("border","0px");
        $(".container-forms").css("box-shadow","none");

    //EVENTO DE CLICK DE EDITAR PARA MODIFICAR EL FORMULARIO
    (function ($) {
        "use strict";
        <?php if(isset($data['form-id'])): ?> var agregar = "agregar-<?php echo e($data['form-id']); ?>"; <?php endif; ?>
        var form_id; 

        $(".id-form").each(function(indice,elemento){
            form_id = $(this).val();
        });

        //ACOMODANDO PARA QUE EJECUTE LA VALIDACION
            $("#form-edit").click(function(event){
                //
                $("#"+form_id).submit();
                //EL RECETARIO PRODUCTO ES UN AJAX QUE SE EJECUTA EN FORM-VALIDATE.JS
                //SI TODO VA BIEN DEJA EL CHECK EN TRUE PARA QUE TERMINE DE LANZAR EL ACTION DEL FORM
            });
    
        //BOTON DE EDITAR FORMULARIO DE EDICIÓN
            $("#icon-edit").click(function(event){
                $("#form-edit").removeAttr("disabled");
                $('#'+form_id+' .input100').removeAttr("readonly");
                $('#'+form_id+' .input100').removeAttr("disabled");
                $("#recetario-"+form_id+" .input100").removeAttr("readonly");
                $('#'+agregar).removeClass("d-none");
                $('#form-re-password').removeClass("d-none");
                $("#label-delete").removeClass("d-none");
            });

        //EVENTO PARA QUITAR LA CONFIRMACIÓN DE CONTRASEÑA SE LLEGA Y LO MUESTRE LUEGO DE DARLE EDITAR
            $("#form-re-password").addClass("d-none");
            $("#label-delete").addClass("d-none");
    })(jQuery);

    //EVENTO PARA AGREGAR NUEVOS PRODUCTOS AL RECETARIO
        <?php if(isset($cantidad)): ?>
            var agregar = "agregar-<?php echo e($data['form-id']); ?>";
            var recetario = "recetario-<?php echo e($data['form-id']); ?>";
            var cantidad = parseInt("<?php echo e($cantidad); ?>", 16);

            $("#"+agregar).click(function() {
                html = "<div class='form-group col-12 row justify-content-center' id="+cantidad+">";
                html +=   "<div class='col-xl-5 col-12 p-0'>";
                html +=       "<label>Producto:</label>";
                html +=        "<div class='input-group validate-input' data-validate='Producto es requerido'>";
                html +=           "<select name='form-producto-"+cantidad+"'"; 
                html +=                   " id='form-producto-"+cantidad+"'"; 
                html +=                   " class='form-control input100 border-right req-true'"; 
                html +=                   " style='height: calc(2.19rem + 10px)' >";
                                <?php if(isset($data_products)): ?>
                                    <?php $__currentLoopData = $data_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                html +=                 "<option value='<?php echo e($recet['value']); ?>'><?php echo e($recet['nombre']); ?></option>";
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                html +=            "</select>";
                html +=        "</div>";
                html +=    "</div>";
                html +=    "<div class='col-xl-5 col-12 p-0'>";
                html +=        "<label>Cantidad (Kg / Und):</label>";
                html +=        "<div class='input-group validate-input' data-validate='Producto es requerido'>";
                html +=            "<input class='form-control input100 border-left req-true form-cantidad'"; 
                html +=                " style='height: calc(2.19rem + 10px)' type='number'"; 
                html +=                " id='form-cantidad-"+cantidad+"' name='form-cantidad-"+cantidad+"'"; 
                html +=                " value='0' placeholder='Ingrese la cantidad del producto' min='0' step='any'>";
                html +=        "</div>";
                html +=    "</div>";
                html +=    "<div class='col-lg d-flex p-0'>";
                html +=        "<button class='btn recetario-buttons m-xl-auto mt-xl-0 mt-1' onclick='borrar("+cantidad+")'>";
                html +=            "<i class='fa fa-trash font-weight-bold'></i>";
                html +=        "</button>";
                html +=    "</div>";
                html +="</div>";

                $("#"+recetario).append(html);
                cantidad++;
            });

            function borrar(codigo){
                $("#"+codigo).remove();
            }
        <?php endif; ?>
</script><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/includes/general_detail.blade.php ENDPATH**/ ?>