<?php $__env->startSection('title','Clientes · Fatto a Casa'); ?>

<?php $__env->startSection('titulo','LISTADO - CLIENTES'); ?>

<?php $__env->startSection('tabs'); ?>
    <ul class="nav nav-tabs">
        <li class="nav-item">
        <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('list-client')); ?>">LISTADO</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="">Opción 2</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="">Opción 3</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="">Opción 4</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('info'); ?>
    <div class="row  my-2 px-2">

            <ul class="nav nav-tabs opc">
                <li class="nav-item">
                <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('agg-cliente')); ?>"><i class="fa fa-plus"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark active font-weight-bold" href=""><i class="fa fa-refresh"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark active font-weight-bold" href=""><i class="fa fa-trash-o"></i></a>
                </li>
            </ul> 
        

            <?php
                $data_list = array(
                    "title" => "Listado de Clientes",
                    "route-opc1" => "list-client",
                    "route-opc2" => "",
                    "route-opc3" => "",

                    "titulos" => array(
                        "nombre",
                        "CI/RIF",
                        "Teléfono",
                        "Correo",
                        "Zona",
                        "Dirección",
                    ),

                    "content" => array( 

                        array(
                        "Nombre" => "Leonardo Guilarte",
                        "CI/RIF" => "268427456",
                        "Telefono" => "04120950165",
                        "Correo" => "leomiguel1907@gmail.com",
                        "Zona" => "Porlamar",
                        "Direccion" => "Calle San Juan Casa 110-15",
                        ),

                        array(
                            "Nombre" => "Andres Ramirez",
                            "CI/RIF" => "23123456",
                            "Telefono" => "04127654321",
                            "Correo" => "andres28ramirez@gmail.com",
                            "Zona" => "Pampatar",
                            "Direccion" => "Urbanizacion Nuevo mundo",
                        ),

                        array(
                            "Nombre" => "Inversiones 123 CA",
                            "CI/RIF" => "12345678",
                            "Telefono" => "04241234567",
                            "Correo" => "inver123@hotmail.com",
                            "Zona" => "El Hatillo",
                            "Direccion" => "Calle la rosa Local 12-10",
                        ),                                    

                    ),


                );
            ?>
            <?php echo $__env->make('includes.general_table',['data'=>$data_list], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        //ACOMODO LA BARRA DE NAVEGACION
        $("#ib").addClass("active");
        $("#ib").removeClass("icono_head");
        $(".ib").removeClass("icono_color");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/clients/lista.blade.php ENDPATH**/ ?>