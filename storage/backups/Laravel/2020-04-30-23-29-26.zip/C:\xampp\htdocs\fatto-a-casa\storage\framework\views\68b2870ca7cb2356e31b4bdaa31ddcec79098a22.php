<div class="col-12">
    <ul class="nav nav-tabs">
        <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($tab); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item">
            <a class="nav-link" href="#">Active</a>
        </li>

        <li class="nav-item">
            <a class="nav-link active font-weight-bold" href="#">Link</a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="#">Link</a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link" href="#">Disabled</a>
        </li>
    </ul>
</div>

<div class="card">

    <div class="card-body">
        CONTENIDO
        <?php echo $__env->yieldContent('contenido'); ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/includes/content.blade.php ENDPATH**/ ?>