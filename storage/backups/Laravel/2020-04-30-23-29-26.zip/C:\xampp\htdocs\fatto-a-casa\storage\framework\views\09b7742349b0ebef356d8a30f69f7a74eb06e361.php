<?php $__env->startSection('title','Back-ups · Fatto a Casa'); ?>

<?php $__env->startSection('titulo','FATTO A CASA - BACK-UPS'); ?>

<?php $__env->startSection('tabs'); ?>
    <ul class="nav nav-tabs opciones">
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('perfil')); ?>">Perfil</a>
        </li>
    <?php if(Auth::user()->tipo != "operador"): ?>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-users')); ?>">Usuarios</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-workers')); ?>">Empleados</a>
        </li>
    <?php endif; ?>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-reports')); ?>">Reportes Generados</a>
        </li>
    <?php if(Auth::user()->tipo != "operador"): ?>
        <li class="nav-item">
            <a class="nav-link text-secondary" href="<?php echo e(route('list-system')); ?>">Reportes del Sistema</a>
        </li>
    <?php endif; ?>
    <?php if(Auth::user()->tipo == "admin"): ?>
        <li class="nav-item">
            <a class="nav-link text-dark active font-weight-bold" href="<?php echo e(route('list-backups')); ?>">Restauración (Back-Ups)</a>
        </li>
    <?php endif; ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('info'); ?>
    <?php if(session('message')): ?>
        <h3 class="text-center alert alert-success"><?php echo e(session('message')); ?></h3>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <h3 class="text-center alert alert-danger"><?php echo e(session('status')); ?></h3>
    <?php endif; ?>

    <div class="row justify-content-center my-3 px-2">
        <h3>Administrar copias de seguridad de la base de datos</h3>
        <div class="col-12 clearfix">
            <a id="create-new-backup-button" href="<?php echo e(route('create-backup')); ?>" class="btn btn-primary pull-right"
            style="margin-bottom:2em;">
                <i class="fa fa-plus"></i> Crear nuevo Backup
            </a>
        </div>
        <div class="col-12">
            <?php if(count($backups)): ?>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>File</th>
                        <th>Size</th>
                        <th>Date</th>
                        <th>Age</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($backup['file_name']); ?></td>
                            <td><?php echo e($backup['file_size']); ?></td>
                            <?php 
                                setlocale(LC_TIME, 'spanish');
                                echo "<td>".strftime("%A, %d de %B de %Y",$backup['last_modified'])."</td>";
                            ?>
                            <td>
                                <?php echo e($backup['age']); ?>

                            </td>
                            <td class="text-right">
                                <a class="btn btn-xs btn-default"
                                href="<?php echo e(route('download-backup', ['file_name' => $backup['file_name']])); ?>"><i
                                        class="fa fa-cloud-download"></i> Download</a>
                                <a class="btn btn-xs btn-danger" data-button-type="delete"
                                href="<?php echo e(route('delete-backup', ['file_name' => $backup['file_name']])); ?>"><i class="fa fa-trash-o"></i>
                                    Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="well">
                    <h5>No existen copias de seguridad en el sistema</h5>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- MODAL PARA FILTRAR LA TABLA -->
    <div class="modal fade" id="table-filter" tabindex="-1" role="dialog" aria-labelledby="titulo" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="titulo">Filtrar Tabla</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                        $data_form = array(
                            "action" => "",
                            "title" => "",
                            "form-id" => "form-list-report",
                            
                            "form-components" => array(
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Incidencia Usuario o Sistema (Opcional*)",
                                    "icon" => "fa-list-alt",
                                    "type" => "text",
                                    "id_name" => "form-name",
                                    "form_name" => "form-name",
                                    "placeholder" => "Ingrese el nombre o la porción del mismo que desea",
                                    "validate" => "Código es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "select",
                                    "label-name" => "Tiempo a Evaluar",
                                    "icon" => "fa-hourglass-half",
                                    "id_name" => "form-tiempo",
                                    "form_name" => "form-tiempo",
                                    "title" => "Selecciona un tiempo",
                                    "options" => array(
                                        array(
                                            "value" => "Específico",
                                            "nombre" => "Específico",
                                        ),
                                        array(
                                            "value" => "todos",
                                            "nombre" => "Cualquier Fecha",
                                        ),
                                    ),
                                    "validate" => "Tiempo a evaluar es requerido",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-true",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Primera fecha",
                                    "icon" => "fa-calendar",
                                    "type" => "date",
                                    "id_name" => "form-fecha-1",
                                    "form_name" => "form-fecha-1",
                                    "placeholder" => "",
                                    "validate" => "Primera fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                                array(
                                    "component-type" => "input",
                                    "label-name" => "Segunda fecha",
                                    "icon" => "fa-calendar",
                                    "type" => "date",
                                    "id_name" => "form-fecha-2",
                                    "form_name" => "form-fecha-2",
                                    "placeholder" => "",
                                    "validate" => "Segunda fecha es requerida",
                                    "bd-error" => "LO QUE SEA",
                                    "requerido" => "req-false",
                                ),
                            ),
                        );
                    ?>
                    <?php echo $__env->make('includes.general_form',['data'=>$data_form], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/ajax.js')); ?>"></script>
    <script>
        //ELIMINAR LOS BOTONES DE AGREGAR-ELIMINAR-FILTRAR-DESCARGAR
            $("#add-lista-reportes").remove();
            $("#print-lista-reportes").remove();

        //BORRO EL TITULO DE LOS FORMULARIOS DE FILTRADO
            $(".form-title").remove();

        //ELIMINO EL SOMBRIADO DEL FORMULARIO Y LOS BORDES
            $(".container-forms").css("border","0px");
            $(".container-forms").css("box-shadow","none");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/profile/backups.blade.php ENDPATH**/ ?>