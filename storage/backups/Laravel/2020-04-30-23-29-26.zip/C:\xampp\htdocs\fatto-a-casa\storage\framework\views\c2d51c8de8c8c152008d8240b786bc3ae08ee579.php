<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="SHORTCUT ICON" href="<?php echo e(asset('img/logo.png')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jspdf.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/sweetalert.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/Chart.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="<?php echo e(asset('font/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/utils.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/navigation.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/toolbar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/form-styles.css')); ?>" rel="stylesheet">

    <!-- Script de la barra de navegación -->
    <script>
	    $(document).ready(function() {
	        $(".dropdown-item").hover(function() {
	      	    $(this).css('background-color', 'rgba(0,0,0,0.1)');
	        }, function() {
	      	    $(this).css('background-color', 'white');
	        });

	        $(".icono_head").hover(function() {
	      	    var id = $(this).attr('id');
	      	    $("."+id).removeClass('icono_color');
	        }, function() {
	      	    var id = $(this).attr('id');
	      	    $("."+id).addClass('icono_color');
	        });

	        $("#logo-imagen").click(function(event) {
	      	    location.href = "<?php echo e(url('/')); ?>";
            });
	    });
        
        function redirect(e){
            switch (e) {
                case "compras":
                    location.href = "<?php echo e(route('list-compras')); ?>";
                    break;
                case "ventas":
                    location.href = "<?php echo e(route('list-ventas')); ?>";
                    break;
                case "clientes":
                    location.href = "<?php echo e(route('list-client')); ?>";
                    break;
                case "proveedores":
                    location.href = "<?php echo e(route('list-prov')); ?>";
                    break;
                case "logistica":
                    location.href = "<?php echo e(route('list-inventario')); ?>";
                    break;
                case "finanzas":
                    location.href = "<?php echo e(route('list-ingresos')); ?>";
                    break;
                case "indicadores":
                    location.href = "<?php echo e(route('ind-logistica')); ?>";
                    break;
                case "calendario":
                    location.href = "<?php echo e(route('list-compras')); ?>";
                    break;
                default:
                    location.href = "<?php echo e(url('/')); ?>";
                    break;
            }
        }
  	</script>

</head>
<body>
    <div id="app">
     
    <!-- BARRA DE NAVEGACION -->
        <div class="nav-side-menu" id="barra_navegacion">
            <div class="brand py-2">
                <div class="m-auto text-center row justify-content-center py-3" style="cursor: pointer">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" class="img-fluid" width="125" height="125" id="logo-imagen"><br>
                </div>
            </div>
            <div class="menu-list">
                <ul id="menu-content" class="menu-content collapse out text-justified d-block">
                    <?php if(Auth::user()->permiso_compra): ?>
                        <li class="py-2 mx-4 icono_head" id="ic" onClick="redirect('compras')">
                            <a>
                                <i class="fa icono_color fa-shopping-cart fa-lg ic "></i>
                                <i class="ic icono_color fa fa-caret-right fa-lg"></i>
                                <span>COMPRAS</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(Auth::user()->permiso_venta): ?>
                        <li class="py-2 mx-4 icono_head" id="ip" onClick="redirect('ventas')">
                            <a>
                                <i class="fa fa-shopping-basket fa-lg ip icono_color"></i>
                                <i class="ip icono_color fa fa-caret-right fa-lg"></i>
                                <span>VENTAS</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(Auth::user()->permiso_cliente): ?>
                        <li class="py-2 mx-4 icono_head" id="ib" onClick="redirect('clientes')">
                            <a>
                                <i class="ib icono_color fa fa-users fa-lg"></i>
                                <i class="ib icono_color fa fa-caret-right fa-lg"></i> 
                                <span>CLIENTES</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(Auth::user()->permiso_proveedor): ?>
                        <li class="py-2 mx-4 icono_head" id="ich" onClick="redirect('proveedores')">
                            <a>
                                <i class="ich icono_color fa fa-book fa-lg"></i>
                                <i class="ich icono_color fa fa-caret-right fa-lg"></i> 
                                <span>PROVEEDORES</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(Auth::user()->permiso_logistica): ?>
                        <li class="py-2 mx-4 icono_head" id="iv" onClick="redirect('logistica')">
                            <a>
                                <i class="iv icono_color fa fa-dropbox fa-lg"></i>
                                <i class="iv icono_color fa fa-caret-right fa-lg"></i> 
                                <span>LOGÍSTICA</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(Auth::user()->permiso_finanzas): ?>
                        <li class="py-2 mx-4 icono_head" id="if" onClick="redirect('finanzas')">
                            <a>
                                <i class="if icono_color fa fa-money fa-lg"></i>
                                <i class="if icono_color fa fa-caret-right fa-lg"></i> 
                                <span>FINANZAS</span>
                            </a>
                        </li>
                    <?php endif; ?>
                        <li class="py-2 mx-4 icono_head" id="iu" onClick="redirect('indicadores')">
                            <a>
                                <i class="iu icono_color fa fa-pie-chart fa-lg"></i>
                                <i class="iu icono_color fa fa-caret-right fa-lg"></i> 
                                <span>INDICADORES</span>
                            </a>
                        </li>
                        <li class="py-2 mx-4 icono_head" id="icon" onClick="redirect('calendario')">
                            <a>
                                <i class="icon icono_color fa fa-calendar fa-lg"></i>
                                <i class="icon icono_color fa fa-caret-right fa-lg"></i>
                                <span>CALENDARIO</span>
                            </a>
                        </li>
                </ul>
            </div>
        </div>
    <!-- FIN BARRA DE NAVEGACION -->
    
    <!-- BARRA SUPERIOR -->
        <nav class="navbar navbar-expand-md navbar-light shadow-sm py-3" id="main" style="background-color: #C47E4D">
            <div class="container">
                <a class="navbar-brand text-white">
                    <?php echo $__env->yieldContent('titulo'); ?>
                </a>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <?php if(Auth::user()->permiso_venta || Auth::user()->permiso_logistica): ?>
                        <!-- Opciones de Notificaciones -->
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <span class="caret"><?php echo e(Session::get('notificaciones')); ?></span><i class="icon text-white fa fa-bell-o fa-lg"></i>
                            </a>
                            
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <?php if(Auth::user()->permiso_venta): ?>
                                <a class="dropdown-item" href="<?php echo e(route('list-cuentas')); ?>">
                                    <span class="caret"><?php echo e(Session::get('cobrar-expirar')); ?></span>
                                    <i class="icon fa fa-exclamation-circle fa-lg mx-1" style="color: #FFD70D;"></i>
                                    <span>Cuentas a Cobrar Proximas a Expirar</span>
                                </a>
                            <?php endif; ?>
                            <?php if(Auth::user()->permiso_logistica): ?>
                                <a class="dropdown-item" href="<?php echo e(route('list-inventario')); ?>">
                                    <span class="caret"><?php echo e(Session::get('inventario-expirar')); ?></span>
                                    <i class="icon fa fa-exclamation-circle fa-lg mx-1" style="color: #FFD70D;"></i>
                                    <span>Inventario Proximo a Expirarse</span>
                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('list-suministro')); ?>" style="border-bottom: 0.5px solid grey">
                                    <span class="caret"><?php echo e(Session::get('suministro-expirar')); ?></span>
                                    <i class="icon fa fa-exclamation-circle fa-lg mx-1" style="color: #FFD70D;"></i>
                                    <span>Suministro Proximo a Expirarse</span>
                                </a>
                            <?php endif; ?>
                            <?php if(Auth::user()->permiso_venta): ?>
                                <a class="dropdown-item" href="<?php echo e(route('list-cuentas')); ?>">
                                    <span class="caret"><?php echo e(Session::get('cobrar-caducar')); ?></span>
                                    <i class="icon text-danger fa fa-exclamation-triangle fa-lg mx-1"></i>
                                    <span>Cuentas a Cobrar Caducadas</span>
                                </a>
                            <?php endif; ?>
                            <?php if(Auth::user()->permiso_logistica): ?>
                                <a class="dropdown-item" href="<?php echo e(route('list-inventario')); ?>">
                                    <span class="caret"><?php echo e(Session::get('inventario-caducar')); ?></span>
                                    <i class="icon text-danger fa fa-exclamation-triangle fa-lg mx-1"></i>
                                    <span>Inventarios Expirados</span>
                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('list-suministro')); ?>">
                                    <span class="caret"><?php echo e(Session::get('suministro-caducar')); ?></span>
                                    <i class="icon text-danger fa fa-exclamation-triangle fa-lg mx-1"></i>
                                    <span>Suministros Expirados</span>
                                </a>
                            <?php endif; ?>
                            </div>
                        </li>
                        <?php endif; ?>

                        <!-- Opciones de Usuario -->
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <span class="caret"></span>
                                <?php echo e(Auth::user()->name); ?> 
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('perfil')); ?>">
                                    <i class="icon icono_color fa fa-gear fa-lg" style="color: #C47E4D"></i>
                                    <span><?php echo e(__('Configuración')); ?></span>
                                </a>  
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    <i class="icon icono_color fa fa-sign-out fa-lg" style="color: #C47E4D"></i>
                                    <span><?php echo e(__('Cerrar Sesión')); ?></span>
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    <!-- FIN BARRA SUPERIOR -->

    <!-- CONTENIDO DE CADA OPCION -->
        <main class="py-3" id="main">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    <!-- FIN CONTENIDO DE CADA OPCION -->

    </div>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\fatto-a-casa\resources\views/layouts/app.blade.php ENDPATH**/ ?>